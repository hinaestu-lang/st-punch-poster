# repo美化 — 代码审查与回归测试

## 维护原则

仓库中的 `src/repo美化.js` 和 `src/styles/panel.css` 是唯一主源码；`npm run build` 会生成供酒馆直接导入的 `dist/repo美化.json`。模板按 ID 唯一，保留旧版导入模板的兼容补丁。不要手改 `dist`，也不要将 `tests/results/` 的测试产物提交到仓库。

## 再审查：收藏来源和强调色回归修复（2026-11-15）

本轮以「repo美化-审查修复.zip」作为**唯一输入基准**，修复上一轮引入的五项回归，不重写已有的 14 个模板。

1. **删除死代码与修正说明**：移除已无调用方的 `latestMessageForWand()`；调整 `wholeMessageText()` 的注释和 `src/manifest.json` 的 `info`。魔棒菜单现在只打开句子拾取匣，不声称自动美化最新整楼。
2. **未分类旧收藏**：收藏详情使用 `snippetDraftMessageId()` 统一定位。如果旧收藏的 `sourceChat` 是当前聊天且原 `messageId` 有效，仍使用其原消息；否则回退当前聊天最新的可用消息。没有 `roleKey` 的旧收藏不再被虚假的角色校验拒绝。
3. **拾取模式的空来源 ID**：多段合并得到 `messageId:null` 时，尝试在有效标记或当前聊天中查找同角色的真实消息。找到则制作海报；找不到则报错，并保留拾取状态，不再无提示地结束。拾取多个不同角色时明确拦截，防止错误归属。
4. **返回按钮可读性**：新增与按钮填充色使用场景不同的 `--sn-accent-ink`，计算强调色在面板背景上的对比度；若不足 4.5:1 则回退为更易读的黑色或白色。保留 `--sn-accent-fg` 用于实色按钮上的文字。
5. **跨平台 Python 命令**：`npm run test:browser` 以 `python3` 启动全部回归测试，适应常见 macOS/Linux 环境；Windows 若没有 `python3` 命令需自行配置 Python 3 命令别名。补充 `tests/picker_legacy_regression.py` 覆盖以上问题。

验证：`npm run build`、`npm run check`、`npm run test:browser` 通过，另外在 320px 和 430px 环境中单独重跑模板浏览器检查；新增回归包括未分类收藏原消息/跨聊天回退、同角色定位、缺失角色提示、合并空 ID、混合角色拦截、浅色与深色返回文字对比度（均不低于 4.5:1）。这些是 Chromium 模拟验证，不代表实际 iPhone 或第三方插件中已完全无问题。

## 本轮确认的问题和修复（2026-11-15）

1. **收藏强调色恢复值**：无效颜色现在回退到 `snippetDefaultPrefs.accent`（`#1b1b1d`），夜间仍能自动切换到 `#f4f4f5`。主按钮、选中标记、返回入口和合并确认按钮都会使用强调色；为浅色强调色自动选择深色文字，避免可读性下降。
2. **跨消息合并来源**：仅当全部记录来自同一聊天、同一有效消息时保留 `messageId`；跨消息合并置为 `null`，如跨聊天再清空 `sourceChat`。点击「repo 美化」会优先选同角色的可用消息，而不是将合并内容错误归属给第一条或最新的其他角色消息。仍保留收藏的角色分组和原文文本。
3. **废弃局部变量与状态**：移除了无用的 `stage`、`ta` 局部变量、只写不读的 `st.fontCat`、`st.skinGroup`、`st.colY`、`st.colH`、`st.needH`，以及未用于渲染的 `postypeShowComments`、`postypeCaption` 默认字段。未删已在用户数据中的同名旧字段，避免破坏旧数据。
4. **CSS 无效规则**：删除 31 条可确认没有实际生成元素的样式，并清理同一优先级下被后续覆盖的声明；保留状态、媒体查询及动态生成节点所需的 CSS。
5. **小红书、POSTYPE 模板与旧补丁同步**：仓库的 `小红书.css` 已移除评论区死结构，更新配图提示和横版封面比例；`POSTYPE.css` 已去掉不再显示的上一篇/下一篇。**插件运行时兼容旧 CSS 的修正规则仍保留**，以照顾此前在手机中导入的文件。
6. **跨平台测试入口**：所有测试脚本的文本读取使用 UTF-8；`npm run test:browser` 现在覆盖全部回归脚本和 14 个模板的浏览器测试，不再漏掉边界情况。
7. **仓库冗余**：生成的 `tests/results/` 不再纳入项目包并被 `.gitignore` 忽略，原先多份重复的审查文档合并到此文件。

## 此前修复（简述）

- 按实际自然段及 `<br>` 获取选区，保留用户明确选择的文字，不把邻段或未选中的正文误加进去。
- 页边批注与 iMessage 多段内容在预览、编辑、导出时保持一致。
- CSS 长文预览滚动、根据内容高度导出、响应式媒体查询按预览设备解析，避免宽版页面末尾文字被截断。
- 导出期间切换模板或修改设置会取消旧导出；坏图不被当成有效成品。
- 备份导入校验模板与数据结构、收藏限额不静默删除、旧收藏跨段排序尽量保持原文顺序。
- 将面板 CSS 从 JS 源码分离、清理曾被后续覆盖的声明、去掉已废弃的导出结果页元素。

## 验证方法与结果

```bash
npm run build
npm run check
npm run test:browser
```

浏览器测试依赖 Python、Playwright（`pip install playwright`）、Pillow（`pip install pillow`）与 Chromium；请按本机 Playwright 安装说明安装浏览器。默认 390px，单独运行 `tests/browser_smoke.py` 时可以使用 `AUDIT_VIEWPORT=320` 或 `430`。

- 语法、独立导入 JSON 与源码一致性、14 个模板声明及 ID：通过。
- `test:browser`：Canvas、撤销重做、CSS 切换、iMessage 图片、坏图、异常备份、脚本重复加载、收藏选区、旧格式位置、图片重试、导出竞态、强调色、跨消息合并：通过。
- 14 种 CSS 在 320 / 390 / 430px 下短文、四段长文与 PNG 导出：共 84 次导出测试通过（`browser_smoke.py` 三个宽度独立运行）。
- 长文场景下 14 × 3 = 42 次正文编辑检查通过。与上一份清理版本导出的 14 × 3 张基准 PNG **逐像素一致**；预期变化发生在句子收藏面板的强调色与跨消息来源行为中。

## 限制与待真机验证

这不意味着可以保证不存在其他 bug。Chromium 无法覆盖 iPhone Safari / WKWebView 的内存阈值、键盘、手势、系统下载及第三方酒馆扩展冲突。另：完整设置备份不会自动包含单独保存在 IndexedDB 的自定义字体字节。新的第三方自定义 CSS 也必须单独验证。

此项目包**未被推送到 GitHub**。安装前请先备份旧脚本和酒馆内收藏/模板数据。


## 头像设置与选区菜单回归修复（2026-11-15）

- 修复模板头像设置入口仅对 POSTYPE、Threads 显示的回归：根据模板 `html` 是否声明 `data-pk="avatar"` 来决定显示通用头像设置，兼容所有使用标准头像插槽的模板。iMessage 的 `data-pk="im-avatar"` 仍使用独立的联系人头像设置；无头像插槽的模板不显示无效控制。保留既有 `postypeAvatarMode`、`postypeAvatarImg` 存储键以免丢失用户设置。
- 修复文字划选后菜单立即消失：`selectionchange` 短暂变为折叠状态时不清空最近一次有效选区；在 220ms 的等待期间也使用已捕获的选区作为兜底。点击选项、点击菜单外侧或 Esc 会关闭菜单。点击外部后即使浏览器重复发出旧 `selectionchange`，菜单也不会复活。首次划选及重新划选可正常更新选中句子。
- 为选区记录关联聊天标识与原消息对象，防止酒馆复用同一聊天数组时，错误地将旧选中文字应用到另一条同 ID 消息上。
- 补充 `tests/avatar_selection_regression.py` 并纳入 `npm run test:browser`：逐一验证 14 种模板的头像入口和可上传性；校验 iMessage 独立设置；验证系统选区在菜单出现前／出现后清空、选区菜单持续、实际 pointerdown 点击、美化和收藏、点击外部／Esc 关闭及重新选区。
- 保留上一轮修复的系统消息来源过滤、`/hide` 角色消息兼容、浏览器路径检测和冗余样式清理。未向 GitHub 推送文件。

验证：`npm run build && npm run check && npm run test:browser` 通过。当前环境为 Chromium；真实 iOS Safari 的系统选区弹窗和第三方插件冲突仍需设备确认。

## 选区消息来源与菜单复活修复（2026-11-15）

- 普通划选快捷菜单改为调用 `snippetMessageEligible(id)` 过滤无资格的 System/旁白消息；可校验真实角色姓名的 `/hide` 消息仍按原规则允许。
- 拾取模式的错误提示按情况区分：消息被删或不存在显示“原消息不存在或已失效”；真实系统/旁白消息显示“系统消息不能作为收藏来源”。
- 选区菜单、220ms 延迟弹出及单消息快捷拾取统一使用 `chatId ?? chatName` 作为聊天标识，并核对原消息对象，解决聊天数组在原地 `splice` 重用时旧选区被当成新聊天操作的问题。
- 菜单被点按正文等位置关闭时，记录选区的 DOM 起止节点及偏移；迟到的同一选区 `selectionchange` 不再复活菜单。只有真正不同的选区、`selectstart` 或新的长按选区手势才能恢复同一段文字的菜单。点击菜单按钮、按 Esc 也抑制旧选区复活。
- 新增 `tests/selection_context_regression.py`，纳入 `npm run test:browser`。覆盖 System 消息拦截、`/hide` 角色识别、正文点按后的迟到选区事件、相同范围的主动重新选取、原地复用聊天数组时的菜单点击/定时弹出/快捷拾取。全部断言通过；重新运行了 320、390、430px 的模板浏览器检查。
- **限制**：无法在 Chromium 中完整复现 iPhone WKWebView 的原生选区工具栏及 Safari 系统手势；对这部分仍需实机检查。未向 GitHub 推送。

## AO3 模板与选区修复（2026-11-15）

新增 `AO3-作品阅读页.css`（ID `ao3_work`）。整块作品 Rating/元数据由 `ao3ShowMetadata` 控制，正文来自用户选区，标题/作者/简介/说明来自现有文本字段，Rating 和其他元数据来自 AO3 专用输入。禁止复制参考图的同人文内容；保留 Top/Kudos，省略评论区。

选区菜单区分折叠与非折叠的非法选区；只有折叠可继续暂存旧选择，拖拽成跨消息选择时即刻失效。滚动引发的 `pointercancel` 不再凭 450ms 就重新显示同一旧范围。新增端到端回归 `tests/ao3_selection_regression.py`。

**本轮验证结果**：`npm run build`、`npm run check` 和完整 `npm run test:browser` 已通过；`AUDIT_VIEWPORT=320`、`390`、`430` 分别运行 `browser_smoke.py`，15 个模板各测试短文和四段长文，合计 90 次 PNG 导出。真实 iPhone Safari 原生文字选择操作仍需真机验证。

## 动态模板数量校验

- 移除 `tests/avatar_selection_regression.py` 中的 `len(specs)==15` 固定断言，改为检查模板目录非空并逐个遍历。`browser_smoke.py`、`check.mjs` 本来已按目录实际文件动态遍历。
- 移除完整备份中“超过 150 个 CSS 模板即拒绝”的固定数量门槛，仍保留原有备份文件大小及单模板内容安全校验。
- `templates/` 中的已附带 CSS 不等同于用户酒馆里的全部自定义模板；相同模板 ID 导入会替换，无相同 ID 则新增。
