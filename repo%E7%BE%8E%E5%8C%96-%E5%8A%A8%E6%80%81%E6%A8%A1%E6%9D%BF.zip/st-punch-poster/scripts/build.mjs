import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=part=>fs.readFileSync(path.join(root,part),'utf8');
const source=read('src/repo美化.js');
const css=read('src/styles/panel.css');
const marker="style.textContent = /* @embed-panel-css */ '';";
if(source.split(marker).length!==2) {
  throw new Error('无法嵌入内置 CSS：源码占位符必须恰好出现一次');
}
const content=source.replace(marker,`style.textContent = ${JSON.stringify(css)};`);
const manifest=JSON.parse(read('src/manifest.json'));
if(manifest.type!=='script'||!manifest.id||!manifest.name||!source.trim()||'content' in manifest) {
  throw new Error('酒馆助手脚本元数据或源码不完整');
}
const target=path.join(root,'dist/repo美化.json');
fs.mkdirSync(path.dirname(target),{recursive:true});
fs.writeFileSync(target,JSON.stringify({...manifest,content},null,2)+'\n');
console.log('已生成 dist/repo美化.json（独立可导入脚本，含内置 CSS）');
