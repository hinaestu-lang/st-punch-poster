import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const src=fs.readFileSync(path.join(root,'src/repo美化.js'),'utf8');
const css=fs.readFileSync(path.join(root,'src/styles/panel.css'),'utf8');
const marker="style.textContent = /* @embed-panel-css */ '';";
if(src.split(marker).length!==2)throw new Error('CSS 占位符异常');
const production=src.replace(marker,`style.textContent = ${JSON.stringify(css)};`);
// Check the actual standalone code executed by SillyTavern, not only the source fragment.
new vm.Script(production,{filename:'repo美化.bundle.js'});
execFileSync(process.execPath,['--check',path.join(root,'src/repo美化.js')],{stdio:'inherit'});
const manifest=JSON.parse(fs.readFileSync(path.join(root,'src/manifest.json'),'utf8'));
const dist=JSON.parse(fs.readFileSync(path.join(root,'dist/repo美化.json'),'utf8'));
if (dist.id!==manifest.id || dist.content!==production || dist.name!==manifest.name || dist.type!=='script') {
 throw new Error('dist/repo美化.json 与源码、manifest 不一致：请运行 npm run build');
}
const folder=path.join(root,'templates');
const ids=new Set();
const files=fs.readdirSync(folder).filter(n=>n.endsWith('.css'));
for(const file of files){
 const css=fs.readFileSync(path.join(folder,file),'utf8');
 const match=css.match(/\/\*\s*@pk-template\s*([\s\S]*?)\s*@end-pk-template\s*\*\//i);
 if(!match)throw new Error(file+': 缺少模板声明');
 const m=JSON.parse(match[1]);
 if(!m.id || typeof m.name!=='string' || typeof m.html!=='string' || !m.html.includes('data-pk="body"') || !Number.isFinite(Number(m.width)))throw new Error(file+': 模板字段不完整');
 if(ids.has(m.id))throw new Error(file+': 模板 ID 重复: '+m.id);
 // Keep repository templates aligned with the intentional runtime legacy patches.
 if(m.id==='xhs_note' && (m.html.includes('xhs-discuss') || m.html.includes('在画布设置中上传配图')
    || !m.html.includes('点击图片占位上传配图') || !/aspect-ratio:\s*390\s*\/\s*230\b/.test(css)))
   throw new Error(file+': 小红书模板包含旧版评论区、文案或竖版封面比例');
 if((m.id==='app_postype'||m.id==='postype') && m.html.includes('ps-neighbor'))
   throw new Error(file+': POSTYPE 模板包含已废弃的上一篇/下一篇结构');
 if(m.id==='ao3_work' && (!m.html.includes('data-pk-section=\"ao3-metadata\"') || !m.html.includes('data-pk=\"body\"') || /ao3-comments|comment-form|Comments:</i.test(m.html)))
   throw new Error(file+': AO3 模板必须有可选 Rating 元数据及正文，且不能含评论区');
 ids.add(m.id);
 if(css.length>180000 || /@import\b|javascript\s*:|expression\s*\(/i.test(css) || /url\s*\(\s*(?!["']?data:)[^)]+\)/i.test(css))throw new Error(file+': 不支持的外部 CSS/资源引用');
 if(/<\s*(?:script|iframe|object|embed|style|svg)\b/i.test(m.html) || /\bon\w+\s*=/i.test(m.html))throw new Error(file+': 模板 HTML 包含不被插件允许的标签');
}
console.log(`检查通过：主脚本语法、导入 JSON 一致性、${files.length} 个模板独立 ID 与结构`);
