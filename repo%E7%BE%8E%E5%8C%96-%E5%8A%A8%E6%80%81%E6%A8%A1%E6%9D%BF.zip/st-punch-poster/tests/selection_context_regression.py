"""Regression for selection security, recycled chat arrays, and Safari's late selectionchange."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
code = json.loads((ROOT / 'dist/repo美化.json').read_text(encoding='utf-8'))['content']
assert 'if(!Number.isInteger(id)||id<0||!snippetMessageEligible(id))return null;' in code
code = code.replace('  const dispose = init();', '''  window.__selAudit={
    readRepoSelection, updateRepoSelection, snippetMessageEligible,
    startSnippetPicking, stopSnippetPicking, onSnippetClick,
    selection:()=>repoSelectionRecord,
    pending:()=>repoSelectionPending,
    dismissed:()=>repoSelectionDismissed,
    quick:()=>snippetQuickTarget,
    snippets:snippetStore, marks:()=>snippetMarks,
    opened:()=>st.lastOpenedMessageId,
    close
  };
  const dispose = init();''',1)
assert 'window.__selAudit' in code
html = '''<!doctype html><html lang="zh"><head><meta charset="utf-8">
<style>body{margin:0}#chat{width:390px;margin:30px auto}.mes_text{font:18px/1.7 sans-serif}</style>
</head><body><div id="extensionsMenu"></div><div id="chat">
<div class="mes" mesid="0"><div class="mes_text"><p id="first">第一句收藏。</p><p id="second">第二句美化。</p></div></div>
<div class="mes" mesid="1"><div class="mes_text"><p id="system">系统旁白内容。</p></div></div>
<div class="mes" mesid="2"><div class="mes_text"><p id="hidden">隐藏的角色文字。</p></div></div>
</div><script>
window.__toasts=[];
window.toastr={error:m=>__toasts.push(['error',m]), info:m=>__toasts.push(['info',m]),success:m=>__toasts.push(['success',m]),warning:m=>__toasts.push(['warning',m])};
window.__ctx={extensionSettings:{},name1:'用户',name2:'角色甲',chatId:'chat-A',chatName:'Chat A',
 chat:[{name:'角色甲',mes:'第一句收藏。\\n第二句美化。',is_user:false},
       {name:'System',mes:'系统旁白内容。',is_system:true,is_user:false},
       {name:'角色甲',mes:'隐藏的角色文字。',is_system:true,is_user:false}],
 characters:[{name:'角色甲'}],characterId:0,saveSettingsDebounced(){}};
window.SillyTavern={getContext:()=>window.__ctx};
</script></body></html>'''
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, **({'executable_path':'/usr/bin/chromium'} if Path('/usr/bin/chromium').exists() else {}), args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':390,'height':844})
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html)
    page.add_script_tag(content=code)
    results = page.evaluate('''async()=>{
      const t=__selAudit, wait=ms=>new Promise(r=>setTimeout(r,ms));
      const menu=()=>document.querySelector('#pk-repo-selection');
      const visible=()=>!!menu()?.classList.contains('show');
      const select=id=>{
        const el=document.getElementById(id),r=document.createRange();r.selectNodeContents(el.firstChild);
        const sel=getSelection();sel.removeAllRanges();sel.addRange(r);
        document.dispatchEvent(new Event('selectionchange'));
      };
      // Ordinary system messages cannot be collected or used as artwork source.
      select('system');await wait(280);
      const systemRejected=t.readRepoSelection()===null && !visible();
      select('hidden');await wait(290);
      const hiddenVerified=t.readRepoSelection()?.id===2 && visible();
      // Tapping elsewhere in the same message body must dismiss, not resurrect.
      getSelection().removeAllRanges();
      select('first');await wait(290);
      document.getElementById('first').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));
      const dismissedInBody=!visible();
      for(let i=0;i<3;i++)document.dispatchEvent(new Event('selectionchange'));
      await wait(330);
      const noResurrection=!visible();
      // Selecting a different range intentionally should open the action menu.
      select('second');await wait(290);
      const changedRangeRearms=visible() && t.selection()?.text==='第二句美化。';
      // Re-selecting exactly the same range requires explicit selectstart.
      document.getElementById('second').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));
      document.dispatchEvent(new Event('selectionchange'));await wait(270);
      const staleIdenticalBlocked=!visible();
      document.getElementById('second').dispatchEvent(new Event('selectstart',{bubbles:true}));
      document.dispatchEvent(new Event('selectionchange'));await wait(270);
      const deliberateReselectRearms=visible();
      // In-place chat array mutation is not an identity change.
      const array=__ctx.chat;
      select('first');await wait(290);
      __ctx.chat.splice(0,3,{name:'角色乙',mes:'替换消息 A',is_user:false},
        {name:'角色乙',mes:'替换消息 B',is_user:false},
        {name:'角色乙',mes:'替换消息 C',is_user:false});
      __ctx.chatId='chat-B';
      const sameArray=array===__ctx.chat;
      menu().querySelector('[data-repo-action="collect"]').click();
      const staleActionBlocked=t.snippets().length===0 && __toasts.some(([kind,msg])=>kind==='error'&&msg.includes('已切换'));
      // Pending 220ms menu cannot re-open from another chat with recycled array.
      __ctx.chatId='chat-A';
      __ctx.chat.splice(0,3,{name:'角色甲',mes:'第一句收藏。',is_user:false},
        {name:'System',mes:'系统旁白内容。',is_system:true,is_user:false},
        {name:'角色甲',mes:'隐藏的角色文字。',is_system:true,is_user:false});
      getSelection().removeAllRanges();
      select('first');await wait(55);
      __ctx.chatId='chat-B';
      __ctx.chat.splice(0,1,{name:'角色乙',mes:'另一个聊天首条',is_user:false});
      await wait(290);
      const stalePendingBlocked=!visible();
      // Quick picker must also reject same-array in-place chat switch.
      __ctx.chatId='chat-A';
      __ctx.chat.splice(0,1,{name:'角色甲',mes:'第一句收藏。',is_user:false});
      t.startSnippetPicking({quick:true,messageId:0});
      const wasQuick=!!t.quick();
      __ctx.chatId='chat-C';
      __ctx.chat.splice(0,1,{name:'角色乙',mes:'新消息',is_user:false});
      document.getElementById('first').dispatchEvent(new MouseEvent('click',{bubbles:true,clientX:100,clientY:64}));
      const quickSwitchBlocked=t.marks().length===0 && t.snippets().length===0;
      t.stopSnippetPicking(false);
      return {systemRejected,hiddenVerified,dismissedInBody,noResurrection,changedRangeRearms,
        staleIdenticalBlocked,deliberateReselectRearms,sameArray,staleActionBlocked,stalePendingBlocked,
        wasQuick,quickSwitchBlocked};
    }''')
    print(json.dumps(results,ensure_ascii=False,indent=2))
    print('page errors',errors)
    assert all(results.values()),results
    assert not errors,errors
    browser.close()
