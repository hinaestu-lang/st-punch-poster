"""Regression: accent remains functional, merged quotes retain correct role/source."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
script = json.loads((ROOT / 'dist/repo美化.json').read_text(encoding='utf-8'))['content']
marker = '  const dispose = init();'
assert marker in script
script = script.replace(marker, '''
  window.__reviewTest = {
    openSnippetBox, snippetPrefs, snippetDefaultPrefs, snippetAccentText,
    snippetMergePlan, snippetOpenMergeEditor, snippetStore, renderSnippetBox, store,
    getOpening:()=>st.lastOpenedMessageId,
    detail:(id)=>{snippetView='detail';snippetDetailId=id;renderSnippetBox();}
  };
  const dispose = init();''', 1)
html = '''<!doctype html><html><head><meta charset="utf-8"></head><body>
<div id="extensionsMenu"></div><div id="chat">
<div class="mes" mesid="0"><div class="mes_text">用户发言</div></div>
<div class="mes" mesid="1"><div class="mes_text">第一句。</div></div>
<div class="mes" mesid="2"><div class="mes_text">第二句。</div></div>
<div class="mes" mesid="3"><div class="mes_text">用户后来发言</div></div>
</div><script>
window.toastr={error(){},info(){},success(){},warning(){}};
window.__ctx={extensionSettings:{},name1:'U',name2:'C',chatId:'chat-test',
chat:[{name:'U',mes:'用户发言',is_user:true},{name:'C',mes:'第一句',is_user:false},
{name:'C',mes:'第二句',is_user:false},{name:'U',mes:'用户后来发言',is_user:true}],
characters:[{name:'C'}],characterId:0,saveSettingsDebounced(){}};
window.SillyTavern={getContext:()=>window.__ctx};
</script></body></html>'''
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, **({'executable_path':'/usr/bin/chromium'} if Path('/usr/bin/chromium').exists() else {}), args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':390,'height':844})
    errors=[]
    page.on('pageerror',lambda err: errors.append(str(err)))
    page.set_content(html)
    page.add_script_tag(content=script)
    status = page.evaluate('''()=>{
      const t=__reviewTest,p=t.snippetPrefs();p.accent='BROKEN';p.theme='light';
      t.openSnippetBox();
      const box=document.querySelector('#pk-snip-overlay');
      const restored=p.accent,light=box.style.getPropertyValue('--sn-accent');
      p.theme='dark';t.renderSnippetBox();
      const dark=box.style.getPropertyValue('--sn-accent');
      p.theme='light';p.accent='#ffe680';t.renderSnippetBox();
      const b=document.createElement('button');b.className='pk-snip-primary';box.append(b);
      const selected=document.createElement('div');selected.className='pk-snip-card is-selected';
      const check=document.createElement('span');check.className='pk-snip-check';selected.append(check);box.append(selected);
      const buttonStyle=getComputedStyle(b),checkStyle=getComputedStyle(check);
      return {restored,light,dark,buttonBackground:buttonStyle.backgroundColor,
        buttonText:buttonStyle.color,selectedBackground:checkStyle.backgroundColor,
        selectedText:checkStyle.color};
    }''')
    print('accent:',status)
    assert status['restored']=='#1b1b1d' and status['light']=='#1b1b1d'
    assert status['dark']=='#f4f4f5'
    assert status['buttonBackground']=='rgb(255, 230, 128)'
    assert status['buttonText']=='rgb(25, 28, 32)'
    assert status['selectedBackground']=='rgb(255, 230, 128)'
    assert status['selectedText']=='rgb(25, 28, 32)'
    outcome = page.evaluate('''()=>{
       const t=__reviewTest;
       t.store().pickedSentences=[
        {id:'one',text:'第一句。',roleKey:'char:C',roleName:'C',messageId:1,sourceChat:'chat-test',savedAt:1},
        {id:'two',text:'第二句。',roleKey:'char:C',roleName:'C',messageId:2,sourceChat:'chat-test',savedAt:2}];
       t.renderSnippetBox();
       const plan=t.snippetMergePlan(['one','two']);t.snippetOpenMergeEditor(plan);
       document.querySelector('#pk-snip-merge-overlay .pk-snip-primary').click();
       const record=t.snippetStore()[0];
       t.detail(record.id);
       document.querySelector('.pk-snip-detail-actions .pk-snip-primary').click();
       return {messageId:record.messageId,sourceChat:record.sourceChat,roleKey:record.roleKey,
         text:record.text,openedMessage:t.getOpening()};
    }''')
    print('cross-message merge:',outcome,'errors:',errors)
    assert outcome['messageId'] is None
    assert outcome['roleKey']=='char:C'
    assert '第一句' in outcome['text'] and '第二句' in outcome['text']
    assert outcome['openedMessage']==2, 'must not choose latest unrelated speaker (message 3)'
    assert not errors
    browser.close()
