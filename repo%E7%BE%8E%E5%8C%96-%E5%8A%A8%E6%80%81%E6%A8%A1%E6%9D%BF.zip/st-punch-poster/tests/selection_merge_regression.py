"""Check selection offsets & merge semantics on real Chromium DOM."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
code=json.loads((root/'dist/repo美化.json').read_text(encoding='utf-8'))['content']
code=code.replace('  const dispose = init();', '''  window.__selectionAudit={clickedSentence,snippetNodeText,addPickedSentence,snippetMergePlan,snippetStore,snippetValidatedItems};
  const dispose = init();''',1)
html='''<html><head><meta charset="utf-8"></head><body><div id="extensionsMenu"></div><div id="chat"><div class="mes" mesid="0"><div class="mes_text"><p>[第一句被选中。]</p><p>第二句没被选中。</p><p>[第三句被选中。]</p></div></div></div><script>
window.toastr={error(){},info(){},success(){},warning(){}};
window.__ctx={extensionSettings:{},name1:'用户',name2:'角色',chatId:'chat-test',chat:[{name:'角色',mes:'消息',is_user:false}],characters:[{name:'角色'}],characterId:0,saveSettingsDebounced(){}};
window.SillyTavern={getContext:()=>window.__ctx};
</script></body></html>'''
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,**({'executable_path':'/usr/bin/chromium'} if Path('/usr/bin/chromium').exists() else {}),args=['--no-sandbox'])
 pg=b.new_page();errors=[];pg.on('pageerror',lambda err:errors.append(str(err)))
 pg.set_content(html);pg.add_script_tag(content=code)
 result=pg.evaluate('''()=>{
  const audit=window.__selectionAudit,body=document.querySelector('.mes_text');
  const ps=Array.from(body.querySelectorAll('p'));
  const picked=[];
  for(const index of [2,0]){
    const n=ps[index].firstChild;
    document.caretRangeFromPoint=()=>{const r=document.createRange();r.setStart(n,4);r.collapse(true);return r};
    const obj=audit.clickedSentence({clientX:40,clientY:20},body);
    if(!obj)throw new Error('failed to click text');
    const item=audit.addPickedSentence(obj.text,0,null,obj);
    picked.push({item,selection:obj.text,range:[obj.start,obj.end]});
  }
  const plan=audit.snippetMergePlan(picked.map(x=>x.item.id));
  const full=audit.snippetNodeText(body).full;
  // The legacy version stored paragraph-local offsets; make sure those do not
  // cause the unselected middle paragraph to be spliced into a merge.
  const legacy=audit.snippetValidatedItems(picked.map(({item})=>{const v={...item};delete v.sourceOffsetMode;v.sourceStart=0;v.sourceEnd=v.text.length;return v;}));
  __ctx.extensionSettings['punch-poster'].pickedSentences=legacy;
  const legacyPlan=audit.snippetMergePlan(legacy.map(x=>x.id));
  return {full,picked,proposal:plan.proposal,legacyProposal:legacyPlan.proposal,
    correctOffsets:picked[0].range[0]>picked[1].range[0]};
 }''')
 print(json.dumps(result,ensure_ascii=False,indent=2));print('errors',errors)
 assert result['correctOffsets']
 assert result['proposal']=='[第一句被选中。]\n[第三句被选中。]'
 assert '第二句' not in result['proposal']
 assert '第二句' not in result['legacyProposal']
 assert not errors
 b.close()
