"""AO3 source-content independence / rating panel and iOS selection boundary regressions."""
from pathlib import Path
import json, re, base64, io
from PIL import Image
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
code=json.loads((ROOT/'dist/repo美化.json').read_text(encoding='utf-8'))['content']
code=code.replace('  const dispose = init();', '''  window.__ao3Test={
    openById, close, cur, setKey, syncLayoutControls, cssTemplateExport,
    selection:()=>repoSelectionRecord,
    insert:spec=>{store().cssTpl[spec.id]=spec;cur().pageSkin='css:'+spec.id;st.cssSignature='';},
    preview:()=>st.ov?.querySelector('.pk-css-holder')?.shadowRoot?.querySelector('.pk-css-page'),
  };
  const dispose = init();''',1)
assert 'window.__ao3Test' in code
source=(ROOT/'templates/AO3-作品阅读页.css').read_text(encoding='utf-8')
m=re.search(r'/\*\s*@pk-template\s*([\s\S]*?)\s*@end-pk-template\s*\*/',source)
spec=json.loads(m.group(1));spec['css']=source.replace(m.group(0),'',1)
assert spec['id']=='ao3_work'
assert not re.search(r'After|Ruth0561|Henry|Brenner|Mature|Major Character Death',source,re.I), 'Screenshot content must not be copied'
html='''<!doctype html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><style>body{margin:0}#chat{width:90%;margin:20px auto}.mes_text{font:18px/1.75 serif}</style></head><body>
<div id="extensionsMenu"></div><div id="chat">
<div class="mes" mesid="0"><div class="mes_text"><p id="one">测试第一段。</p><p id="two">测试第二段。</p></div></div>
<div class="mes" mesid="1"><div class="mes_text"><p id="other">另一条角色消息。</p></div></div>
</div><script>window.__toasts=[];window.toastr={info:m=>__toasts.push(m),error:m=>__toasts.push(m),warning:m=>__toasts.push(m),success:m=>__toasts.push(m)};
window.__ctx={extensionSettings:{},name1:'用户',name2:'角色',chatId:'ao3-test',chatName:'ao3-test',chat:[{name:'角色',mes:'测试第一段。\\n测试第二段。',is_user:false},{name:'角色',mes:'另一条角色消息。',is_user:false}],characters:[{name:'角色'}],characterId:0,saveSettingsDebounced(){}};
window.SillyTavern={getContext:()=>window.__ctx};</script></body></html>'''

def chrome(p):
    args={'headless':True,'args':['--no-sandbox','--disable-web-security']}
    if Path('/usr/bin/chromium').exists():args['executable_path']='/usr/bin/chromium'
    return p.chromium.launch(**args)

with sync_playwright() as p:
    browser=chrome(p)
    page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html);page.add_script_tag(content=code)
    checks=page.evaluate('''async spec=>{
      const t=__ao3Test,wait=ms=>new Promise(r=>setTimeout(r,ms));
      t.insert(spec);t.openById(0,'测试第一段。\\n测试第二段。');
      t.setKey('pubTitle','用户自拟标题');t.setKey('pubAuthor','用户自拟署名');
      t.setKey('pubKicker','用户自己填写的故事简介。');t.setKey('pubNote','用户自己填写的作者说明。');
      t.setKey('ao3Rating','用户填写的等级');t.setKey('ao3MetaLines','Fandom: 用户自行输入的圈名\\nRelationship: 用户自行输入的关系\\n自由文本备注');
      await wait(110);
      const pg=t.preview(),meta=pg.querySelector('[data-pk-section="ao3-metadata"]');
      const render={title:pg.querySelector('h1').textContent,
       author:pg.querySelector('.ao3-author').textContent,
       summary:pg.querySelector('.ao3-summary .ao3-section-body').textContent,
       notes:pg.querySelector('.ao3-notes .ao3-section-body').textContent,
       rating:pg.querySelector('[data-pk="ao3-rating"]').textContent,
       labels:[...pg.querySelectorAll('.ao3-metadata [data-pk="ao3-meta-lines"] dt')].map(x=>x.textContent),
       footer:pg.querySelector('.ao3-actions').textContent,
       noComments:!pg.querySelector('.ao3-comments,.ao3-comment-form,[data-pk-section="ao3-comments"]'),
       metaVisible:!meta.hidden,
       hasOptions:!!document.querySelector('[data-ao3-options]:not([hidden])')};
      t.setKey('ao3ShowMetadata',false);await wait(100);
      render.hidden=!t.preview().querySelector('[data-pk-section="ao3-metadata"]').getBoundingClientRect().height;
      render.settingsHidden=!!document.querySelector('[data-ao3-meta-fields][hidden]');
      t.setKey('ao3ShowMetadata',true);await wait(110);
      render.restored=!!t.preview().querySelector('[data-pk-section="ao3-metadata"]').getBoundingClientRect().height;
      const png=await t.cssTemplateExport();render.png=png;
      t.close();
      const menu=()=>document.querySelector('#pk-repo-selection'), visible=()=>!!menu()?.classList.contains('show');
      const select=(id)=>{const el=document.getElementById(id),r=document.createRange();r.selectNodeContents(el.firstChild);const sel=getSelection();sel.removeAllRanges();sel.addRange(r);document.dispatchEvent(new Event('selectionchange'));};
      select('one');await wait(300);
      render.menuInitially=visible();
      // Safari collapsed a valid selection: keep the old quick actions.
      getSelection().removeAllRanges();document.dispatchEvent(new Event('selectionchange'));
      render.collapsedStillVisible=visible();
      select('one');await wait(320);
      // New, non-collapsed but invalid selection across different messages:
      // reject old saved text; the floating action MUST disappear.
      const r=document.createRange();r.setStart(document.getElementById('one').firstChild,0);r.setEnd(document.getElementById('other').firstChild,3);
      const sel=getSelection();sel.removeAllRanges();sel.addRange(r);document.dispatchEvent(new Event('selectionchange'));
      render.invalidRangeCloses=!visible()&&!t.selection();
      select('two');await wait(300);
      render.secondMenu=visible();
      document.getElementById('two').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));
      render.dismissed=!visible();
      await wait(470);
      // Stale range is still selected, but a scroll's pointercancel must not revive it.
      document.getElementById('two').dispatchEvent(new PointerEvent('pointercancel',{bubbles:true}));
      await wait(290);
      render.staleLongpressBlocked=!visible();
      return render;
    }''',spec)
    b64=checks.pop('png').split(',',1)[1]
    with Image.open(io.BytesIO(base64.b64decode(b64))) as im:
        checks['pngSize']=[im.width,im.height]
        assert im.height>200 and im.width>=390
        out=ROOT/'tests/results/ao3-preview.png'
        out.parent.mkdir(exist_ok=True,parents=True)
        im.save(out)
    print(json.dumps(checks,ensure_ascii=False,indent=2))
    assert checks['title']=='用户自拟标题'
    assert checks['author']=='用户自拟署名'
    assert checks['summary']=='用户自己填写的故事简介。'
    assert checks['notes']=='用户自己填写的作者说明。'
    assert checks['rating']=='用户填写的等级'
    assert checks['labels']==['Fandom:','Relationship:']
    for k in ('noComments','metaVisible','hasOptions','hidden','settingsHidden','restored','menuInitially','collapsedStillVisible','invalidRangeCloses','secondMenu','dismissed','staleLongpressBlocked'):
        assert checks[k],(k,checks)
    assert not errors,errors
    browser.close()
