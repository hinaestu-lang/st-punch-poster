"""Transient image failures, malformed old settings, merge ordering."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
code=json.loads((root/'dist/repo美化.json').read_text(encoding='utf-8'))['content']
code=code.replace('  const dispose = init();', '''  window.__edgeTest={imgOf,imgCache,store,cur,openById,fillEditorialImages,syncOne,snippetMergePlan};
  const dispose = init();''',1)
html='''<!doctype html><html><head><meta charset="utf-8"></head><body><div id="extensionsMenu"></div><div id="chat"><div class="mes" mesid="0"><div class="mes_text"><p>第一段。</p><p>第二段。</p></div></div></div><script>window.toastr={error(){},info(){},success(){},warning(){}};window.__ctx={extensionSettings:{},name1:'U',name2:'C',chatId:'chat-test',chat:[{name:'C',mes:'hi',is_user:false}],characters:[{name:'C'}],characterId:0,saveSettingsDebounced(){}};window.SillyTavern={getContext:()=>window.__ctx};</script></body></html>'''
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,**({'executable_path':'/usr/bin/chromium'} if Path('/usr/bin/chromium').exists() else {}),args=['--no-sandbox'])
 pg=b.new_page(viewport={'width':390,'height':844});errors=[]
 pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.set_content(html);pg.add_script_tag(content=code)
 result=pg.evaluate('''async()=>{
  const t=__edgeTest,s=__ctx.extensionSettings['punch-poster'];
  s.cur={skinImg:123,paperImg:45,postypeAvatarMode:'custom',postypeAvatarImg:123,
    pubImages:[{id:'a',src:99,caption:88}],imessageImage:12};
  const c=t.store().cur;
  // Check an untrusted preset re-normalizes after its object is replaced.
  const sanitized={image:c.skinImg,avatar:c.postypeAvatarImg,photo:c.pubImages[0].src,caption:c.pubImages[0].caption};
  t.openById(0,'测试文本');
  t.cur().pubImages=[{id:'p',src:77,caption:99}];
  t.syncOne('skinImg');t.fillEditorialImages();
  const broken='data:image/png;base64,%%%invalid%%%';
  t.imgOf(broken);
  await new Promise(r=>setTimeout(r,50));
  const old=t.imgCache.get(broken);
  t.imgOf(broken);const avoidedRequestStorm=t.imgCache.get(broken)===old;
  const errored=old.failedAt>0;
  old.failedAt=Date.now()-31000;
  t.imgOf(broken);
  const retried=t.imgCache.get(broken)!==old;
  return {sanitized,errored,avoidedRequestStorm,retried};
 }''')
 print(json.dumps(result,ensure_ascii=False,indent=2), 'pageErrors',errors)
 assert result['sanitized']=={'image':'','avatar':'','photo':'','caption':''}
 assert result['errored'] and result['avoidedRequestStorm'] and result['retried']
 assert not errors
 b.close()
