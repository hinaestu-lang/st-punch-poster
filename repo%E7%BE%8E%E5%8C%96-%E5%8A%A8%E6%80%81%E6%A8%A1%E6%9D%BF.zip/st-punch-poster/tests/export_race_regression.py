"""A stale async CSS screenshot must not export a different template."""
from pathlib import Path
import json,re
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
code=json.loads((root/'dist/repo美化.json').read_text(encoding='utf-8'))['content']
code=code.replace('  const dispose = init();','  window.__raceTest={openById,cssTemplateExport,setKey,store,cur};\n  const dispose = init();',1)
s=(root/'templates'/'推特.css').read_text(encoding='utf-8');m=re.search(r'/\*\s*@pk-template\s*([\s\S]*?)\s*@end-pk-template\s*\*/',s)
spec=json.loads(m.group(1));spec['css']=s.replace(m.group(0),'',1)
html='''<html><head><meta charset="utf-8"></head><body><div id="extensionsMenu"></div><div id="chat"><div class="mes" mesid="0"><div class="mes_text">一些文字。</div></div></div><script>window.toastr={error(){},info(){},success(){},warning(){}};window.__ctx={extensionSettings:{},name1:'U',name2:'C',chatId:'0',chat:[{name:'C',mes:'test',is_user:false}],characters:[{name:'C'}],characterId:0,saveSettingsDebounced(){}};window.SillyTavern={getContext:()=>window.__ctx};</script></body></html>'''
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,**({'executable_path':'/usr/bin/chromium'} if Path('/usr/bin/chromium').exists() else {}),args=['--no-sandbox'])
 pg=b.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.set_content(html);pg.add_script_tag(content=code)
 result=pg.evaluate('''async spec=>{
  const t=__raceTest;t.store().cssTpl[spec.id]=spec;t.openById(0,'第一段。');t.setKey('pageSkin','css:'+spec.id);
  const promise=t.cssTemplateExport();
  t.setKey('pageSkin','punch');
  let stopped=false;let message='';
  try{await promise}catch(e){stopped=true;message=String(e.message)}
  t.setKey('pageSkin','css:'+spec.id);
  const normal=await t.cssTemplateExport();
  return {stopped,message,normal:normal.startsWith('data:image/png;base64,')};
 }''',spec)
 print(result,'page errors',errors)
 assert result['stopped'] and '导出期间页面已修改' in result['message']
 assert result['normal'] and not errors
 b.close()
