from pathlib import Path
import json,re,base64,io
from PIL import Image
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
code=json.loads((ROOT/'dist/repo美化.json').read_text('utf8'))['content']
assert '  const dispose = init();' in code
hook='''  window.__pkTest = {
    openById,beginInlineEdit,finishInlineEdit,cssTemplateExport,changeZoom,
    close,render,setKey,historyTravel,historyPush,snippetImportData,
    startSnippetPicking,stopSnippetPicking,onSnippetClick,clickedSentence,
    snippetStore,store,cssEntries,
    get:()=>({base:st.base,custom:st.custom,rendered:st.chars.join(''),pageSkin:cur().pageSkin,
      height:st.H,zoom:st.zoom}),
    preview:()=>st.ov?.querySelector('.pk-css-holder')?.shadowRoot?.querySelector('.pk-css-page'),
    stage:()=>st.ov?.querySelector('.pk-stage'),
    insertTemplate: spec => {store().cssTpl[spec.id]=spec;cur().pageSkin='css:'+spec.id;st.cssSignature='';},
    addSnippet: addPickedSentence,
  };
'''
code=code.replace('  const dispose = init();',hook+'  const dispose = init();',1)
def spec(name):
 src=(ROOT/'templates'/name).read_text(encoding='utf-8')
 m=re.search(r'/\*\s*@pk-template\s*([\s\S]*?)\s*@end-pk-template\s*\*/',src)
 d=json.loads(m.group(1));d['css']=src.replace(m.group(0),'',1);return d
html='''<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><style>body{background:#ccc;}#chat{max-width:390px;margin:30px auto}.mes_text{font:18px/1.5 sans-serif}</style></head><body><div id="extensionsMenu"></div><div id="chat"><div class="mes" mesid="0"><div class="mes_text"><p>第一句完整结束。</p><p>[第二句话有完整括号。]</p><p>第三段。</p><p>第四段。</p></div></div></div><script>
window.__toasts=[];window.toastr={error:m=>__toasts.push(['error',m]),info:m=>__toasts.push(['info',m]),success:m=>__toasts.push(['success',m]),warning:m=>__toasts.push(['warning',m])};
window.confirm=()=>true;
window.__ctx={extensionSettings:{},name1:'用户',name2:'角色', chat:[{name:'角色',mes:'测试消息',is_user:false}],characters:[{name:'角色'}],characterId:0,chatId:'chat0',saveSettingsDebounced(){}};
window.SillyTavern={getContext:()=>window.__ctx};
</script></body></html>'''
results={}
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,**({'executable_path':'/usr/bin/chromium'} if Path('/usr/bin/chromium').exists() else {}),args=['--no-sandbox'])
 pg=b.new_page(viewport={'width':390,'height':844})
 errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.set_content(html);pg.add_script_tag(content=code)
 # Native canvas, zoom and undo.
 results['canvas']=pg.evaluate('''()=>{
  const t=__pkTest;t.openById(0,'第一段。\\n第二段。\\n第三段。');
  const cv=t.stage().querySelector('canvas'),url=cv.toDataURL('image/png');
  const original=t.get().rendered;
  t.beginInlineEdit();const field=document.querySelector('.pk-edta');field.innerText='修改后的正文。';
  t.finishInlineEdit(true);
  const modified=t.get().rendered;
  t.historyTravel(-1);const undone=t.get().rendered;
  t.historyTravel(1);const redone=t.get().rendered;
  t.close();return {image:url.startsWith('data:image/png;base64,'),original,modified,undone,redone};
 }''')
 # Template switching and old shadow rebuild.
 pg.evaluate('''spec=>__pkTest.insertTemplate(spec)''',spec('iMessage.css'))
 results['switch']=pg.evaluate('''spec=>{
  const t=__pkTest;t.openById(0,'第一段。\\n第二段。\\n第三段。');
  const first=t.preview().querySelectorAll('.im-row.im-in').length;
  t.insertTemplate(spec);t.render(true);
  const second=t.preview().querySelectorAll('.pa-note').length;
  t.close();return {first,second};
 }''',spec('页边批注.css'))
 # Image switch and valid tiny PNG.
 im=Image.new('RGBA',(8,8),(0,250,0,140));buf=io.BytesIO();im.save(buf,format='PNG');url='data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode()
 results['image']=pg.evaluate('''async args=>{
  const t=__pkTest;t.insertTemplate(args.spec);t.openById(0,'第一段。\\n第二段。');
  t.setKey('imessageShowImage',true);t.setKey('imessageImageSide','left');t.setKey('imessageImage',args.url);
  // Wait for the async preview update instead of racing a fixed 80 ms sleep.
  await new Promise(resolve=>{
    let frames=0;
    const check=()=>{
      if(t.preview()?.querySelector('[data-pk="im-image"] img') || ++frames>100)resolve();
      else requestAnimationFrame(check);
    };check();
  });
  const root=t.preview();const photo=root?.querySelector('[data-pk="im-image"] img');
  const left=root?.querySelector('[data-pk-section="im-photo"]')?.classList.contains('im-left');
  const exportUrl=await t.cssTemplateExport();
  t.close();return {photo:!!photo,src:photo?.getAttribute('src')?.slice(0,22),left,export:exportUrl.startsWith('data:image/png')};
 }''',{'spec':spec('iMessage.css'),'url':url})
 results['broken_image']=pg.evaluate('''async spec=>{
  const t=__pkTest;t.insertTemplate(spec);t.openById(0,'第一段。');
  t.setKey('imessageShowImage',true);t.setKey('imessageImage','data:image/png;base64,AAAAAAAA');
  await new Promise(r=>setTimeout(r,70));
  let failed=false;try{await t.cssTemplateExport()}catch(e){failed=/图片/.test(String(e))}
  t.close();return {failed};
 }''',spec('iMessage.css'))
 # Bad backup must not change library or prototypes.
 results['backup']=pg.evaluate('''async()=>{
  const t=__pkTest;const prior=t.snippetStore().length;
  const malformed=JSON.stringify({format:'punch-poster-full-backup',module:'punch-poster',settings:{cur:{},cssTpl:{bad:{id:'bad',name:'bad',width:390,html:'<div data-pk="body"></div>',css:'@import url(https://evil.example/x.css)'}}}});
  t.snippetImportData({size:malformed.length,text:async()=>malformed});
  await new Promise(r=>setTimeout(r,70));
  return {before:prior,after:t.snippetStore().length,errors:window.__toasts.filter(x=>x[0]==='error').map(x=>x[1])};
 }''')
 # Backups with more than 150 user CSS templates should be accepted: 15 is not a cap.
 results['many_templates']=pg.evaluate('''async()=>{
  const t=__pkTest;
  const cssTpl={};
  for(let i=0;i<151;i++){
    const id='extra_template_'+i;
    cssTpl[id]={id,name:'新增模板 '+i,width:390,html:'<article><section data-pk="body"></section></article>',css:'.pk-css-page{padding:12px;color:#222}'};
  }
  const raw=JSON.stringify({format:'punch-poster-full-backup',module:'punch-poster',settings:{cur:{},cssTpl}});
  const before=window.__toasts.length;
  t.snippetImportData({size:raw.length,text:async()=>raw});
  await new Promise(r=>setTimeout(r,180));
  const added=Object.keys(t.cssEntries()).filter(id=>id.startsWith('extra_template_'));
  const errors=window.__toasts.slice(before).filter(x=>x[0]==='error');
  t.openById(0,'新增模板的正文。');
  t.setKey('pageSkin','css:extra_template_150');
  await new Promise(r=>setTimeout(r,80));
  const text=t.preview()?.querySelector('[data-pk="body"]')?.textContent;
  t.close();
  return {added:added.length,lastTemplateRendered:text==='新增模板的正文。',errors};
 }''')
 # Reinject script to simulate SillyTavern JS hot reload; no duplicate global elements.
 pg.add_script_tag(content=code)
 results['reload']=pg.evaluate('''()=>({style:document.querySelectorAll('#pk-style').length,wand:document.querySelectorAll('#pk-wand').length,tapHandle:document.querySelectorAll('#pk-snip-tap-handle').length})''')
 results['pageErrors']=errors
 b.close()
print(json.dumps(results,ensure_ascii=False,indent=2))
(ROOT/'tests/results').mkdir(parents=True,exist_ok=True)
(ROOT/'tests/results/feature-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
assert results['canvas']['image']
assert results['canvas']['modified']=='修改后的正文。'
assert results['canvas']['undone']==results['canvas']['original']
assert results['canvas']['redone']==results['canvas']['modified']
assert results['switch']=={'first':3,'second':3}
assert results['image']['photo'] and results['image']['left'] and results['image']['export']
assert results['broken_image']['failed']
assert any('备份 CSS 模板不安全' in e for e in results['backup']['errors'])
assert results['many_templates']=={'added':151,'lastTemplateRendered':True,'errors':[]},results['many_templates']
assert results['reload']=={'style':1,'wand':1,'tapHandle':1}
assert not errors
