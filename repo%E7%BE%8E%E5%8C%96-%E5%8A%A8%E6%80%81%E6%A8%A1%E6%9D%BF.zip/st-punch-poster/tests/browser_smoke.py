from pathlib import Path
import os,shutil
import json,re,base64,io,traceback
from PIL import Image
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
script=json.loads((ROOT/'dist/repo美化.json').read_text('utf-8'))['content']
hook='''  window.__pkTest = {
    clickedSentence, snippetNodeText, marginNoteParts,
    openById, beginInlineEdit, finishInlineEdit, cssTemplateExport, changeZoom,
    get:()=>({source:st.custom,rendered:st.chars.join(''),pageSkin:cur().pageSkin,
      height:st.H,zoom:st.zoom,inlineEditing:st.inlineEditing,
      editable:st.inlineBodies?.length||0}),
    insertTemplate: spec => {store().cssTpl[spec.id]=spec;cur().pageSkin='css:'+spec.id;st.cssSignature='';},
    view:()=>st.ov?.querySelector('.pk-css-holder')?.shadowRoot?.querySelector('.pk-css-page'),
    sheet:()=>st.ov?.querySelector('.pk-css-holder'),
    overlay:()=>st.ov, close, store, syncAll
  };
'''
assert '  const dispose = init();' in script
script=script.replace('  const dispose = init();',hook+'  const dispose = init();',1)
html='''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><style>html,body{margin:0;background:#ddd;}#chat{width:385px;max-width:100%;margin:100px auto}.mes_text p{font-size:18px;line-height:1.9}</style></head><body><div id="extensionsMenu"></div><div id="chat"><div class="mes" mesid="0"><div class="mes_text"><p>她说。这句话已经结束了。]</p><p>[说起来，作为一个按月收费的AI男亲，你今天给的自拍是不是有点太少了？快点，干点对得起月租的活。]</p><p>下一段没有括号，但是也很重要。</p></div></div></div><script>
window.__errors=[];window.toastr={info(x){},success(x){},error(x){window.__errors.push('toast '+x)},warning(x){}};
window.__ctx={extensionSettings:{},name1:'用户',name2:'角色', chat:[{name:'角色',mes:'测试',is_user:false}],characters:[{name:'角色',avatar:''}],characterId:0,chatId:'test-chat',saveSettingsDebounced(){}};
window.SillyTavern={getContext:()=>window.__ctx};
</script></body></html>'''
files=sorted((ROOT/'templates').glob('*.css'))
scenarios={}
for f in files:
 s=f.read_text('utf-8');m=re.search(r'/\*\s*@pk-template\s*([\s\S]*?)\s*@end-pk-template\s*\*/',s)
 meta=json.loads(m.group(1));scenarios[meta['id']]={'name':meta['name'],'html':meta['html'],'css':s.replace(m.group(0),'',1),'id':meta['id'],'width':meta['width']}
errs=[];results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,**({'executable_path':'/usr/bin/chromium'} if Path('/usr/bin/chromium').exists() else {}),args=['--no-sandbox','--disable-web-security'])
 viewport=int(os.getenv('AUDIT_VIEWPORT','390'))
 page=browser.new_page(viewport={'width':viewport,'height':844},device_scale_factor=1)
 page.on('pageerror',lambda ex: errs.append(str(ex)))
 page.set_content(html)
 page.add_script_tag(content=script)
 # selection regression: bracketed paragraph only, no previous line.
 t=page.evaluate('''()=>{
  const ps=document.querySelectorAll('.mes_text p');
  const node=ps[1].firstChild;
  document.caretRangeFromPoint=()=>{const r=document.createRange();r.setStart(node,7);r.collapse(true);return r};
  const out=__pkTest.clickedSentence({clientX:70,clientY:200},document.querySelector('.mes_text'));
  const first=ps[0].firstChild;
  document.caretRangeFromPoint=()=>{const r=document.createRange();r.setStart(first,6);r.collapse(true);return r};
  const out2=__pkTest.clickedSentence({clientX:70,clientY:200},document.querySelector('.mes_text'));
  return {bracket:out?.text,prior:out2?.text,rangeCount:out?.ranges.length};
 }''')
 results.append({'feature':'selection bracket vs prior',**t,'pass':t['bracket']=='[说起来，作为一个按月收费的AI男亲，你今天给的自拍是不是有点太少了？快点，干点对得起月租的活。]' and '说起来' not in (t.get('prior') or '')})
 # second test with br within one parent
 t=page.evaluate('''()=>{
  const body=document.querySelector('.mes_text');body.innerHTML='旧句结束。<br>[新的句子，不要和旧句合并。]';
  const node=body.childNodes[2];document.caretRangeFromPoint=()=>{const r=document.createRange();r.setStart(node,4);r.collapse(true);return r};
  const out=__pkTest.clickedSentence({clientX:70,clientY:200},body);return {picked:out?.text,ranges:out?.ranges.length};
 }''')
 results.append({'feature':'br sentence boundary',**t,'pass':t['picked']=='[新的句子，不要和旧句合并。]'})
 # Every template: short text, long multi-paragraph editing, PNG, stage scroll, duplicate remount.
 for meta in scenarios.values():
  try:
   page.set_content(html)
   # redeclare mock after navigation
   page.add_script_tag(content=script)
   page.evaluate('''spec=>{__pkTest.insertTemplate(spec)}''',meta)
   for kind,body in [('short','简短的文字。'),('long','第一段包含中文和 English。|第二段。|第三段要被编辑。|第四段作为结尾。'.replace('|',chr(10)))]:
    page.evaluate('''text=>__pkTest.openById(0,text)''',body)
    page.wait_for_timeout(70)
    status=page.evaluate('''()=>{
       const t=__pkTest,pg=t.view(),stage=t.overlay()?.querySelector('.pk-stage'),sh=t.sheet();
       return {height:t.get().height,stageClientHeight:stage?.clientHeight,stageScrollHeight:stage?.scrollHeight,
         sheetScrollHeight:sh?.scrollHeight,bodyText:pg?.querySelector('[data-pk="body"]')?.textContent,
         width:pg?.getBoundingClientRect().width,pages:pg?.querySelectorAll('[data-pk="body"]').length};
    }''')
    if kind=='long':
     edit=page.evaluate('''()=>{
      const t=__pkTest;t.beginInlineEdit();const targets=t.view().querySelectorAll('[contenteditable="true"]');
      const before=Array.from(targets).map(x=>x.textContent);
      if(targets.length>2)targets[2].textContent='第三段已修改。';
      else if(targets.length)targets[0].textContent='第一段包含中文和 English。\\n第二段。\\n第三段已修改。\\n第四段作为结尾。';
      t.finishInlineEdit(true);
      return {before,after:t.get().rendered,targets:targets.length};
     }''')
     status['editTargets']=edit['targets'];status['editOkay']='第三段已修改' in edit['after'] and ('第一段' in edit['after']);status['newText']=edit['after']
     assert status['editOkay'],f"{meta['id']} edit lost data: {edit}"
    try:
     png=page.evaluate('''async()=>await __pkTest.cssTemplateExport()''')
     data=base64.b64decode(png.split(',')[1]);im=Image.open(io.BytesIO(data));status['png']=(im.width,im.height)
     if kind=='long':
      (ROOT/'tests/results/png'/str(viewport)).mkdir(parents=True,exist_ok=True)
      (ROOT/'tests/results/png'/str(viewport)/(meta['id']+'.png')).write_bytes(data)
     status['pngOK']=im.width>0 and im.height>0
    except Exception as e:
     status['pngError']=str(e)[:220];status['pngOK']=False
    assert status['height']>0 and status['pngOK']
    if kind=='long':
     # scroll container should clip long pages; css stage may be shorter than page
     status['stageScroll']=status['stageScrollHeight']>status['stageClientHeight']
    results.append({'template':meta['id'],'viewport':viewport,'scenario':kind,**{k:v for k,v in status.items() if k not in ['bodyText','newText']}})
    page.evaluate('''()=>__pkTest.close()''')
  except Exception as e:
   errs.append(f"{meta['id']}: {str(e)}")
 print('results count',len(results),'errors',len(errs),'unit',results[:2]);print('errors',errs[:18])
 browser.close()
(ROOT/'tests/results').mkdir(parents=True,exist_ok=True)
(ROOT/'tests/results'/f'integration-{viewport}.json').write_text(json.dumps({'results':results,'errors':errs},ensure_ascii=False,indent=2),encoding='utf8')
if errs or not all(x.get('pass',True) for x in results):
 raise SystemExit('FAIL: '+str(errs[:3]))
