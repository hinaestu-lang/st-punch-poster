"""Shared CSS avatar controls and persistent native-selection action menu."""
from pathlib import Path
import base64, io, json, re
from PIL import Image
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
code=json.loads((ROOT/'dist/repo美化.json').read_text(encoding='utf-8'))['content']
code=code.replace('  const dispose = init();', '''  window.__uxTest={openById,close,panel,setKey,syncLayoutControls,render,store,
    prefs:snippetPrefs,snippets:snippetStore,selection:()=>repoSelectionRecord,
    insertTemplate:spec=>{store().cssTpl[spec.id]=spec;cur().pageSkin='css:'+spec.id;st.cssSignature='';},
    preview:()=>st.ov?.querySelector('.pk-css-holder')?.shadowRoot?.querySelector('.pk-css-page'),
    opened:()=>st.lastOpenedMessageId};
  const dispose = init();''',1)
assert 'window.__uxTest' in code
specs=[]
for path in sorted((ROOT/'templates').glob('*.css')):
    src=path.read_text(encoding='utf-8')
    match=re.search(r'/\*\s*@pk-template\s*([\s\S]*?)\s*@end-pk-template\s*\*/',src)
    data=json.loads(match.group(1));data['css']=src.replace(match.group(0),'',1)
    specs.append(data)
assert specs, "模板目录为空，无法进行头像兼容性回归测试"
image=Image.new('RGBA',(8,8),(40,180,90,230));buf=io.BytesIO();image.save(buf,format='PNG')
url='data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode()
html='''<!doctype html><html lang="zh"><head><meta charset="utf-8">
<style>body{margin:0}#chat{width:390px;margin:40px auto}.mes_text{font:18px/1.7 sans-serif}</style></head><body>
<div id="extensionsMenu"></div><div id="chat"><div class="mes" mesid="0"><div class="mes_text">
<p>第一句用来收藏。</p><p>第二句用来美化。</p></div></div></div>
<script>window.__toasts=[];window.toastr={error:m=>__toasts.push(['error',m]),info:m=>__toasts.push(['info',m]),success:m=>__toasts.push(['success',m]),warning:m=>__toasts.push(['warning',m])};
window.__ctx={extensionSettings:{},name1:'用户',name2:'角色',chatId:'test-chat',
 chat:[{name:'角色',mes:'第一句用来收藏。\\n第二句用来美化。',is_user:false}],
 characters:[{name:'角色'}],characterId:0,saveSettingsDebounced(){}};
window.SillyTavern={getContext:()=>window.__ctx};
</script></body></html>'''
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,**({'executable_path':'/usr/bin/chromium'} if Path('/usr/bin/chromium').exists() else {}),args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':390,'height':844})
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html)
    page.add_script_tag(content=code)
    avatar_results=page.evaluate('''async ({specs,url})=>{
      const t=__uxTest;const results=[];
      for(const spec of specs){
        t.insertTemplate(spec);t.openById(0,'第一句用来收藏。\\n第二句用来美化。');
        t.panel('text');t.syncLayoutControls();
        const hasAvatar=/data-pk\\s*=\\s*["']avatar["']/i.test(spec.html);
        const fields=document.querySelector('[data-template-fields]');
        const avatar=document.querySelector('[data-template-field="avatar"]');
        const imOptions=document.querySelector('[data-imessage-options]');
        const shown=!fields.hidden&&!avatar.hidden;
        let uploaded=false;
        if(hasAvatar){
          t.setKey('postypeAvatarMode','custom');t.setKey('postypeAvatarImg',url);
          await new Promise(r=>setTimeout(r,110));
          uploaded=!!t.preview()?.querySelector('[data-pk="avatar"] img.pk-avatar-photo');
        }
        results.push({id:spec.id,hasAvatar,shown,uploaded,imessageOptions:!imOptions.hidden});
        t.close();
      }
      return results;
    }''', {'specs':specs,'url':url})
    assert all(r['hasAvatar']==r['shown'] for r in avatar_results),avatar_results
    assert all(r['uploaded'] for r in avatar_results if r['hasAvatar']),avatar_results
    assert next(r for r in avatar_results if r['id']=='imessage_dark')['imessageOptions']
    # Test both collapse-before-menu-appears and collapse-after-menu-appears.
    action_results=page.evaluate('''async()=>{
      const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
      const menu=()=>document.querySelector('#pk-repo-selection');
      const visible=()=>!!menu()?.classList.contains('show');
      const select=index=>{
        const txt=document.querySelectorAll('#chat .mes_text p')[index].firstChild;
        const range=document.createRange();range.selectNodeContents(txt);
        const sel=getSelection();sel.removeAllRanges();sel.addRange(range);
        document.dispatchEvent(new Event('selectionchange'));
      };
      const collapse=()=>{getSelection().removeAllRanges();document.dispatchEvent(new Event('selectionchange'));};
      select(0);await sleep(85);collapse();await sleep(320);
      const earlyCollapseStillVisible=visible();
      const firstText=__uxTest.selection()?.text;
      await sleep(600);
      const notVanishing=visible();
      menu().querySelector('[data-repo-action="collect"]').click();
      const collected=__uxTest.snippets().some(s=>s.text==='第一句用来收藏。');
      const afterCollectClosed=!visible();
      select(1);await sleep(340);
      const secondText=__uxTest.selection()?.text;
      collapse();await sleep(100);
      const afterCollapseStillVisible=visible();
      menu().querySelector('[data-repo-action="beautify"]').click();
      const opened=__uxTest.opened()===0;
      __uxTest.close();
      select(0);await sleep(290);
      const beforeOutside=visible();
      document.body.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));
      const outsideClosed=!visible();
      document.dispatchEvent(new Event('selectionchange'));await sleep(320);
      const oldSelectionNotRevived=!visible();
      // New selection after an outside click must replace the previous text.
      document.querySelectorAll('#chat .mes_text p')[1].dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));
      select(1);await sleep(290);
      const refreshed=visible()&&__uxTest.selection()?.text==='第二句用来美化。';
      document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
      const escaped=!visible();
      return {earlyCollapseStillVisible,notVanishing,firstText,collected,afterCollectClosed,
        secondText,afterCollapseStillVisible,opened,beforeOutside,outsideClosed,oldSelectionNotRevived,refreshed,escaped};
    }''')
    print('Avatars:', json.dumps(avatar_results,ensure_ascii=False,indent=2))
    print('Selection:',json.dumps(action_results,ensure_ascii=False,indent=2))
    print('Page errors:',errors)
    expected={'earlyCollapseStillVisible':True,'notVanishing':True,'firstText':'第一句用来收藏。','collected':True,
              'afterCollectClosed':True,'secondText':'第二句用来美化。','afterCollapseStillVisible':True,
              'opened':True,'beforeOutside':True,'outsideClosed':True,'oldSelectionNotRevived':True,'refreshed':True,'escaped':True}
    assert action_results==expected,(action_results,expected)
    # Real pointerdown+click sequence, not only DOM .click(): selection is gone
    # by the time a user actually reaches for the floating action bar.
    page.evaluate('''()=>{
      const txt=document.querySelectorAll('#chat .mes_text p')[0].firstChild;
      const r=document.createRange();r.selectNodeContents(txt);
      const sel=getSelection();sel.removeAllRanges();sel.addRange(r);
      document.dispatchEvent(new Event('selectionchange'));
    }''')
    page.wait_for_timeout(300)
    page.evaluate('''()=>{getSelection().removeAllRanges();document.dispatchEvent(new Event('selectionchange'))}''')
    assert page.locator('#pk-repo-selection.show').count()==1
    page.locator('#pk-repo-selection [data-repo-action="beautify"]').click()
    assert page.evaluate('''()=>__uxTest.opened()===0 && !!document.querySelector('#pk-overlay.show')''')
    assert not errors,errors
    browser.close()
