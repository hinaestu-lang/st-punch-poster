"""Legacy unclassified quotes, null-ID picker merges, and readable back action."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
dist = json.loads((root/'dist/repo美化.json').read_text(encoding='utf-8'))
script = dist['content']
assert 'function latestMessageForWand' not in script
assert 'function snippetDraftMessageId' in script
assert '最新消息' not in json.loads((root/'src/manifest.json').read_text(encoding='utf-8'))['info']
script = script.replace('  const dispose = init();', '''  window.__pickerAudit={openSnippetBox,closeSnippetBox,close,startSnippetPicking,stopSnippetPicking,
    snippetMarks,showSnippetActionMenu,snippetPrefs,snippetApplyAppearance,snippetAccentInk,
    snippetContrast,snippetDraftMessageId,snippetCurrentCharacter,snippetMessageEligible,snippetStore,store,renderSnippetBox,
    detail:(id)=>{snippetView='detail';snippetDetailId=id;renderSnippetBox()},
    opened:()=>st.lastOpenedMessageId,picking:()=>snippetPicking};
  const dispose = init();''', 1)
html='''<!doctype html><html><head><meta charset="utf-8"></head><body>
<div id="extensionsMenu"></div><div id="chat">
<div class="mes" mesid="0"><div class="mes_text">用户的消息。</div></div>
<div class="mes" mesid="1"><div class="mes_text">角色甲第一句。</div></div>
<div class="mes" mesid="2"><div class="mes_text">角色甲第二句。</div></div>
<div class="mes" mesid="3"><div class="mes_text">用户最后一句。</div></div>
</div><script>
window.__toasts=[];window.toastr={error:m=>__toasts.push(['error',m]),info:m=>__toasts.push(['info',m]),success:m=>__toasts.push(['success',m]),warning:m=>__toasts.push(['warning',m])};
window.__ctx={extensionSettings:{},name1:'用户',name2:'角色甲',chatId:'current',
 chat:[{name:'用户',mes:'用户的消息。',is_user:true},{name:'角色甲',mes:'角色甲第一句。',is_user:false},
       {name:'角色甲',mes:'角色甲第二句。',is_user:false},{name:'用户',mes:'用户最后一句。',is_user:true}],
 characters:[{name:'角色甲'}],characterId:0,saveSettingsDebounced(){}};
window.SillyTavern={getContext:()=>window.__ctx};
</script></body></html>'''
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,**({'executable_path':'/usr/bin/chromium'} if Path('/usr/bin/chromium').exists() else {}),args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':390,'height':844})
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html)
    page.add_script_tag(content=script)
    result=page.evaluate('''()=>{
      const t=__pickerAudit,records=t.store();
      const show=id=>{t.openSnippetBox();t.detail(id);document.querySelector('.pk-snip-detail-actions .pk-snip-primary').click();return t.opened()};
      records.pickedSentences=[{id:'unclassified-same',text:'旧收藏。',messageId:0,sourceChat:'current',savedAt:1}];
      const unclassifiedOriginal=show('unclassified-same');t.close();
      records.pickedSentences=[{id:'unclassified-foreign',text:'旧外部收藏。',messageId:null,sourceChat:'other',savedAt:2}];
      const unclassifiedFallback=show('unclassified-foreign');t.close();
      records.pickedSentences=[{id:'classified',text:'跨消息的角色句子。',roleKey:'char:角色甲',roleName:'角色甲',messageId:null,sourceChat:'current',savedAt:3}];
      const classifiedFallback=show('classified');t.close();
      // A classified quote must not borrow a user message if the role is absent.
      records.pickedSentences=[{id:'missing',text:'未知角色。',roleKey:'char:缺席',roleName:'缺席',messageId:null,sourceChat:'current',savedAt:4}];
      const prior=t.opened();t.openSnippetBox();t.detail('missing');
      document.querySelector('.pk-snip-detail-actions .pk-snip-primary').click();
      const missingRoleHandled=t.opened()===prior && __toasts.some(x=>x[0]==='error'&&x[1].includes('找不到'));
      t.closeSnippetBox();
      const prefs=t.snippetPrefs();prefs.theme='light';prefs.accent='#ffe680';t.openSnippetBox();t.detail('missing');
      const box=document.querySelector('#pk-snip-overlay');const back=box.querySelector('.pk-snip-back');
      const lightBack=getComputedStyle(back).color;const lightInk=box.style.getPropertyValue('--sn-accent-ink');
      const lightContrast=t.snippetContrast(lightInk,'#ffffff');
      prefs.theme='dark';prefs.accent='#111111';t.renderSnippetBox();
      const darkBack=getComputedStyle(box.querySelector('.pk-snip-back')).color;
      const darkInk=box.style.getPropertyValue('--sn-accent-ink');
      const darkContrast=t.snippetContrast(darkInk,'#191c20');t.closeSnippetBox();
      // A merged mark no longer has a message ID; the floating action must
      // resolve an existing message by role rather than silently doing nothing.
      t.startSnippetPicking({fromFloating:true});
      t.snippetMarks.push({id:'merged',text:'角色甲第一句。\\n角色甲第二句。',roleKey:'char:角色甲',messageId:null,ranges:[]});
      t.showSnippetActionMenu('角色甲第一句。\\n角色甲第二句。',null,80,80);
      const menuPresent=!!document.querySelector('#pk-snip-action-menu button');
      document.querySelector('#pk-snip-action-menu button').click();
      const pickerOpened=t.opened(),pickerClosed=!t.picking();t.close();
      // Missing source in picker: must keep picking and show feedback.
      t.startSnippetPicking({fromFloating:true});
      t.snippetMarks.push({id:'notfound',text:'未知角色句子。',roleKey:'char:缺席',messageId:null,ranges:[]});
      t.showSnippetActionMenu('未知角色句子。',null,80,80);
      document.querySelector('#pk-snip-action-menu button').click();
      const pickerMissingWarn=t.picking()&&__toasts.some(x=>x[0]==='error'&&x[1].includes('找不到'));
      t.snippetMarks.push({id:'other-role',text:'用户的句子。',roleKey:'user:用户',messageId:3,ranges:[]});
      t.showSnippetActionMenu('用户的句子。',3,80,80);
      document.querySelector('#pk-snip-action-menu button').click();
      const mixedRoleBlocked=t.picking()&&__toasts.some(x=>x[0]==='error'&&x[1].includes('不同角色'));
      t.stopSnippetPicking(false);
      // SillyTavern uses is_system both for genuine system entries and /hide.
      // Genuine system messages cannot impersonate the active character.
      __ctx.chat.push({name:'System',mes:'这是系统说明。',is_user:false,is_system:true}); // 4
      __ctx.chat.push({name:'角色甲',mes:'被隐藏的角色甲发言。',is_user:false,is_system:true}); // 5
      __ctx.chat.push({name:'角色乙',mes:'被隐藏的角色乙发言。',is_user:false,is_system:true}); // 6
      __ctx.characters.push({name:'角色乙'});
      const systemExcluded=!t.snippetMessageEligible(4);
      const hiddenRecognized=t.snippetMessageEligible(5)&&t.snippetMessageEligible(6)
        &&t.snippetCurrentCharacter(6).roleKey==='char:角色乙';
      const systemOriginal=t.snippetDraftMessageId({sourceChat:'current',messageId:4,roleKey:'unclassified'});
      const systemClassified=t.snippetDraftMessageId({sourceChat:'current',messageId:4,roleKey:'char:角色甲'});
      const hiddenSameRole=t.snippetDraftMessageId({sourceChat:'current',messageId:5,roleKey:'char:角色甲'});
      const hiddenOtherRole=t.snippetDraftMessageId({sourceChat:'current',messageId:6,roleKey:'char:角色乙'});
      const hiddenWrongRole=t.snippetDraftMessageId({sourceChat:'current',messageId:6,roleKey:'char:角色甲'});
      const noSystemFallback=t.snippetDraftMessageId({sourceChat:'other',messageId:null,roleKey:'unclassified'});
      return {unclassifiedOriginal,unclassifiedFallback,classifiedFallback,missingRoleHandled,
        lightBack,lightContrast,darkBack,darkContrast,menuPresent,pickerOpened,pickerClosed,pickerMissingWarn,mixedRoleBlocked,
        systemExcluded,hiddenRecognized,systemOriginal,systemClassified,hiddenSameRole,hiddenOtherRole,hiddenWrongRole,noSystemFallback};
    }''')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    print('page errors:',errors)
    assert result['unclassifiedOriginal']==0
    assert result['unclassifiedFallback']==3
    assert result['classifiedFallback']==2
    assert result['missingRoleHandled']
    assert result['lightContrast']>=4.5 and result['darkContrast']>=4.5
    assert result['lightBack']=='rgb(25, 28, 32)'
    assert result['darkBack']=='rgb(255, 255, 255)'
    assert result['menuPresent'] and result['pickerOpened']==2 and result['pickerClosed']
    assert result['pickerMissingWarn'] and result['mixedRoleBlocked']
    assert result['systemExcluded'] and result['hiddenRecognized']
    assert result['systemOriginal']==3 and result['noSystemFallback']==3
    assert result['systemClassified']==2 and result['hiddenWrongRole']==2
    assert result['hiddenSameRole']==5 and result['hiddenOtherRole']==6
    assert not errors
    browser.close()
