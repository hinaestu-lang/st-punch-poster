// 打孔海报 · 酒馆助手版
(() => {
  const window = globalThis.parent && globalThis.parent !== globalThis ? globalThis.parent : globalThis;
  const document = window.document;
  const { Image, FontFace, MutationObserver, SillyTavern, Path2D, DOMMatrix } = window;
  const requestAnimationFrame = window.requestAnimationFrame.bind(window);

  if (typeof window.__pkDispose === 'function') window.__pkDispose();
  document.getElementById('pk-style')?.remove();
  const style = document.createElement('style');
  style.id = 'pk-style';
  // Stylesheet consolidated from historical CSS append patches; original cascade order preserved.
  // The build step embeds src/styles/panel.css in dist/repo美化.json.
  // Keep CSS separate from application logic; dist remains standalone.
  style.textContent = /* @embed-panel-css */ '';

  document.head.appendChild(style);

const MODULE = 'punch-poster';

const BASE = {
  pageSkin: 'punch',     // 打孔 / 独立出版版式 / 真实 App 静态仿界面
  skinImg: '',          // 独立版式图片
  skinImgScale: 1, skinImgX: 50, skinImgY: 50,
  // POSTYPE 手机网页阅读页：不设置的文案优先沿用当前角色与当前日期。
  postypeChannel: '',
  postypeAvatarMode: 'char', // char / user / custom / initial
  postypeAvatarImg: '',
  postypeDate: '',
  postypeShowAuthor: true,
  // AO3: the metadata panel is optional; content remains user-supplied.
  ao3ShowMetadata: true,
  ao3Rating: '',
  ao3MetaLines: '',
  // One customizable Threads reply, independent of the main author's data.
  threadsShowComments: true,
  threadsReplyName: '',
  threadsReplyTime: '1天',
  threadsReplyText: '',
  threadsReplyAvatarMode: 'initial',
  threadsReplyAvatarImg: '',
  // iMessage only: optional photo message and independent contact avatar.
  imessageShowImage: false,
  imessageImage: '',
  imessageImageSide: 'right',
  imessageAvatarMode: 'system',
  imessageAvatarImg: '',

  layoutMode: 'double',     // double 双区 / single 纯正文打孔
  singleScraps: false,     // 单区是否在正文上叠放碎片（默认只有孔洞）
  scrapPos: 'top',          // 碎片区位置：top 在上 / bottom 在下
  width: 1080,              // 打孔导出宽度 / CSS 高清倍率基准
  cssPageWidth: 0,          // CSS 页面实际布局宽度（0 = 模板原宽），同时用于预览与 PNG 导出

  paperColor: '#fbfaf6',    // 正文纸色（碎片就是从这张纸上剪的）
  paperTex: 'none',         // 正文纸纹理
  paperImg: '',             // 正文纸底图
  paperImgScale: 1,         // 图片缩放，1 = 默认铺满
  paperImgX: 50,           // 图片水平对齐，0 左 50 中 100 右
  paperImgY: 50,           // 图片垂直对齐，0 上 50 中 100 下
  ink: '#2b2b2b',           // 字色
  fontKey: 'songti',        // 字体，见下方 FONTS
  fontName: '',             // 上传的字体文件名
  fontSize: 46,             // 正文字号
  lineHeight: 2.0,          // 行距倍数
  letterSpacing: 0,         // 字距 px
  indent: false,            // 段首缩进两格
  padX: 84,                 // 左右边距
  padY: 100,                // 正文区上下留白
  textBoxWidth: 100,        // 单区正文栏宽度（占可用空间百分比）
  textBoxX: 50,             // 单区正文栏水平位置（0 左 100 右）
  textVAlign: 'middle',     // 单区正文垂直位置
  pubOn: false,            // 单区图文编排：标题、正文、图片、署名按块流动
  pubTitle: '',
  pubKicker: '',
  pubTitleSize: 1.75,
  pubTitleAlign: 'left',
  pubSigPosition: 'end',    // title 标题下 / end 正文后 / footer 页脚
  pubImages: [],          // 段落之间的插图，每项含 src/after/width/align/ratio/caption

  backColor: '#bdb9b1',     // 底板色（孔里透出来的也是它）
  backTex: 'linen',         // 底板纹理
  backImg: '',              // 碎片区域图片，缩放平移以碎片区为边界
  backImgScale: 1,          // 背景图缩放
  backImgX: 50,            // 背景图水平对齐
  backImgY: 50,            // 背景图垂直对齐
  textAlign: 'left',        // 正文对齐：left / center / right / justify 两端
  split: 0.45,              // 碎片区占纸张高度的比例（拖分界白条调整）

  holeShape: 'rough',       // 孔形：rough 毛边 / rect 方 / round 圆角 / circle 圆 / torn 撕纸
  holeSize: 1.0,            // 孔大小（相对字号）
  holeShade: true,          // 孔边阴影
  holeMode: 'back',         // 孔里显示：back 透出底板 / color 自定义颜色
  holeColor: '#3b3833',     // 自定义孔颜色

  arrange: 'rows',          // 碎片排列
  rowLimit: 6,              // 每行最多几个碎片，满行自动换行
  columnLimit: 5,           // 每列最多几个碎片，满列自动换列
  scrapScale: 1.0,          // 碎片相对孔的大小，1 = 和孔一样大
  scrapVar: 0.0,            // 碎片大小错落，0 = 全部一致
  scrapTilt: 0.12,          // 碎片最大倾斜（弧度）
  scrapShadow: true,        // 碎片阴影
  deco: 0,                  // 空白装饰碎片数量

  pubAuthor: '{{char}}',      // 全模板共用的作者（可修改）
  pubNote: '',              // 全模板共用的附注 / 题记，支持换行
  pubDate: '',              // 全模板共用日期，留空为今天
  sig1: '{{char}}',         // 署名第一行，可用 {{char}} {{user}} {{date}}，留空不显示
  sig2: '{{user}}',         // 署名第二行
  sig3: '',                 // 自定义第三行
  sig4: '',                 // 自定义第四行
  sigAlign: 'right',        // 署名对齐：left / center / right
  sigPlace: 'scrap',        // 文案位置：scrap 碎片区 / text 原文区
  sigSize: 0.56,            // 署名字号（相对正文字号）
  sigColor: '#555555',      // 文案颜色（文案在碎片区底部）
  repOn: false,             // 一键替换开关
  reps: [                   // 替换规则：from 原词 → to 替换成，{{char}} {{user}} 代表当前名字
    { from: '{{char}}', to: 'char' },
    { from: '{{user}}', to: 'user' },
  ],
  randomCount: 8,           // 随机挖几个
};

const SIG_KEYS = ['pubTitle', 'pubKicker', 'pubAuthor', 'pubNote', 'pubDate', 'sigAlign', 'sigPlace', 'sigSize', 'sigColor'];

const BUILTIN = {
  '麻布': {},
  '粉白散落': {
    scrapPos: 'bottom', arrange: 'scatter', holeShape: 'rect',
    paperColor: '#ffffff', backColor: '#e3d4d9', backTex: 'grain',
    fontKey: 'heiti',
    scrapScale: 1.2, scrapVar: 0.18, scrapTilt: 0.14, deco: 4,
  },
  '墨绿阶梯': {
    scrapPos: 'top', arrange: 'stairs', holeShape: 'rect',
    paperColor: '#465243', paperTex: 'canvas', ink: '#eeeee6',
    backColor: '#e6eae7', backTex: 'crumple', scrapTilt: 0.06, textAlign: 'justify', indent: true, sigColor: '#5d6b5a',
  },
  '牛皮纸': {
    paperColor: '#f4efe4', paperTex: 'fiber', backColor: '#b68f63', backTex: 'fiber',
    holeShape: 'shred', scrapVar: 0.28, scrapTilt: 0.2, arrange: 'scatter', deco: 2,
  },
  '方格本': {
    paperColor: '#fdfdfb', paperTex: 'grid', backColor: '#2f3a4a', backTex: 'grain', sigColor: '#c8ced8',
    fontKey: 'heiti', holeShape: 'round', scrapTilt: 0.05,
  },

  '旧报纸': {
    paperColor: '#eee0c6', paperTex: 'fiber', ink: '#382f28',
    backColor: '#ad987e', backTex: 'grain', sigColor: '#382f28',
    fontKey: 'notoserif', holeShape: 'torn', arrange: 'scatter', scrapTilt: 0.12,
  },
  '霜蓝信纸': {
    paperColor: '#edf4f7', paperTex: 'lines', ink: '#354c5e',
    backColor: '#9bb4c4', backTex: 'grain', sigColor: '#293e53',
    fontKey: 'notoseriftc', holeShape: 'round', scrapVar: 0.14,
  },
  '暗室黑稿': {
    layoutMode: 'single', singleScraps: false,
    paperColor: '#252830', paperTex: 'grain', ink: '#eeede7',
    backColor: '#0f131a', holeMode: 'color', holeColor: '#626879',
    sigColor: '#c3c8d1', sigPlace: 'text', fontKey: 'notoseriftc', holeShape: 'rough',
  },
  '铅灰复写': {
    paperColor: '#e6e9e8', paperTex: 'grid', ink: '#353a3b',
    backColor: '#444c53', backTex: 'halftone', sigColor: '#e9e9e3',
    fontKey: 'notosanstc', holeShape: 'shred', arrange: 'stairs', scrapTilt: 0.09,
  },
  '朱砂印记': {
    paperColor: '#f4e8df', paperTex: 'fiber', ink: '#553831',
    backColor: '#883f40', backTex: 'grain', sigColor: '#f1ddd0',
    holeMode: 'color', holeColor: '#b44e47', fontKey: 'kaiti', holeShape: 'rough',
  },
  '紫雾拼贴': {
    paperColor: '#f5f0f7', paperTex: 'none', ink: '#463b51',
    backColor: '#a79ab6', backTex: 'canvas', sigColor: '#332d42',
    holeShape: 'round', arrange: 'scatter', scrapScale: 1.12, scrapVar: 0.25,
  },
  '森林标本': {
    paperColor: '#edf0e3', paperTex: 'fiber', ink: '#344739',
    backColor: '#a7b4a0', backTex: 'linen', sigColor: '#354b39',
    fontKey: 'wenkai', holeShape: 'maple', arrange: 'stairs',
  },
  '棕褐胶片': {
    paperColor: '#f0e3d5', paperTex: 'grain', ink: '#4e392e',
    backColor: '#694b42', backTex: 'halftone', sigColor: '#f5e6d7',
    fontKey: 'notoserif', holeShape: 'rect', arrange: 'rows', scrapTilt: 0.03,
  },
  '深海蓝图': {
    paperColor: '#204866', paperTex: 'grid', ink: '#eef5fc',
    backColor: '#102d45', backTex: 'grain', sigColor: '#d4e4ee',
    holeMode: 'color', holeColor: '#85b4d1', holeShape: 'shred',
    fontKey: 'notosanstc', arrange: 'scatter', scrapVar: 0.2,
  },
  '粉色便笺': {
    layoutMode: 'single', singleScraps: false,
    paperColor: '#fae8ea', paperTex: 'grid', ink: '#624850',
    backColor: '#bc7e8e', holeMode: 'color', holeColor: '#d2a1ad',
    sigColor: '#734a59', sigPlace: 'text', fontKey: 'xiaowei', holeShape: 'round',
  },
  '荧光剪贴': {
    paperColor: '#fffdf3', paperTex: 'none', ink: '#242523',
    backColor: '#d7d9ce', backTex: 'halftone', sigColor: '#41433d',
    holeMode: 'color', holeColor: '#cbe64c', fontKey: 'notosans',
    holeShape: 'rect', arrange: 'scatter', scrapVar: 0.18,
  },
  '雾银单页': {
    layoutMode: 'single', singleScraps: false,
    paperColor: '#ebeeec', paperTex: 'linen', ink: '#374040',
    backColor: '#8d9a97', holeMode: 'color', holeColor: '#7c9998',
    sigPlace: 'text', sigColor: '#475655', fontKey: 'notoserif', holeShape: 'torn',
  },
};

const COLOR_RAIL = ['#25262a','#555b67','#2b4b70','#7dabc5','#3e6259','#95b29b','#735c8d','#b9a7cc','#9e3d46','#df7f73','#ad7754','#e1bf9e','#8f9594','#d6d2c9','#d6e450','#f8f5eb','#ffffff','#000000'];
function colorRail(key){
  return `<div class="pk-color-rail" aria-label="左右滑动选择颜色">${COLOR_RAIL.map(c=>`<button type="button" data-color-key="${key}" data-color-value="${c}" title="${c}" aria-label="选择颜色 ${c}" style="--pk-rail-color:${c}"></button>`).join('')}</div>`;
}



const TEXT_LAYOUTS = {
  book: { title: '经典书页', fontSize: 44, lineHeight: 1.9, letterSpacing: 0, padX: 120, padY: 115, textAlign: 'justify', indent: true, textBoxWidth: 100, textBoxX: 50, textVAlign: 'middle' },
  poem: { title: '疏朗诗行', fontSize: 49, lineHeight: 2.7, letterSpacing: 3, padX: 140, padY: 135, textAlign: 'left', indent: false, textBoxWidth: 72, textBoxX: 22, textVAlign: 'middle' },
  center: { title: '中央独白', fontSize: 53, lineHeight: 2.25, letterSpacing: 2, padX: 140, padY: 130, textAlign: 'center', indent: false, textBoxWidth: 82, textBoxX: 50, textVAlign: 'middle' },
  narrow: { title: '窄栏文章', fontSize: 42, lineHeight: 2.0, letterSpacing: 1, padX: 135, padY: 100, textAlign: 'left', indent: true, textBoxWidth: 60, textBoxX: 25, textVAlign: 'top' },
  right: { title: '右侧手记', fontSize: 43, lineHeight: 2.25, letterSpacing: 1, padX: 145, padY: 110, textAlign: 'right', indent: false, textBoxWidth: 68, textBoxX: 100, textVAlign: 'middle' },
  bottom: { title: '低处题记', fontSize: 52, lineHeight: 2.15, letterSpacing: 2, padX: 155, padY: 145, textAlign: 'left', indent: false, textBoxWidth: 86, textBoxX: 50, textVAlign: 'bottom' },
  airy: { title: '通透留白', fontSize: 44, lineHeight: 2.75, letterSpacing: 6, padX: 95, padY: 150, textAlign: 'justify', indent: false, textBoxWidth: 100, textBoxX: 50, textVAlign: 'middle' },
  compact: { title: '密排档案', fontSize: 35, lineHeight: 1.45, letterSpacing: 0, padX: 85, padY: 100, textAlign: 'left', indent: false, textBoxWidth: 100, textBoxX: 50, textVAlign: 'top' },
};

const ZINE_LAYOUTS = {
  literary: { name:'文学杂志', pubTitleSize:1.95, pubTitleAlign:'left', pubSigPosition:'title', fontSize:44, lineHeight:1.9, padX:118, padY:105, textBoxWidth:100, textBoxX:50, textVAlign:'top', textAlign:'justify', indent:false },
  folio: { name:'艺术图录', pubTitleSize:1.32, pubTitleAlign:'center', pubSigPosition:'end', fontSize:40, lineHeight:2.15, padX:132, padY:120, textBoxWidth:92, textBoxX:50, textVAlign:'top', textAlign:'left', indent:false },
  notebook: { name:'私人小刊', pubTitleSize:1.56, pubTitleAlign:'left', pubSigPosition:'end', fontSize:45, lineHeight:2.25, padX:140, padY:120, textBoxWidth:76, textBoxX:5, textVAlign:'top', textAlign:'left', indent:false },
  catalogue: { name:'章节扉页', pubTitleSize:2.5, pubTitleAlign:'right', pubSigPosition:'title', fontSize:41, lineHeight:2.1, padX:116, padY:135, textBoxWidth:86, textBoxX:100, textVAlign:'top', textAlign:'left', indent:false },
};

const TEX = [
  ['none', '无'], ['grain', '颗粒'], ['linen', '麻布'], ['canvas', '帆布'], ['fiber', '纤维'],
  ['crumple', '褶皱'], ['grid', '方格'], ['lines', '横线'], ['dots', '点阵'], ['halftone', '网点'],
];

const HANG = '，。、！？；：”’）》」』…,.!?;:';
const NO_RANDOM = /[\s，。、！？；：“”‘’（）《》「」『』【】…—·～~,.!?;:'"()<>\[\]\-■]/;

const st = {
  zoom: 1, livePreview: true, lastTab: 'text', history: [], historyIndex: -1, historyLock: false, historyLastKey: '', historyLastAt: 0,
  base: '', custom: null, customIsRendered: false, raw: '', chars: [], holes: [],
  speaker: '', isUser: false, editing: false, seed: 0, boxes: [], pieces: [], off: {}, free: [], fid: 0, canvas: null, ov: null,
  lastOpenedChat: null, lastOpenedMessageId: null,
};
let rafId = 0;

const ctx = () => SillyTavern.getContext();
// Normalize once per settings object. A fresh object (undo/reset) is normalized
// again, but ordinary reads no longer replace a reference another handler uses.
const normalizedCur = new WeakSet();
function store() {
  const es = ctx().extensionSettings;
  if (!es[MODULE] || typeof es[MODULE] !== 'object' || Array.isArray(es[MODULE])) es[MODULE] = {};
  const s = es[MODULE];
  // Repair an incomplete backup without discarding previously imported CSS.
  if (!s.cur || typeof s.cur !== 'object' || Array.isArray(s.cur)) s.cur = {};
  for (const key of ['tpl','sigTpl','cssTpl','cssHidden'])
    if (!s[key] || typeof s[key] !== 'object' || Array.isArray(s[key])) s[key] = {};
  if (!normalizedCur.has(s.cur)) {
    s.cur = Object.assign(clone(BASE), clone(s.cur));
    normalizedCur.add(s.cur);
    // Restore safely even if an older import saved malformed lists.
    if(!Array.isArray(s.cur.reps))s.cur.reps=[];
    else s.cur.reps=s.cur.reps.filter(r=>r&&typeof r==='object'&&!Array.isArray(r))
      .slice(0,300).map(r=>({from:String(r.from??''),to:String(r.to??'')}));
    if(!Array.isArray(s.cur.pubImages))s.cur.pubImages=[];
    else s.cur.pubImages=s.cur.pubImages.filter(x=>x&&typeof x==='object'&&!Array.isArray(x))
      .slice(0,80).map(x=>({...x,src:typeof x.src==='string'?x.src:'',caption:typeof x.caption==='string'?x.caption:''}));
    // Broken/old presets must not crash image widgets via non-string URLs.
    for(const k of ['skinImg','paperImg','backImg','postypeAvatarImg','threadsReplyAvatarImg','imessageImage','imessageAvatarImg'])
      if(typeof s.cur[k]!=='string')s.cur[k]='';
    if(typeof s.cur.pageSkin!=='string')s.cur.pageSkin='punch';
    // Upgrade older positional signatures without modifying existing new fields.
    if (!s.cur.pkSharedCopyV32) {
      const old = s.cur;
      const titleValue = String(old.sig1 || '').trim();
      if (!old.pubTitle && titleValue && titleValue !== '{{char}}') old.pubTitle = titleValue;
      const leftover = [old.sig2, old.sig3, old.sig4]
        .filter((v, i) => v && String(v).trim() && !(i === 0 && v === '{{user}}'));
      if (!old.pubNote && leftover.length) old.pubNote = leftover.join('\n');
      old.pkSharedCopyV32 = true;
    }
    const legacy = s.cur.pageSkin || 'punch';
    if (legacy !== 'punch' && !String(legacy).startsWith('css:')) s.cur.pageSkin='css:'+legacy;
    if (legacy==='css:singlepage' && !s.cssTpl.singlepage) {
      s.cur.pageSkin='punch'; s.cur.layoutMode='single'; s.cur.singleScraps=false;
    }
    if (legacy==='css:blank' && !s.cssTpl.blank) s.cur.pageSkin='punch';
    delete s.cur.longPoster; delete s.cur.ratio;
  }
  return s;
}
const clone = o => JSON.parse(JSON.stringify(o || {}));
const cur = () => ctx().extensionSettings[MODULE].cur;
const persist = () => ctx().saveSettingsDebounced();
const toast = (t, m) => window.toastr && window.toastr[t](m);

// Content belongs to the current message, not the previously edited poster.
// Keep pageSkin, font, colors, layout, toggle preferences and saved presets.
// When a different message is opened, discard only the per-post input fields.
const FRESH_POST_FIELDS = [
  'pubTitle','pubKicker','pubAuthor','pubNote','pubDate',
  'postypeChannel','postypeDate','ao3Rating','ao3MetaLines',
  'threadsReplyName','threadsReplyTime','threadsReplyText',
  'threadsReplyAvatarImg','postypeAvatarImg',
  'imessageImage','imessageAvatarImg','skinImg','pubImages',
];
function beginMessageDraft(messageId) {
  const chat = ctx().chat;
  if(st.lastOpenedChat===chat && st.lastOpenedMessageId===messageId)return;
  const p=store().cur;
  for(const key of FRESH_POST_FIELDS){
    const value=BASE[key];
    p[key]=value&&typeof value==='object'?clone(value):(value??'');
  }
  st.lastOpenedChat=chat;
  st.lastOpenedMessageId=messageId;
  persist();
}


// 操作历史：撤销 / 重做只作用于当前海报，不会修改酒馆的原始消息。
function snapshot() {
  return {
    settings: clone(cur()), custom: st.custom, customIsRendered: !!st.customIsRendered,
    holes: clone(st.holes), free: clone(st.free), off: clone(st.off),
    seed: st.seed, fid: st.fid,
  };
}
function updateHistoryButtons() {
  if (!st.ov) return;
  const undo = st.ov.querySelector('[data-act="undo"]');
  const redo = st.ov.querySelector('[data-act="redo"]');
  if (undo) undo.disabled = st.historyIndex <= 0;
  if (redo) redo.disabled = st.historyIndex < 0 || st.historyIndex >= st.history.length - 1;
}
function historyPush(key = '') {
  if (st.historyLock || !st.ov || !isOpen()) return;
  const item = snapshot();
  const last = st.history[st.historyIndex];
  if (last && JSON.stringify(last) === JSON.stringify(item)) return;
  const now = Date.now();
  if (key && key === st.historyLastKey && now - st.historyLastAt < 450 && st.historyIndex > 0 && st.historyIndex === st.history.length - 1) {
    st.history[st.historyIndex] = item;
  } else {
    st.history = st.history.slice(0, st.historyIndex + 1);
    st.history.push(item);
    if (st.history.length > 35) st.history.shift();
    st.historyIndex = st.history.length - 1;
  }
  st.historyLastKey = key; st.historyLastAt = now;
  updateHistoryButtons();
}
function resetHistory() {
  st.history = [snapshot()];
  st.historyIndex = 0;
  st.historyLastKey = ''; st.historyLastAt = 0;
  updateHistoryButtons();
}
function historyTravel(delta) {
  const i = st.historyIndex + delta;
  if (i < 0 || i >= st.history.length) return;
  const item = clone(st.history[i]);
  st.historyLock = true;
  st.historyIndex = i;
  const settings = store();
  settings.cur = item.settings;
  st.custom = item.custom;
  st.customIsRendered = !!item.customIsRendered;
  buildText();
  st.holes = item.holes;
  st.free = item.free;
  st.off = item.off;
  st.seed = item.seed;
  st.fid = item.fid;
  persist();
  syncAll();
  schedule();
  st.historyLastKey = '';
  st.historyLock = false;
  updateHistoryButtons();
}

// 仅改变预览缩放比例，导出尺寸与海报数据保持不变。
function updatePreviewZoom(resetScroll = false) {
  const ov = st.ov;
  if (!ov || !st.canvas) return;
  const stage = ov.querySelector('.pk-stage');
  const cv = st.canvas;
  if (!stage) return;
  const label = ov.querySelector('.pk-zoom-label');
  if (label) label.textContent = st.zoom === 1 ? '适宽' : Math.round(st.zoom * 100) + '%';
  const outBtn = ov.querySelector('[data-act="zoom-out"]');
  const inBtn = ov.querySelector('[data-act="zoom-in"]');
  if (outBtn) outBtn.disabled = st.zoom <= 1;
  if (inBtn) inBtn.disabled = st.zoom >= 3;
  if(cssActive()){cssSize();if(resetScroll){stage.scrollTop=0;stage.scrollLeft=0;}return;}
  const cs = window.getComputedStyle(stage);
  const aw = Math.max(60, stage.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight));
  const base = aw / Math.max(1, st.W || cv.width);
  const zoom = st.editing ? 1 : st.zoom;
  cv.style.setProperty('width', ((st.W || cv.width) * base * zoom).toFixed(1) + 'px', 'important');
  cv.style.setProperty('height', ((st.H || cv.height) * base * zoom).toFixed(1) + 'px', 'important');
  cv.style.maxWidth = 'none'; cv.style.maxHeight = 'none';
  cv.style.touchAction = !st.editing && zoom > 1 ? 'pan-x pan-y' : 'pan-y';
  if (resetScroll) { stage.scrollTop = 0; stage.scrollLeft = 0; }
  if (st.editing) updateEditorBounds();
}
function changeZoom(dir) {
  const levels = [1, 1.35, 1.8, 2.35, 3];
  let i = levels.findIndex(v => Math.abs(v - st.zoom) < 0.01);
  if (i < 0) i = 0;
  const next = dir === 0 ? 1 : levels[Math.max(0, Math.min(levels.length - 1, i + dir))];
  if (next === st.zoom) return;
  const stage = st.ov?.querySelector('.pk-stage');
  const visual=cssActive()?st.ov?.querySelector('.pk-css-holder'):st.canvas;
  const oldH = parseFloat(visual?.style.height) || visual?.getBoundingClientRect().height || 1;
  const oldW = parseFloat(visual?.style.width) || visual?.getBoundingClientRect().width || 1;
  const relativeY = stage ? (stage.scrollTop + stage.clientHeight / 2) / oldH : 0;
  const relativeX = stage ? (stage.scrollLeft + stage.clientWidth / 2) / oldW : 0;
  st.zoom = next;
  updatePreviewZoom(false);
  if (stage) {
    const newH = parseFloat(visual?.style.height) || oldH;
    const newW = parseFloat(visual?.style.width) || oldW;
    stage.scrollTop = Math.max(0, relativeY * newH - stage.clientHeight / 2);
    stage.scrollLeft = Math.max(0, relativeX * newW - stage.clientWidth / 2);
  }
}

const rnd = (i, s) => { const x = Math.sin(i * 12.9898 + s * 78.233) * 43758.5453; return x - Math.floor(x); };
const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const isOpen = () => !!(st.ov && st.ov.classList.contains('show'));
let keyboardRenderPending = false, keyboardRenderTimer = 0;
function schedule(force = false) {
  if (!force && (keyboardIsOpen() || Date.now() < keyboardCoolingUntil)) {
    keyboardRenderPending = true;
    // After the keyboard closes, flush the last deferred preview automatically.
    if (!keyboardIsOpen() && !keyboardRenderTimer) {
      keyboardRenderTimer = setTimeout(() => {
        keyboardRenderTimer = 0;
        if (keyboardRenderPending && !keyboardIsOpen()) schedule(true);
      }, Math.max(20, keyboardCoolingUntil - Date.now() + 16));
    }
    return;
  }
  keyboardRenderPending = false;
  if (rafId) return;
  rafId = requestAnimationFrame(() => { rafId = 0; render(true); updatePreviewZoom(); });
}

const texCache = new Map();
function texCanvas(kind) {
  if (texCache.has(kind)) return texCache.get(kind);
  const N = { crumple: 256, fiber: 128, halftone: 12, grid: 48, dots: 24, lines: 56 }[kind] || 64;
  const c = document.createElement('canvas');
  c.width = c.height = N;
  const q = c.getContext('2d');
  const wrap = fn => { for (const dx of [-N, 0, N]) for (const dy of [-N, 0, N]) { q.save(); q.translate(dx, dy); fn(); q.restore(); } };
  const noise = (n, a) => {
    for (let i = 0; i < n; i++) {
      q.fillStyle = rnd(i, 9) > 0.5 ? `rgba(255,255,255,${a})` : `rgba(0,0,0,${a * 0.7})`;
      q.fillRect(Math.floor(rnd(i, 7) * N), Math.floor(rnd(i, 8) * N), 1, 1);
    }
  };
  if (kind === 'grain') noise(N * N * 0.25, 0.09);
  if (kind === 'linen') {
    for (let i = 0; i < N; i += 4) {
      q.fillStyle = 'rgba(255,255,255,.15)'; q.fillRect(0, i, N, 1.5);
      q.fillStyle = 'rgba(0,0,0,.06)'; q.fillRect(i, 0, 1.5, N);
    }
    noise(260, 0.08);
  }
  if (kind === 'canvas') {
    for (let y = 0; y < N; y += 4) for (let x = 0; x < N; x += 4) {
      q.fillStyle = ((x + y) / 4) % 2 ? 'rgba(0,0,0,.05)' : 'rgba(255,255,255,.09)';
      q.fillRect(x, y, 4, 4);
    }
    noise(500, 0.06);
  }
  if (kind === 'fiber') {
    noise(1200, 0.06);
    for (let i = 0; i < 160; i++) {
      const x = rnd(i, 31) * N, y = rnd(i, 32) * N, a = rnd(i, 33) * Math.PI, l = 4 + rnd(i, 34) * 14;
      const col = rnd(i, 35) > 0.5 ? 'rgba(255,255,255,.18)' : 'rgba(60,40,20,.10)';
      wrap(() => { q.strokeStyle = col; q.lineWidth = 0.7; q.beginPath(); q.moveTo(x, y); q.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); q.stroke(); });
    }
  }
  if (kind === 'crumple') {
    for (let i = 0; i < 46; i++) {
      const x = rnd(i, 41) * N, y = rnd(i, 42) * N, r = 20 + rnd(i, 43) * 80;
      const light = rnd(i, 44) > 0.5, a = 0.04 + rnd(i, 45) * 0.05;
      wrap(() => {
        const gr = q.createRadialGradient(x, y, 0, x, y, r);
        gr.addColorStop(0, light ? `rgba(255,255,255,${a})` : `rgba(0,0,0,${a})`);
        gr.addColorStop(1, 'rgba(0,0,0,0)');
        q.fillStyle = gr; q.fillRect(x - r, y - r, r * 2, r * 2);
      });
    }
    for (let i = 0; i < 9; i++) {
      const x = rnd(i, 51) * N, y = rnd(i, 52) * N, a = rnd(i, 53) * Math.PI, l = 40 + rnd(i, 54) * 120;
      wrap(() => {
        q.lineWidth = 1.2;
        q.strokeStyle = 'rgba(255,255,255,.22)'; q.beginPath(); q.moveTo(x, y); q.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); q.stroke();
        q.strokeStyle = 'rgba(0,0,0,.08)'; q.beginPath(); q.moveTo(x + 1.5, y + 1.5); q.lineTo(x + 1.5 + Math.cos(a) * l, y + 1.5 + Math.sin(a) * l); q.stroke();
      });
    }
    noise(4000, 0.05);
  }
  if (kind === 'grid') { q.fillStyle = 'rgba(0,0,0,.09)'; q.fillRect(0, 0, N, 1); q.fillRect(0, 0, 1, N); }
  if (kind === 'lines') { q.fillStyle = 'rgba(0,0,0,.10)'; q.fillRect(0, N - 1, N, 1); }
  if (kind === 'dots') { q.fillStyle = 'rgba(0,0,0,.18)'; q.beginPath(); q.arc(N / 2, N / 2, 1.4, 0, Math.PI * 2); q.fill(); }
  if (kind === 'halftone') { q.fillStyle = 'rgba(0,0,0,.08)'; q.beginPath(); q.arc(N / 2, N / 2, 2.6, 0, Math.PI * 2); q.fill(); }
  texCache.set(kind, c);
  return c;
}
function texSwatch(kind, color) {
  const c = document.createElement('canvas');
  c.width = c.height = 96;
  const q = c.getContext('2d');
  q.fillStyle = color; q.fillRect(0, 0, 96, 96);
  if (kind !== 'none') { q.fillStyle = q.createPattern(texCanvas(kind), 'repeat'); q.fillRect(0, 0, 96, 96); }
  return c.toDataURL();
}

const imgCache = new Map();
function imgOf(src) {
  if (typeof src!=='string' || !src.trim()) return null;
  src=src.trim();
  let e = imgCache.get(src);
  const now=Date.now();
  // A network error is not permanent: retry on a later render, but never
  // retry every animation frame for an invalid URL.
  if (e && e.failedAt && now-e.failedAt>=30000) imgCache.delete(src), e=null;
  if (!e) {
    e = { img: new Image(), ok: false, failedAt: 0 };
    if (!src.startsWith('data:')) e.img.crossOrigin = 'anonymous';
    e.img.onload = () => { e.ok = true; e.failedAt = 0; if (isOpen()) schedule(); };
    e.img.onerror = () => { e.failedAt = Date.now(); toast('warning', '图片加载失败（链接无效或不允许跨域）'); };
    e.img.src = src;
    imgCache.set(src, e);
    while(imgCache.size>18) imgCache.delete(imgCache.keys().next().value);
  }
  return e.ok ? e.img : null;
}

const GF = 'https://fonts.googleapis.com/css2?display=swap&family=';
const ZF = id => `https://fontsapi.zeoseven.com/${id}/main/result.css`;
// Curated reading/poster fonts. Previous IDs stay below as hidden options,
// so templates saved in older versions continue to render unchanged.
const FONTS = {
  songti: { name: '宋体', stack: '"Songti SC","STSong","Noto Serif SC","Source Han Serif SC",serif' },
  kinghwa: { name: '京华老宋', fam: 'KingHwaOldSong', css: ZF(309), stack: '"KingHwaOldSong","Songti SC",serif' },
  huiwen: { name: '汇文明朝', fam: 'Huiwen-mincho', css: ZF(256), stack: '"Huiwen-mincho","Songti SC",serif' },
  zhuque: { name: '朱雀仿宋', fam: 'Zhuque Fangsong (technical preview)', css: ZF(7), stack: '"Zhuque Fangsong (technical preview)","STFangsong","Songti SC",serif' },
  clearsong: { name: '屏显臻宋', fam: 'Clear Han Serif', css: ZF(79), stack: '"Clear Han Serif","Songti SC",serif' },
  chillhuo: { name: '寒蝉活宋', fam: 'ChillHuoSong_F', css: ZF(875), stack: '"ChillHuoSong_F","Songti SC",serif' },
  notoserif: { name: '思源宋体', fam: 'Noto Serif SC', css: GF + 'Noto+Serif+SC:wght@400', stack: '"Noto Serif SC",serif' },
  heiti: { name: '黑体', stack: '"PingFang SC","Heiti SC","Noto Sans SC","Microsoft YaHei",sans-serif' },
  notosans: { name: '思源黑体', fam: 'Noto Sans SC', css: GF + 'Noto+Sans+SC:wght@400', stack: '"Noto Sans SC",sans-serif' },
  taipei: { name: '台北黑体', fam: 'Taipei Sans TC Beta', css: ZF(2112), stack: '"Taipei Sans TC Beta","PingFang TC",sans-serif' },
  kaiti: { name: '楷体', stack: '"Kaiti SC","STKaiti","KaiTi",serif' },
  wenkai: { name: '霞鹜文楷', fam: 'LXGW WenKai', css: 'https://cdn.jsdelivr.net/npm/lxgw-wenkai-webfont@1.7.0/style.css', stack: '"LXGW WenKai",serif' },
  yuangu: { name: '源古宋体', fam: 'YuanGuSong-TGC Book', css: ZF(612), stack: '"YuanGuSong-TGC Book","Songti SC",serif' },
  jinshu: { name: '寒蝉锦书宋', fam: '寒蝉锦书宋', css: ZF(2245), stack: '"寒蝉锦书宋","Songti SC",serif' },
  nano: { name: '纳米老宋', fam: 'NanoOldSong-A', css: ZF(467), stack: '"NanoOldSong-A","Songti SC",serif' },
  siyin: { name: '思印宋', fam: 'SiyinSong', css: ZF(892), stack: '"SiyinSong","Songti SC",serif' },
  duanhei: { name: '寒蝉端黑宋', fam: '寒蝉端黑宋Pro', css: ZF(366), stack: '"寒蝉端黑宋Pro","Songti SC",serif' },
  xinzhisong: { name: '霞鹜新致宋', fam: 'LXGW Neo ZhiSong', css: ZF(22), stack: '"LXGW Neo ZhiSong","Songti SC",serif' },
  huifang: { name: '汇文仿宋', fam: 'Huiwen-Fangsong', css: ZF(440), stack: '"Huiwen-Fangsong","STFangsong",serif' },
  huizheng: { name: '汇文正楷', fam: 'Huiwen-ZhengKai', css: ZF(438), stack: '"Huiwen-ZhengKai","STKaiti",serif' },
  coopkai: { name: '汇迹正楷', fam: 'CooperZhengKai', css: ZF(482), stack: '"CooperZhengKai","STKaiti",serif' },
  chillkai: { name: '寒蝉正楷', fam: 'ChillKai', css: ZF(5), stack: '"ChillKai","STKaiti",serif' },
  zhuokai: { name: '寒蝉拙楷', fam: '寒蝉拙楷体 R', css: ZF(2239), stack: '"寒蝉拙楷体 R","STKaiti",serif' },
  zhenkai: { name: '霞鹜臻楷', fam: 'LXGW ZhenKai GB', css: ZF(2), stack: '"LXGW ZhenKai GB","STKaiti",serif' },
  neoxihei: { name: '霞鹜新晰黑', fam: 'LXGW Neo XiHei', css: ZF(19), stack: '"LXGW Neo XiHei","PingFang SC",sans-serif' },
  yunmo: { name: '寒蝉云墨黑', fam: '寒蝉云墨黑B Medium', css: ZF(2254), stack: '"寒蝉云墨黑B Medium","PingFang SC",sans-serif' },
  jiangyuan: { name: '江城圆体', fam: 'JiangChengYuanTi', css: ZF(59), stack: '"JiangChengYuanTi","PingFang SC",sans-serif' },
  chillround: { name: '寒蝉全圆', fam: '寒蝉全圆体', css: ZF(3), stack: '"寒蝉全圆体","PingFang SC",sans-serif' },
  chillsemi: { name: '寒蝉半圆', fam: '寒蝉半圆体', css: ZF(243), stack: '"寒蝉半圆体","PingFang SC",sans-serif' },
  deyi: { name: '得意黑', fam: 'Smiley Sans Oblique', css: ZF(92), stack: '"Smiley Sans Oblique","PingFang SC",sans-serif' },
    upload: { name: '上传字体' },
  // Older saved templates may reference these keys; keep their definitions.
  xiaowei: { name: '站酷小薇', fam: 'ZCOOL XiaoWei', css: GF + 'ZCOOL+XiaoWei', stack: '"ZCOOL XiaoWei",serif', hidden: true },
  mashan: { name: '马善政', fam: 'Ma Shan Zheng', css: GF + 'Ma+Shan+Zheng', stack: '"Ma Shan Zheng",cursive', hidden: true },
  longcang: { name: '龙藏体', fam: 'Long Cang', css: GF + 'Long+Cang', stack: '"Long Cang",cursive', hidden: true },
  kuaile: { name: '快乐体', fam: 'ZCOOL KuaiLe', css: GF + 'ZCOOL+KuaiLe', stack: '"ZCOOL KuaiLe",sans-serif', hidden: true },
  notoseriftc: { name: '繁体明体', fam: 'Noto Serif TC', css: GF + 'Noto+Serif+TC:wght@400', stack: '"Noto Serif TC","Songti TC",serif', hidden: true },
  notosanstc: { name: '繁体黑体', fam: 'Noto Sans TC', css: GF + 'Noto+Sans+TC:wght@400', stack: '"Noto Sans TC","PingFang TC",sans-serif', hidden: true },
  qingke: { name: '青刻黄油', fam: 'ZCOOL QingKe HuangYou', css: GF + 'ZCOOL+QingKe+HuangYou', stack: '"ZCOOL QingKe HuangYou",sans-serif', hidden: true },
  zhigmang: { name: '志莽行书', fam: 'Zhi Mang Xing', css: GF + 'Zhi+Mang+Xing', stack: '"Zhi Mang Xing",cursive', hidden: true },
  liujian: { name: '毛草体', fam: 'Liu Jian Mao Cao', css: GF + 'Liu+Jian+Mao+Cao', stack: '"Liu Jian Mao Cao",cursive', hidden: true },
  notoserifhk: { name: '港式明体', fam: 'Noto Serif HK', css: GF + 'Noto+Serif+HK:wght@400', stack: '"Noto Serif HK","Songti TC",serif', hidden: true },
};
// Each font appears in only its most useful groups; saved font keys remain supported.
const FONT_CATS = {
  常用: ['songti','kinghwa','huiwen','notoserif','heiti','notosans','kaiti','wenkai','upload'],
  宋明: ['songti','kinghwa','huiwen','yuangu','jinshu','nano','siyin','duanhei','clearsong','chillhuo','xinzhisong','notoserif'],
  楷仿: ['kaiti','wenkai','zhuque','huifang','huizheng','coopkai','chillkai','zhuokai','zhenkai'],
  黑圆: ['heiti','notosans','taipei','neoxihei','yunmo','jiangyuan','chillround','chillsemi','deyi'],
};
function fontCategory(ov, cat) {
  if (!ov) return;
  const keys = new Set(FONT_CATS[cat] || FONT_CATS.常用);
  ov.querySelectorAll('[data-fontcat]').forEach(b => b.classList.toggle('on', b.dataset.fontcat === cat));
  ov.querySelectorAll('.pk-fonts [data-font]').forEach(b => { b.hidden = !keys.has(b.dataset.font); });
}

// Wait until the remote CSS has arrived before trying to load its font-face.
// On iOS, initiating document.fonts.load before the stylesheet exists can
// report empty results, leaving a silent serif fallback in the export.
const fontReady = new Set();
const fontPending = new Set();
function ensureFont(f, text) {
  if (!f?.css || !f.fam) return;
  const sample = (text || '字').slice(0, 160);
  const key = f.fam + '|' + sample;
  if (fontReady.has(key) || fontPending.has(key)) return;
  let link = [...document.querySelectorAll('link[data-pkfont]')].find(l => l.dataset.pkfont === f.fam);
  const load = () => {
    if (fontReady.has(key) || fontPending.has(key)) return;
    fontPending.add(key);
    document.fonts.load(`40px "${f.fam}"`, sample).then(faces => {
      if (faces.length) {
        fontReady.add(key);
        if (isOpen()) schedule();
      }
    }).catch(() => {}).finally(() => { fontPending.delete(key); });
  };
  if (!link) {
    link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = f.css;
    link.dataset.pkfont = f.fam;
    link.addEventListener('load', () => { link.dataset.loaded = '1'; load(); }, { once: true });
    document.head.appendChild(link);
  } else if (link.dataset.loaded === '1') load();
  else link.addEventListener('load', load, { once: true });
}
const fontUp = { ok: false, loading: false };
function idb(mode, fn) {
  return new Promise((res,rej)=>{
    const rq=window.indexedDB.open('pk-poster',1);
    rq.onupgradeneeded=()=>{
      if(!rq.result.objectStoreNames.contains('f'))rq.result.createObjectStore('f');
    };
    rq.onerror=()=>rej(rq.error);
    rq.onsuccess=()=>{
      const db=rq.result;
      let tx;
      try{
        tx=db.transaction('f',mode);
        const request=fn(tx.objectStore('f'));
        tx.oncomplete=()=>{db.close();res(request?.result);};
        tx.onerror=()=>{db.close();rej(tx.error);};
        tx.onabort=()=>{db.close();rej(tx.error||new Error('字体存储中断'));};
      }catch(error){db.close();rej(error);}
    };
  });
}

async function useFontBuffer(buf) {
  const f = await new FontFace('PKUploadFont', buf).load();
  document.fonts.add(f);
  fontUp.ok = true;
}
function loadUploadFont() {
  if (fontUp.ok || fontUp.loading) return;
  fontUp.loading = true;
  idb('readonly', s => s.get('font')).then(buf => buf && useFontBuffer(buf)).then(() => { if (isOpen()) schedule(); })
    .catch(() => { }).finally(() => { fontUp.loading = false; });
}
function fontStack(p) {
  const base = FONTS.songti.stack;
  if (p.fontKey === 'upload') {
    loadUploadFont();
    return fontUp.ok ? `"PKUploadFont",${base}` : base;
  }
  const f = FONTS[p.fontKey] || FONTS.songti;
  ensureFont(f, [...new Set(st.chars)].join('') + sigLines(p).join(''));
  return f.stack;
}

function drawCover(g, img, x, y, w, h, scale = 1, posX = 50, posY = 50) {
  if (!img.width || !img.height || !w || !h) return;
  // Default scale=1 / position=50 matches the old centered cover behavior.
  const cover = Math.max(w / img.width, h / img.height);
  const z = Math.min(3, Math.max(0.5, +scale || 1));
  const iw = img.width * cover * z, ih = img.height * cover * z;
  const ax = Math.min(1, Math.max(0, (+posX || 0) / 100));
  const ay = Math.min(1, Math.max(0, (+posY || 0) / 100));
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
  g.drawImage(img, x + (w - iw) * ax, y + (h - ih) * ay, iw, ih);
  g.restore();
}

function fillLayer(g, x, y, w, h, color, tex, img, imageStyle) {
  g.fillStyle = color; g.fillRect(x, y, w, h);
  if (img) drawCover(g, img, x, y, w, h,
    imageStyle?.scale ?? 1, imageStyle?.x ?? 50, imageStyle?.y ?? 50);
  if (tex && tex !== 'none') { g.fillStyle = g.createPattern(texCanvas(tex), 'repeat'); g.fillRect(x, y, w, h); }
}

const SVG_SHAPES = {
  diamond: 'M50 2 L98 50 L50 98 L2 50 Z',
  triangle: 'M50 4 L97 94 L3 94 Z',
  heart: 'M50 92 C20 72 2 54 2 33 C2 16 15 5 29 5 C39 5 46 11 50 19 C54 11 61 5 71 5 C85 5 98 16 98 33 C98 54 80 72 50 92 Z',
  drop: 'M50 2 C58 18 86 44 86 64 C86 84 70 98 50 98 C30 98 14 84 14 64 C14 44 42 18 50 2 Z',
  moon: 'M62 4 A46 46 0 1 0 96 70 A38 38 0 1 1 62 4 Z',
  cloud: 'M26 82 C12 82 2 72 2 59 C2 47 11 38 23 37 C25 22 37 11 52 11 C65 11 76 19 80 31 C91 33 98 43 98 55 C98 70 87 82 73 82 Z',
  bird: 'M2 38 C18 28 36 30 50 52 C64 30 82 28 98 38 C84 37 70 44 57 62 L50 72 L43 62 C30 44 16 37 2 38 Z',
  maple: 'M50 2 L58 18 L67 13 L64 33 L82 22 L79 34 L97 37 L85 48 L92 55 L69 61 L71 69 L53 64 L52 98 L48 98 L47 64 L29 69 L31 61 L8 55 L15 48 L3 37 L21 34 L18 22 L36 33 L33 13 L42 18 Z',
  butterfly: 'M50 32 C40 6 4 2 4 26 C4 44 28 48 45 50 C29 53 10 62 17 80 C24 98 45 82 50 62 C55 82 76 98 83 80 C90 62 71 53 55 50 C72 48 96 44 96 26 C96 2 60 6 50 32 Z',
};
const SHAPES = [
  ['rough', '毛边'], ['rect', '方'], ['round', '圆角'], ['circle', '圆'], ['torn', '撕纸'], ['shred', '碎撕'],
  ['diamond', '菱形'], ['triangle', '三角'], ['star', '星'], ['heart', '心'],
  ['drop', '水滴'], ['moon', '月亮'], ['cloud', '云'], ['flower', '花'], ['bird', '飞鸟'],
  ['maple', '枫叶'], ['butterfly', '蝴蝶'],
];
const baseCache = new Map();
function basePath(name) {
  if (baseCache.has(name)) return baseCache.get(name);
  let p;
  if (name === 'star') {
    let d = '';
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? 20 : 48;
      d += (i ? 'L' : 'M') + (50 + Math.cos(a) * r).toFixed(1) + ' ' + (52 + Math.sin(a) * r).toFixed(1) + ' ';
    }
    p = new Path2D(d + 'Z');
  } else if (name === 'flower') {
    p = new Path2D();
    for (let i = 0; i < 5; i++) {
      const a = -Math.PI / 2 + i * Math.PI * 2 / 5, cx = 50 + Math.cos(a) * 24, cy = 52 + Math.sin(a) * 24;
      p.moveTo(cx + 24, cy); p.arc(cx, cy, 24, 0, Math.PI * 2);
    }
  } else p = new Path2D(SVG_SHAPES[name] || SVG_SHAPES.diamond);
  baseCache.set(name, p);
  return p;
}
function shapePath(shape, x, y, w, h, k) {
  const P = new Path2D();
  if (shape === 'rect') { P.rect(x, y, w, h); return P; }
  if (shape === 'circle') { P.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2); return P; }
  if (shape === 'round') {
    const r = Math.min(w, h) * 0.25;
    P.moveTo(x + r, y); P.arcTo(x + w, y, x + w, y + h, r); P.arcTo(x + w, y + h, x, y + h, r);
    P.arcTo(x, y + h, x, y, r); P.arcTo(x, y, x + w, y, r); P.closePath(); return P;
  }
  if (shape === 'torn' || shape === 'shred') {
    const dense = shape === 'shred';
    const n = dense ? 10 : 6;
    const edge = dense ? 0.22 : 0.12;
    const drift = dense ? 0.08 : 0.035;
    const pts = [];
    const pushEdge = (fx, fy, ex, ey, seedA, seedB) => {
      for (let t = 0; t < n; t++) {
        const u = t / n;
        const nx = fx + (ex - fx) * u;
        const ny = fy + (ey - fy) * u;
        const px = nx + (rnd(k * 41 + t, seedA) - 0.5) * drift;
        const py = ny + (rnd(k * 43 + t, seedB) - 0.5) * drift;
        const ox = ex === fx ? ((nx < .5 ? -1 : 1) * rnd(k * 47 + t, seedA + 10) * edge) : 0;
        const oy = ey === fy ? ((ny < .5 ? -1 : 1) * rnd(k * 53 + t, seedB + 10) * edge) : 0;
        pts.push([px + ox, py + oy]);
        if (dense && t < n - 1 && rnd(k * 59 + t, seedA + seedB) > 0.55) {
          const notch = 0.05 + rnd(k * 61 + t, seedA + 20) * 0.09;
          const tx = ex === fx ? px + ox * 0.2 + (nx < .5 ? notch : -notch) : px + (rnd(k * 67 + t, seedA + 30) - 0.5) * 0.05;
          const ty = ey === fy ? py + oy * 0.2 + (ny < .5 ? notch : -notch) : py + (rnd(k * 71 + t, seedB + 30) - 0.5) * 0.05;
          pts.push([tx, ty]);
        }
      }
    };
    pushEdge(0, 0, 1, 0, 1, 2);
    pushEdge(1, 0, 1, 1, 3, 4);
    pushEdge(1, 1, 0, 1, 5, 6);
    pushEdge(0, 1, 0, 0, 7, 8);
    pts.forEach(([a, b], i) => { const px = x + w * a, py = y + h * b; i ? P.lineTo(px, py) : P.moveTo(px, py); });
    P.closePath();
    if (dense) {
      const extra = 1 + Math.floor(rnd(k, 91) * 2);
      for (let e = 0; e < extra; e++) {
        const sx = x + (0.05 + rnd(k + e, 92) * 0.9) * w;
        const sy = y + (0.05 + rnd(k + e, 93) * 0.9) * h;
        const sw = w * (0.12 + rnd(k + e, 94) * 0.16);
        const sh = h * (0.1 + rnd(k + e, 95) * 0.15);
        const Q = new Path2D();
        const m = 5;
        for (let i = 0; i < m; i++) {
          const a = -Math.PI / 2 + i * (Math.PI * 2 / m);
          const rr = 0.35 + rnd(k + e * 3 + i, 96) * 0.28;
          const px = sx + Math.cos(a) * sw * rr;
          const py = sy + Math.sin(a) * sh * rr;
          i ? Q.lineTo(px, py) : Q.moveTo(px, py);
        }
        Q.closePath();
        P.addPath(Q);
      }
    }
    return P;
  }
  if (shape === 'rough') {
    const m = 0.05;
    [[0, 0], [1, 0], [1, 1], [0, 1]].forEach(([a, b], i) => {
      const px = x + w * (a + (a ? -1 : 1) * rnd(k * 7 + i, 21) * m);
      const py = y + h * (b + (b ? -1 : 1) * rnd(k * 7 + i, 22) * m);
      i ? P.lineTo(px, py) : P.moveTo(px, py);
    });
    P.closePath(); return P;
  }
  P.addPath(basePath(shape), new DOMMatrix([w / 100, 0, 0, h / 100, x, y]));
  return P;
}

function spacedText(g, text, x, y, sp, align) {
  const cs = Array.from(text), ws = cs.map(c => g.measureText(c).width);
  const total = ws.reduce((a, b) => a + b, 0) + sp * (cs.length - 1);
  let sx = align === 'right' ? x - total : align === 'center' ? x - total / 2 : x;
  g.textAlign = 'left';
  cs.forEach((c, i) => { g.fillText(c, sx, y); sx += ws[i] + sp; });
}

function names() {
  const c = ctx();
  return { user: c.name1 || '', char: (!st.isUser && st.speaker) || c.name2 || '' };
}

// 本地繁简字形对应表（ICU Traditional-Simplified 单字映射），不联网。
const ZH_MAP_FROM = "㑳㘚㠏㠣㥮㩜㩳㼆䃮䊷䋙䋻䓣䝼䡵䥑䥕䬗䮄䯀䰾䱽䲁䲘䴉䶧丟並乾亂亙亞佇佈佔併來侖侶侷俁係俔俠俬俱倀倆倈倉個們倖倣倫偉側偵偽傑傖傘備傢傭傯傳傴債傷傾僂僅僇僉僑僕僞僤僥僨僱價儀儂億儈儉儐儔儕儘償優儲儷儸儺儻儼兇兌兒兗內兩冊冪凈凍凜凱別刪剄則剋剎剗剛剝剮剴創剷劃劇劉劊劌劍劏劑劚勁動勗務勛勝勞勢勣勩勱勳勵勸勻匭匯匱區協卹卻厙厠厭厲厴參叄叢吒吢吳吶呂咷咼員唄唚唸問啓啞啟啢喎喚喨喪喫喬單喲嗆嗇嗊嗎嗚嗩嗶嘆嘍嘔嘖嘗嘜嘩嘮嘯嘰嘵嘸嘽噁噓噚噝噠噥噦噯噲噴噸噹嚀嚇嚌嚐嚕嚙嚥嚦嚨嚮嚲嚳嚴嚶囀囁囂囅囈囉囍囑囓囪圇國圍園圓圖團垵埡埨埰執堅堊堖堝堯報場塊塋塏塒塗塚塢塤塵塸塹塿墊墜墠墮墳墶墻墾壇壋壎壓壘壙壚壜壞壟壠壢壩壪壯壺壼壽夠夢夥夾奐奧奩奪奬奮奼妝姊姍姦姪娙娛婁婦婭媧媯媼媽嫋嫗嫵嫻嫿嬀嬃嬈嬋嬌嬙嬝嬡嬤嬪嬰嬸孃孌孫學孿宮寢實寧審寫寬寵寶尅將專尋對導尷屆屍屓屜屢層屨屬岡峴島峽崍崑崗崙崢崬嵐嵽嶁嶄嶇嶔嶗嶠嶢嶧嶨嶮嶴嶸嶺嶼巋巒巔巖巘巰帥師帳帶幀幃幗幘幟幣幫幬幹幾庫廁廂廄廈廎廚廝廞廟廠廡廢廣廩廬廳廻弒弔弳張強彄彆彈彌彎彙彞彠彥彿後徑從徠復徬徵徹恆恥悅悞悳悵悶悽惡惱惲惻愛愜愨愴愷愾慄慇態慍慘慚慟慣慤慪慫慮慳慶慼慾憂憊憐憑憒憖憚憤憫憮憲憶懃懇應懌懍懞懟懣懨懮懲懶懷懸懺懼懾戀戇戔戧戩戰戱戲戶拋挩挾捨捫捲掃掄掗掙掛採揀揚換揮搆損搖搗搥搧搨搵搶搾摀摑摜摟摯摳摶摺摻撈撏撐撓撚撝撟撢撣撥撫撲撳撻撾撿擁擄擇擊擋擓擔據擠擣擬擯擰擱擲擴擷擺擻擼擾攄攆攏攔攖攙攛攜攝攢攣攤攪攬敗敘敵數斂斃斆斕斬斷於昇時晉晛晝暈暉暐暘暢暫暱曄曆曇曉曏曖曠曨曬書會朧東枒柵桿梔梘梜條梟梲棄棖棗棟棡棧棲棶椏楊楓楨業極榖榪榮榲榿構槍槓槖槤槧槨槳樁樂樅樑樓標樞樣樸樹樺橈橋機橢橫檁檉檔檜檝檟檢檣檮檯檳檸檻櫃櫍櫓櫚櫛櫝櫞櫟櫥櫧櫨櫪櫫櫬櫱櫳櫸櫺櫻欄權欏欒欓欖欞欵欽歎歐歛歟歡歲歷歸歿殘殞殤殨殫殮殯殰殲殺殼毀毆毬毿氂氈氌氣氫氬氳氹氾汎汙決沍沒沖況洩洶浹浿涇涼淒淚淥淨淪淵淶淺渙減渢渦測渾湊湋湞湧湯溈準溝溫溮溳溼滄滅滌滎滬滯滲滷滸滻滾滿漁漊漍漚漢漣漬漲漵漸漿潁潑潔潕潙潛潤潯潰潷潿澀澆澇澐澗澠澤澦澩澫澮澱濁濃濆濕濘濚濜濟濤濫濬濰濱濺濼濾瀂瀅瀆瀇瀉瀋瀏瀕瀘瀝瀟瀠瀦瀧瀨瀰瀲瀾灃灄灑灕灘灝灠灣灤灧災為烏烴無煉煒煙煢煥煩煬煱熅熒熗熰熱熲熾燀燁燄燈燉燐燒燖燙燜營燦燬燭燴燶燻燼燾燿爍爐爛爭爲爺爾牀牆牋牘牽犖犢犧狀狹狽猙猶猻獁獃獄獅獎獨獪獫獮獰獱獲獵獷獸獺獻獼玀現琺琿瑋瑒瑣瑤瑩瑪瑯瑲璉璊璕璗璡璣璦璫環璵璽瓅瓊瓏瓔瓚瓛甌甕產産畝畢畫異當疇疊痀痙痠痾瘂瘋瘍瘓瘞瘡瘧瘮瘲瘺瘻療癆癇癉癒癘癟癡癢癤癥癧癩癬癭癮癰癱癲發皁皚皰皸皺盃盜盞盡監盤盧盪眞眥眾睍睏睜睞睪瞇瞘瞜瞞瞭瞶瞼矓矚矯砲硏硜硤硨硯碩碭碸確碼磑磚磣磧磯磽磾礄礆礎礐礙礡礦礪礫礬礮礱祕祿禍禎禕禡禦禪禮禰禱禿秈稅稈稏稜稟種稱穀穇穌積穎穠穡穢穩穫穭窩窪窮窯窵窶窺竄竅竇竈竊竪競筆筍筧筴箇箋箎箏箝節範築篋篔篢篤篩篳簀簆簍簞簡簣簫簷簹簽簾籃籌籐籙籛籜籟籠籤籩籪籬籮籲粧粵糝糞糧糰糲糴糶糹糾紀紂紃約紅紆紇紈紉紋納紐紓純紕紖紗紘紙級紛紜紝紞紡紬紮細紱紲紳紵紹紺紼紿絀終絃組絅絆絎結絕絛絝絞絡絢給絨絪絰統絲絳絶絹絺綁綃綄綆綈綉綌綎綏綐綑經綖綜綝綞綠綡綢綣綧綪綫綬維綯綰綱網綳綴綵綸綹綺綻綽綾綿緄緇緊緋緑緒緓緔緗緘緙線緝緞締緡緣緦編緩緬緯緱緲練緶緹緻縈縉縊縋縐縑縕縗縛縝縞縟縣縧縫縭縮縯縱縲縳縴縵縶縷縹總績繃繅繆繒織繕繚繞繡繢繩繪繫繭繮繯繰繳繶繸繹繻繼繽繾繿纁纆纈纊續纍纏纓纔纕纖纘纜缽罃罈罌罎罣罰罵罷羅羆羈羋羣羥羨義羶習翫翬翹翺翽耬耮聖聞聯聰聲聳聵聶職聹聽聾肅脅脈脛脣脫脹腎腖腡腦腫腳腸膃膕膚膞膠膢膩膽膾膿臉臍臏臘臚臟臠臢臥臨臺與興舉舊舖艙艤艦艫艱艷芻苎苧茲荊荳莊莖莢莧菓華菸萇萊萬萵葉葒著葤葦葯葷蒍蒐蒓蒔蒞蒼蓀蓆蓋蓮蓯蓽蔄蔔蔞蔣蔥蔦蔭蔴蔿蕁蕆蕎蕒蕓蕕蕘蕢蕩蕪蕭蕷薀薈薊薌薑薔薘薟薦薩薳薴薺藉藍藎藝藥藪藭藴藶藷藹藺蘀蘄蘆蘇蘊蘋蘚蘞蘢蘭蘺蘿虆虉處虛虜號虧虯蛺蛻蜆蝀蝕蝟蝦蝨蝸螄螞螢螮螻螿蟄蟈蟎蟣蟬蟯蟲蟶蟻蠅蠆蠍蠐蠑蠔蠟蠣蠧蠨蠱蠶蠻衆衊術衚衛衝袞袴裊裏補裝裡製複褌褘褲褳褸褻襀襇襏襖襝襠襤襪襬襯襲襴覈見覎規覓視覘覡覥覦親覬覯覲覷覺覽覿觀觴觶觸訁訂訃計訊訌討訏訐訒訓訕訖託記訛訝訟訢訣訥訩訪設許訴訶診註証詁詆詎詐詒詔評詖詗詘詛詝詞詠詡詢詣試詩詪詫詬詭詮詰話該詳詵詷詼詿誄誅誆誇誌認誑誒誕誘誚語誠誡誣誤誥誦誨說説誰課誶誹誼誾調諂諄談諉請諍諏諑諒諓論諗諛諜諝諞諟諡諢諤諦諧諫諭諮諱諲諳諴諶諷諸諺諼諾謀謁謂謄謅謊謎謏謐謔謖謗謙謚講謝謠謡謨謫謬謭謳謹謾譁譅證譎譏譓譖識譙譚譜譞譟譫譯議譴護譸譽譾讀變讋讌讎讒讓讕讖讚讜讞豈豎豐豔豬豶貍貓貙貝貞貟負財貢貧貨販貪貫責貯貰貲貳貴貶買貸貺費貼貽貿賀賁賂賃賄賅資賈賊賑賒賓賕賙賚賜賞賠賡賢賣賤賦賧質賫賬賭賰賴賵賸賺賻購賽賾贄贅贇贈贊贋贍贏贐贓贔贖贗贛贜赬趕趙趨趲跡跤跼踐踡踰踴蹌蹕蹟蹣蹤蹧蹺躂躉躊躋躍躑躒躓躕躚躡躥躦躪軀車軋軌軍軏軑軒軔軛軝軟軤軫軲軸軹軺軻軼軾較輄輅輇輈載輊輋輒輓輔輕輗輛輜輝輞輟輥輦輩輪輬輮輯輳輶輸輻輾輿轀轂轄轅轆轉轍轎轔轝轟轡轢轤辦辭辮辯農迴逕這連週進遊運過達違遙遜遞遠適遯遲遷選遺遼邁還邇邊邏邐郟郵鄆鄉鄒鄔鄖鄧鄩鄭鄰鄲鄳鄴鄶鄺酇酈醃醖醜醞醫醬醱醲醼釀釁釃釅釋釐釒釓釔釕釗釘釙針釣釤釦釧釩釴釵釷釹釺釿鈀鈁鈃鈄鈇鈈鈉鈍鈎鈐鈑鈒鈔鈕鈞鈣鈥鈦鈧鈮鈰鈳鈴鈷鈸鈹鈺鈽鈾鈿鉀鉅鉈鉉鉊鉋鉍鉑鉕鉗鉚鉛鉝鉞鉢鉤鉥鉦鉧鉨鉬鉭鉮鉶鉷鉸鉺鉻鉿銀銃銅銈銍銑銓銖銘銚銛銜銠銣銥銦銨銩銪銫銬銱銲銳銶銷銹銻銼鋁鋃鋅鋇鋌鋏鋐鋒鋗鋙鋝鋟鋣鋤鋥鋦鋨鋩鋪鋭鋮鋯鋰鋱鋶鋸鋹鋼錀錁錄錆錇錈錏錐錒錕錘錙錚錛錞錟錠錡錢錤錦錨錩錫錮錯録錳錶錸鍀鍁鍃鍆鍇鍈鍊鍋鍍鍔鍘鍚鍛鍠鍤鍥鍩鍬鍭鍰鍵鍶鍺鍾鎂鎄鎇鎊鎓鎔鎖鎗鎘鎚鎛鎝鎡鎢鎣鎦鎧鎩鎪鎬鎮鎰鎲鎳鎵鎶鎸鎿鏃鏇鏈鏌鏍鏏鏐鏑鏗鏘鏜鏝鏞鏟鏡鏢鏤鏨鏰鏵鏷鏹鏺鏻鏽鐃鐄鐇鐋鐍鐏鐐鐒鐓鐔鐘鐙鐝鐠鐦鐧鐨鐩鐫鐮鐯鐲鐳鐵鐶鐸鐺鐽鐿鑄鑈鑊鑌鑑鑒鑔鑕鑞鑠鑣鑥鑪鑭鑰鑱鑲鑷鑹鑼鑽鑾鑿钁長門閂閃閆閈閉開閌閎閏閑閒間閔閘閡関閣閥閧閨閩閫閬閭閱閲閶閹閻閼閽閾閿闃闆闇闈闉闊闋闌闍闐闑闒闓闔闕闖闘關闞闠闡闢闤闥阨阪陘陝陞陣陰陳陸陽隄隉隊階隑隕際隤隨險隮隱隴隸隻雋雖雙雛雜雞離難雲電霑霢霧霽靂靄靆靈靉靚靜靦靨靷鞀鞏鞝鞽韁韃韉韋韌韍韓韙韜韞韡韮韻響頁頂頃項順頇須頊頌頍頎頏預頑頒頓頔頗領頜頠頡頤頦頫頭頮頰頲頴頵頷頸頹頻頽顆題額顎顏顒顓顔顗願顙顛類顢顥顧顫顬顯顰顱顳顴風颭颮颯颱颳颶颸颺颻颼飀飄飆飈飛飠飢飣飥飩飪飫飭飯飲飴飼飽飾飿餃餄餅餉養餌餎餏餑餒餓餕餖餗餘餚餛餜餞餡館餬餱餳餵餶餷餺餼餽餾餿饁饃饅饈饉饊饋饌饑饒饗饘饜饞饢馬馭馮馱馳馴馹馼駁駃駉駐駑駒駓駔駕駘駙駛駝駟駡駢駪駭駰駱駸駼駿騁騂騄騅騊騌騍騎騏騑騖騙騞騠騤騧騫騭騮騰騱騵騶騷騸騾驀驁驂驃驄驅驊驌驍驎驏驕驗驚驛驟驢驤驥驦驪驫骯髏髒體髕髖髮鬀鬆鬍鬚鬢鬥鬧鬨鬩鬭鬮鬱鬹魎魘魚魛魢魨魯魴魷魺鮀鮁鮃鮆鮈鮊鮋鮍鮎鮐鮑鮒鮓鮚鮜鮝鮞鮟鮠鮡鮣鮦鮪鮫鮭鮮鮳鮶鮸鮺鯀鯁鯇鯉鯊鯒鯔鯕鯖鯛鯝鯡鯢鯤鯧鯨鯪鯫鯰鯴鯷鯻鯽鯿鰁鰂鰃鰆鰈鰉鰊鰍鰏鰐鰒鰓鰜鰟鰠鰣鰤鰥鰧鰨鰩鰭鰮鰱鰲鰳鰵鰶鰷鰹鰺鰻鰼鰾鱀鱂鱅鱇鱈鱉鱒鱔鱖鱗鱘鱚鱝鱟鱠鱣鱤鱧鱨鱭鱯鱲鱷鱸鱺鳥鳧鳩鳬鳲鳳鳴鳶鳾鴆鴇鴉鴒鴕鴛鴝鴞鴟鴣鴦鴨鴯鴰鴴鴷鴻鴿鵁鵂鵃鵏鵐鵑鵒鵓鵜鵝鵟鵠鵡鵪鵬鵮鵯鵲鵷鵾鶄鶇鶉鶊鶓鶖鶘鶚鶠鶡鶥鶩鶪鶬鶯鶱鶲鶴鶹鶺鶻鶼鷀鷁鷂鷄鷈鷊鷓鷖鷗鷙鷚鷟鷥鷦鷫鷭鷯鷲鷳鷸鷹鷺鷽鷿鸂鸇鸌鸏鸑鸕鸘鸚鸛鸝鸞鹵鹹鹺鹼鹽麗麤麥麩麯麴麵麼麽黃黌點黨黲黴黶黷黽黿鼇鼈鼉鼕鼴齊齋齎齏齒齔齕齗齘齙齜齟齠齡齣齦齧齩齪齬齮齯齲齶齷齼龍龎龐龑龔龕龜𡑍𥗽𨧀𨨏𨭆𨭎";
const ZH_MAP_TO = "㑇㘎㟆𫵷㤘㨫㧐𬎆鿎䌶䌺䌾𬜯䞍𫟦鿏𬭯扬𫠊䯅鲃䲝鳚鳤鹮咬丢并干乱亘亚伫布占并来仑侣局俣系伣侠私具伥俩俫仓个们幸仿伦伟侧侦伪杰伧伞备家佣偬传伛债伤倾偻仅戮佥侨仆伪𫢸侥偾雇价仪侬亿侩俭傧俦侪尽偿优储俪㑩傩傥俨凶兑儿兖内两册幂净冻凛凯别删刭则克刹刬刚剥剐剀创铲划剧刘刽刿剑㓥剂㔉劲动勖务勋胜劳势𪟝勚劢勋励劝匀匦汇匮区协恤却厍厕厌厉厣参叁丛咤吣吴呐吕啕呙员呗吣念问启哑启唡㖞唤亮丧吃乔单哟呛啬唝吗呜唢哔叹喽呕啧尝唛哗唠啸叽哓呒啴𫫇嘘㖊咝哒哝哕嗳哙喷吨当咛吓哜尝噜啮咽呖咙向亸喾严嘤啭嗫嚣冁呓啰禧嘱啮囱囵国围园圆图团埯垭𫭢采执坚垩垴埚尧报场块茔垲埘涂冢坞埙尘𫭟堑𪣻垫坠𫮃堕坟垯墙垦坛垱埙压垒圹垆坛坏垄垅坜坝塆壮壶壸寿够梦伙夹奂奥奁夺奖奋姹妆姐姗奸侄𫰛娱娄妇娅娲妫媪妈袅妪妩娴婳妫媭娆婵娇嫱袅嫒嬷嫔婴婶娘娈孙学孪宫寝实宁审写宽宠宝克将专寻对导尴届尸屃屉屡层屦属冈岘岛峡崃昆岗仑峥岽岚𫶇嵝崭岖嵚崂峤峣峄峃崄岙嵘岭屿岿峦巅岩𪩘巯帅师帐带帧帏帼帻帜币帮帱干几库厕厢厩厦庼厨厮𫷷庙厂庑废广廪庐厅回弑吊弪张强𫸩别弹弥弯汇彝彟彦佛后径从徕复彷征彻恒耻悦悮德怅闷凄恶恼恽恻爱惬悫怆恺忾栗殷态愠惨惭恸惯悫怄怂虑悭庆戚欲忧惫怜凭愦慭惮愤悯怃宪忆勤恳应怿懔蒙怼懑恹忧惩懒怀悬忏惧慑恋戆戋戗戬战戯戏户抛捝挟舍扪卷扫抡挜挣挂采拣扬换挥构损摇捣捶扇拓揾抢榨捂掴掼搂挚抠抟折掺捞挦撑挠捻㧑挢掸掸拨抚扑揿挞挝捡拥掳择击挡㧟担据挤捣拟摈拧搁掷扩撷摆擞撸扰摅撵拢拦撄搀撺携摄攒挛摊搅揽败叙敌数敛毙敩斓斩断于升时晋𬀪昼晕晖𬀩旸畅暂昵晔历昙晓向暧旷昽晒书会胧东丫栅杆栀枧𬂩条枭棁弃枨枣栋㭎栈栖梾桠杨枫桢业极谷杩荣榅桤构枪杠橐梿椠椁桨桩乐枞梁楼标枢样朴树桦桡桥机椭横檩柽档桧楫槚检樯梼台槟柠槛柜𬃊橹榈栉椟橼栎橱槠栌枥橥榇蘖栊榉棂樱栏权椤栾𣗋榄棂款钦叹欧敛欤欢岁历归殁残殒殇㱮殚殓殡㱩歼杀壳毁殴球毵牦毡氇气氢氩氲凼泛泛污决冱没冲况泄汹浃𬇙泾凉凄泪渌净沦渊涞浅涣减沨涡测浑凑𣲗浈涌汤沩准沟温浉涢湿沧灭涤荥沪滞渗卤浒浐滚满渔溇𬇹沤汉涟渍涨溆渐浆颍泼洁𣲘沩潜润浔溃滗涠涩浇涝沄涧渑泽滪泶𬇕浍淀浊浓𣸣湿泞溁浕济涛滥浚潍滨溅泺滤澛滢渎㲿泻沈浏濒泸沥潇潆潴泷濑弥潋澜沣滠洒漓滩灏漤湾滦滟灾为乌烃无炼炜烟茕焕烦炀㶽煴荧炝𬉼热颎炽𬊤烨焰灯炖磷烧𬊈烫焖营灿毁烛烩㶶熏烬焘耀烁炉烂争为爷尔床墙笺牍牵荦犊牺状狭狈狰犹狲犸呆狱狮奖独狯猃狝狞㺍获猎犷兽獭献猕猡现珐珲玮玚琐瑶莹玛琅玱琏𫞩𬍤𬍡琎玑瑷珰环玙玺𬍛琼珑璎瓒𤩽瓯瓮产产亩毕画异当畴叠佝痉酸疴痖疯疡痪瘗疮疟瘆疭瘘瘘疗痨痫瘅愈疠瘪痴痒疖症疬癞癣瘿瘾痈瘫癫发皂皑疱皲皱杯盗盏尽监盘卢荡真眦众𪾢困睁睐睾眯眍䁖瞒了瞆睑眬瞩矫炮研硁硖砗砚硕砀砜确码硙砖碜碛矶硗䃅硚硷础𬒈碍礴矿砺砾矾炮砻秘禄祸祯祎祃御禅礼祢祷秃籼税秆䅉棱禀种称谷䅟稣积颖秾穑秽稳获稆窝洼穷窑窎窭窥窜窍窦灶窃竖竞笔笋笕䇲个笺篪筝钳节范筑箧筼𬕂笃筛筚箦筘篓箪简篑箫檐筜签帘篮筹藤箓篯箨籁笼签笾簖篱箩吁妆粤糁粪粮团粝籴粜纟纠纪纣𬘓约红纡纥纨纫纹纳纽纾纯纰纼纱纮纸级纷纭纴𬘘纺䌷扎细绂绁绅纻绍绀绋绐绌终弦组䌹绊绗结绝绦绔绞络绚给绒𬘡绖统丝绛绝绢𫄨绑绡𬘫绠绨绣绤𬘩绥䌼捆经𫄧综𬘭缍绿𫟅绸绻𬘯𬘬线绶维绹绾纲网绷缀彩纶绺绮绽绰绫绵绲缁紧绯绿绪绬绱缃缄缂线缉缎缔缗缘缌编缓缅纬缑缈练缏缇致萦缙缢缒绉缣缊缞缚缜缟缛县绦缝缡缩𬙂纵缧䌸纤缦絷缕缥总绩绷缫缪缯织缮缭绕绣缋绳绘系茧缰缳缲缴𫄷䍁绎𦈡继缤缱䍀𫄸𬙊缬纩续累缠缨才𬙋纤缵缆钵䓨坛罂坛挂罚骂罢罗罴羁芈群羟羡义膻习玩翚翘翱翙耧耢圣闻联聪声耸聩聂职聍听聋肃胁脉胫唇脱胀肾胨脶脑肿脚肠腽腘肤䏝胶𦝼腻胆脍脓脸脐膑腊胪脏脔臜卧临台与兴举旧铺舱舣舰舻艰艳刍苧苎兹荆豆庄茎荚苋果华烟苌莱万莴叶荭着荮苇药荤𫇭搜莼莳莅苍荪席盖莲苁荜𬜬卜蒌蒋葱茑荫麻𫇭荨蒇荞荬芸莸荛蒉荡芜萧蓣蕰荟蓟芗姜蔷荙莶荐萨䓕苧荠借蓝荩艺药薮䓖蕴苈薯蔼蔺萚蕲芦苏蕴苹藓蔹茏兰蓠萝蔂𬟁处虚虏号亏虬蛱蜕蚬𬟽蚀猬虾虱蜗蛳蚂萤䗖蝼螀蛰蝈螨虮蝉蛲虫蛏蚁蝇虿蝎蛴蝾蚝蜡蛎蠹蟏蛊蚕蛮众蔑术胡卫冲衮绔袅里补装里制复裈袆裤裢褛亵𫌀裥袯袄裣裆褴袜䙓衬袭襕核见觃规觅视觇觋觍觎亲觊觏觐觑觉览觌观觞觯触讠订讣计讯讧讨𬣙讦讱训讪讫托记讹讶讼䜣诀讷讻访设许诉诃诊注证诂诋讵诈诒诏评诐诇诎诅𬣞词咏诩询诣试诗𬣳诧诟诡诠诘话该详诜𫍣诙诖诔诛诓夸志认诳诶诞诱诮语诚诫诬误诰诵诲说说谁课谇诽谊訚调谄谆谈诿请诤诹诼谅𬣡论谂谀谍谞谝𬤊谥诨谔谛谐谏谕谘讳𬤇谙𫍯谌讽诸谚谖诺谋谒谓誊诌谎谜𫍲谧谑谡谤谦谥讲谢谣谣谟谪谬谫讴谨谩哗䜧证谲讥𬤝谮识谯谭谱𫍽噪谵译议谴护诪誉谫读变詟䜩雠谗让谰谶赞谠谳岂竖丰艳猪豮狸猫䝙贝贞贠负财贡贫货贩贪贯责贮贳赀贰贵贬买贷贶费贴贻贸贺贲赂赁贿赅资贾贼赈赊宾赇赒赉赐赏赔赓贤卖贱赋赕质赍账赌䞐赖赗剩赚赙购赛赜贽赘赟赠赞赝赡赢赆赃赑赎赝赣赃赪赶赵趋趱迹交局践蜷逾踊跄跸迹蹒踪糟跷跶趸踌跻跃踯跞踬蹰跹蹑蹿躜躏躯车轧轨军𫐄轪轩轫轭𬨂软轷轸轱轴轵轺轲轶轼较𨐈辂辁辀载轾𪨶辄挽辅轻𫐐辆辎辉辋辍辊辇辈轮辌𫐓辑辏𬨎输辐辗舆辒毂辖辕辘转辙轿辚舆轰辔轹轳办辞辫辩农回迳这连周进游运过达违遥逊递远适遁迟迁选遗辽迈还迩边逻逦郏邮郓乡邹邬郧邓𬩽郑邻郸𫑡邺郐邝酂郦腌酝丑酝医酱酦𬪩宴酿衅酾酽释厘钅钆钇钌钊钉钋针钓钐扣钏钒𬬩钗钍钕钎𬬱钯钫钘钭𫓧钚钠钝钩钤钣钑钞钮钧钙钬钛钪铌铈钶铃钴钹铍钰钸铀钿钾钜铊铉𬬿铇铋铂钷钳铆铅𫟷钺钵钩𬬸钲𬭁鿭钼钽𬬹铏𫟹铰铒铬铪银铳铜𫓯铚铣铨铢铭铫铦衔铑铷铱铟铵铥铕铯铐铞焊锐𨱇销锈锑锉铝锒锌钡铤铗𬭎锋𫓶铻锊锓铘锄锃锔锇铓铺锐铖锆锂铽锍锯𬬮钢𬬭锞录锖锫锩铔锥锕锟锤锱铮锛𬭚锬锭锜钱𫓹锦锚锠锡锢错录锰表铼锝锨锪钔锴锳炼锅镀锷铡钖锻锽锸锲锘锹𬭤锾键锶锗钟镁锿镅镑𬭩镕锁枪镉锤镈𨱏镃钨蓥镏铠铩锼镐镇镒镋镍镓鿔镌镎镞镟链镆镙𬭬镠镝铿锵镗镘镛铲镜镖镂錾镚铧镤镪䥽𬭸锈铙𨱑𫔍铴𫔎𨱔镣铹镦镡钟镫镢镨锎锏镄𬭼镌镰䦃镯镭铁镮铎铛𫟼镱铸鿭镬镔鉴鉴镲锧镴铄镳镥𬬻镧钥镵镶镊镩锣钻銮凿䦆长门闩闪闫闬闭开闶闳闰闲闲间闵闸阂关阁阀哄闺闽阃阆闾阅阅阊阉阎阏阍阈阌阒板暗闱𬮱阔阕阑阇阗𫔶阘闿阖阙闯斗关阚阓阐辟阛闼厄坂陉陕升阵阴陈陆阳堤陧队阶𬮿陨际𬯎随险𬯀隐陇隶只隽虽双雏杂鸡离难云电沾霡雾霁雳霭叇灵叆靓静腼靥纼鼗巩绱鞒缰鞑鞯韦韧韨韩韪韬韫𮧵韭韵响页顶顷项顺顸须顼颂𫠆颀颃预顽颁顿𬱖颇领颌𬱟颉颐颏𫖯头颒颊颋颕𫖳颔颈颓频颓颗题额颚颜颙颛颜𫖮愿颡颠类颟颢顾颤颥显颦颅颞颧风飐飑飒台刮飓飔飏飖飕飗飘飙飚飞饣饥饤饦饨饪饫饬饭饮饴饲饱饰饳饺饸饼饷养饵饹饻饽馁饿馂饾𫗧余肴馄馃饯馅馆糊糇饧喂馉馇馎饩馈馏馊馌馍馒馐馑馓馈馔饥饶飨𫗴餍馋馕马驭冯驮驰驯驲𫘜驳𫘝𬳶驻驽驹𬳵驵驾骀驸驶驼驷骂骈𬳽骇骃骆骎𬳿骏骋骍𫘧骓𫘦骔骒骑骐𬴂骛骗𬴃𫘨骙䯄骞骘骝腾𫘬𫘪驺骚骟骡蓦骜骖骠骢驱骅骕骁𬴊骣骄验惊驿骤驴骧骥骦骊骉肮髅脏体髌髋发剃松胡须鬓斗闹哄阋斗阄郁鬶魉魇鱼鱽鱾鲀鲁鲂鱿鲄𬶍鲅鲆𫚖𬶋鲌鲉鲏鲇鲐鲍鲋鲊鲒鲘鲞鲕𩽾𬶏𬶐䲟鲖鲔鲛鲑鲜鲓鲪𩾃鲝鲧鲠鲩鲤鲨鲬鲻鲯鲭鲷鲴鲱鲵鲲鲳鲸鲮鲰鲶鲺鳀𬶟鲫鳊鳈鲗鳂䲠鲽鳇𬶠鳅鲾鳄鳆鳃鳒鳑鳋鲥𫚕鳏䲢鳎鳐鳍鳁鲢鳌鳓鳘𬶭鲦鲣鲹鳗鳛鳔𬶨鳉鳙𩾌鳕鳖鳟鳝鳜鳞鲟𬶮鲼鲎鲙鳣鳡鳢鲿鲚鳠𫚭鳄鲈鲡鸟凫鸠凫鸤凤鸣鸢䴓鸩鸨鸦鸰鸵鸳鸲鸮鸱鸪鸯鸭鸸鸹鸻䴕鸿鸽䴔鸺鸼𬷕鹀鹃鹆鹁鹈鹅𫛭鹄鹉鹌鹏鹐鹎鹊鹓鹍䴖鸫鹑鹒鹋鹙鹕鹗𬸘鹖鹛鹜䴗鸧莺𬸣鹟鹤鹠鹡鹘鹣鹚鹢鹞鸡䴘鹝鹧鹥鸥鸷鹨𬸦鸶鹪鹔𬸪鹩鹫鹇鹬鹰鹭鸴䴙㶉鹯鹱鹲𬸚鸬鹴鹦鹳鹂鸾卤咸鹾碱盐丽粗麦麸曲麹面么么黄黉点党黪霉黡黩黾鼋鳌鳖鼍冬鼹齐斋赍齑齿龀龁龂𬹼龅龇龃龆龄出龈啮咬龊龉𬺈𫠜龋腭龌𬺓龙厐庞䶮龚龛龟𫭼𬒗𬭊𬭛𬭶𬭳";
const ZH_MAP_FROM_CHARS = Array.from(ZH_MAP_FROM);
const ZH_MAP_TO_CHARS = Array.from(ZH_MAP_TO);
const ZH_FOLD = new Map(ZH_MAP_FROM_CHARS.map((ch, i) => [ch, ZH_MAP_TO_CHARS[i]]));
function repKey(ch) {
  return (ZH_FOLD.get(ch) || ch).toLowerCase();
}

// 只做匹配时的繁简、大小写归一，保持原文其他字和替换结果原样。
function replaceAnyCaseScript(text, from, to) {
  const needle = Array.from(from).map(repKey);
  if (!needle.length) return text;
  const input = Array.from(text), folded = input.map(repKey), result = [];
  for (let i = 0; i < input.length;) {
    let matched = i + needle.length <= input.length;
    for (let j = 0; matched && j < needle.length; j++) {
      if (folded[i + j] !== needle[j]) matched = false;
    }
    if (matched) { result.push(to); i += needle.length; }
    else { result.push(input[i]); i++; }
  }
  return result.join('');
}

function applyReps(t) {
  const p = cur();
  if (!p.repOn || !Array.isArray(p.reps)) return t;
  const n = names();
  const res = v => (v || '').replace(/{{char}}/gi, n.char).replace(/{{user}}/gi, n.user);
  p.reps.map(r => [res(r.from).trim(), res(r.to)]).filter(([f]) => f)
    .sort((a, b) => Array.from(b[0]).length - Array.from(a[0]).length)
    .forEach(([f, to]) => { t = replaceAnyCaseScript(t, f, to); });
  return t;
}

function normalize(t) {
  return (t || '').replace(/\r/g, '').replace(/[ \t\u3000]+\n/g, '\n').replace(/\n{2,}/g, '\n').trim();
}

function buildText() {
  const raw = normalize(st.custom != null ? st.custom : st.base);
  const rendered = normalize(st.custom!=null && st.customIsRendered ? raw : applyReps(raw));
  if (raw !== st.raw || rendered !== st.chars.join('')) {
    st.holes = []; st.off = {}; st.free = [];
  }
  st.raw = raw;
  st.chars = Array.from(rendered);
}

function sharedCopy(p) {
  const n = names(), d = new Date().toLocaleDateString('zh-CN');
  const expand = t => String(t ?? '').replace(/{{char}}/gi, n.char).replace(/{{user}}/gi, n.user).replace(/{{date}}/gi, d).trim();
  return {
    title: expand(p.pubTitle) || n.user || '未命名作品',
    subtitle: expand(p.pubKicker),
    author: expand(p.pubAuthor) || n.char || '作者',
    note: expand(p.pubNote),
    date: expand(p.pubDate) || expand(p.postypeDate) || d,
  };
}
function sigLines(p) {
  const m = sharedCopy(p);
  // One semantic record for punch poster and every imported CSS layout.
  // Dates are available as a CSS slot, but not forced into punch artwork.
  return [m.title, m.subtitle, ...m.note.split('\n'), m.author].filter(Boolean);
}

function layoutText(g, p, font, W, fsx) {
  const fs = fsx || +p.fontSize, ls = +p.letterSpacing, lh = fs * p.lineHeight;
  const usable = Math.max(20, W - 2 * p.padX);
  const single = p.layoutMode === 'single';
  const widthFactor = single ? Math.min(100, Math.max(45, +p.textBoxWidth || 100)) / 100 : 1;
  const maxW = usable * widthFactor;
  const boxX = +p.padX + (usable - maxW) * (single ? Math.min(100, Math.max(0, +p.textBoxX || 0)) / 100 : 0);
  g.font = `${fs}px ${font}`;
  const paras = [[]];
  st.chars.forEach((ch, i) => { if (ch === '\n') paras.push([]); else paras[paras.length - 1].push(i); });
  const lines = [];
  const paraEnds = [];
  paras.forEach(pi => {
    let x = p.indent ? fs * 2 + ls * 2 : 0;
    let line = { items: [], last: false };
    lines.push(line);
    pi.forEach(i => {
      const ch = st.chars[i], w = g.measureText(ch).width;
      if (line.items.length && x + w > maxW && !HANG.includes(ch)) { x = 0; line = { items: [], last: false }; lines.push(line); }
      line.items.push({ i, ch, w, x });
      x += w + ls;
    });
    line.last = true;
    paraEnds.push(lines.length);
  });
  const boxes = [];
  lines.forEach((ln, li) => {
    const n = ln.items.length;
    let extra = 0;
    if (p.textAlign === 'justify' && !ln.last && n > 1) {
      const e = ln.items[n - 1];
      extra = Math.max(0, (maxW - (e.x + e.w)) / (n - 1));
    }
    let off = 0;
    if (n && !extra) {
      const e = ln.items[n - 1], lw = e.x + e.w - (ln.items[0].x);
      off = ['center', 'right'].includes(p.textAlign) ? (maxW - lw) * (p.textAlign === 'center' ? 0.5 : 1) - ln.items[0].x : 0;
    }
    ln.items.forEach((it, j) => { it.ax = boxX + it.x + extra * j + off; it.line = li; boxes.push(it); });
  });
  return { boxes, lh, h: lines.length * lh, lineCount: lines.length, paraEnds, boxX, boxW: maxW };
}


// Editorial composition on a single paper: insertion boxes shift subsequent
// paragraphs. Original text indices remain unchanged for punching/hit testing.
function wrapEditorial(g, text, font, size, maxW) {
  g.font = `${size}px ${font}`;
  const lines = [''];
  for (const c of Array.from(String(text || ''))) {
    const last = lines.length - 1;
    if (c === '\n') { lines.push(''); continue; }
    if (lines[last] && g.measureText(lines[last] + c).width > maxW) lines.push(c);
    else lines[last] += c;
  }
  return lines;
}
function layoutEditorial(g, p, T, fs, font, sigFs, sigLH, sigs) {
  if (p.layoutMode !== 'single' || !p.pubOn || st.editing) return T;
  const gap = fs * 0.48;
  const blocks = [];
  let shift = 0;
  const add = (b, h) => { b.y = shift; blocks.push(b); shift += h; };
  const maxW = T.boxW;
  if (p.pubKicker?.trim()) {
    const sz = Math.max(15, fs * 0.57);
    const lines = wrapEditorial(g, p.pubKicker.trim(), font, sz, maxW);
    add({type:'heading', lines, size:sz, color:p.sigColor, align:p.pubTitleAlign, lineH:sz*1.45}, lines.length * sz * 1.45 + gap*0.65);
  }
  if (p.pubTitle?.trim()) {
    const sz = fs * Math.max(1.1, Math.min(3, +p.pubTitleSize || 1.75));
    const lines = wrapEditorial(g, p.pubTitle.trim(), font, sz, maxW);
    add({type:'heading', lines, size:sz, color:p.ink, align:p.pubTitleAlign, lineH:sz*1.2}, lines.length * sz * 1.2 + gap);
  }
  const sigBlockH = sigs.length ? sigLH*sigs.length + gap : 0;
  if (sigs.length && p.pubSigPosition === 'title') add({type:'signature',lines:sigs.slice(),size:sigFs,lineH:sigLH},sigBlockH);
  // Photographs use a block model; images inserted after paragraph N affect
  // the positions of every subsequent glyph and remain inside the text column.
  const events = new Map();
  const photos = Array.isArray(p.pubImages) ? p.pubImages.slice(0,8) : [];
  photos.forEach(pic => {
    if (!pic?.src) return;
    const at = Math.min(T.paraEnds.length, Math.max(0, Math.floor(+pic.after || 0)));
    const line = at === 0 ? 0 : T.paraEnds[at-1];
    const w = maxW * Math.min(1,Math.max(.3,(+pic.width||80)/100));
    const im = imgOf(pic.src);
    const ar = pic.ratio === 'natural' && im?.width && im?.height ? im.width/im.height : ({'1:1':1,'4:3':4/3,'16:9':16/9,'3:4':3/4}[pic.ratio] || 4/3);
    const h = Math.min(2400, w / ar);
    const capSize = Math.max(14,fs*.43);
    const caps = pic.caption?.trim() ? wrapEditorial(g,pic.caption.trim(),font,capSize,w) : [];
    const capH = caps.length ? caps.length*capSize*1.6 + gap*.2 : 0;
    const block = {type:'photo', pic, w, h, capSize, caps, capH, align:pic.align||'center'};
    if (!events.has(line)) events.set(line, []);
    events.get(line).push(block);
  });
  const lineShifts = [];
  // "shift" includes heading and inline byline before the first paragraph.
  for (let li=0; li<=T.lineCount; li++) {
    const before = events.get(li) || [];
    for (const imageBlock of before) {
      imageBlock.y = li*T.lh + shift + gap*.45;
      blocks.push(imageBlock);
      shift += imageBlock.h + imageBlock.capH + gap*1.2;
    }
    if (li<T.lineCount) lineShifts[li]=shift;
  }
  if (sigs.length && p.pubSigPosition === 'end') {
    blocks.push({type:'signature', y:T.h+shift+gap, lines:sigs.slice(),size:sigFs,lineH:sigLH});
    shift += sigBlockH + gap;
  }
  T.boxes.forEach(b => { b.flowShift = lineShifts[b.line] || 0; });
  T.h += shift;
  T.editorialBlocks = blocks;
  return T;
}
function paintEditorial(g,p,T,font,ty,textY) {
  if (!T.editorialBlocks) return;
  for (const b of T.editorialBlocks) {
    const y = textY + ty + b.y;
    g.save();
    if (b.type === 'heading') {
      g.font = `${b.size}px ${font}`;
      g.fillStyle = b.color;
      g.textBaseline = 'top';
      g.textAlign = b.align === 'center' ? 'center' : b.align === 'right' ? 'right' : 'left';
      const x = b.align === 'center' ? T.boxX + T.boxW/2 : b.align === 'right' ? T.boxX + T.boxW : T.boxX;
      b.lines.forEach((line,i) => g.fillText(line,x,y+i*b.lineH));
    } else if (b.type === 'signature') {
      g.font = `${b.size}px ${font}`;g.fillStyle=p.sigColor;g.textBaseline='top';
      const x = p.sigAlign === 'center' ? T.boxX+T.boxW/2 : p.sigAlign==='right' ? T.boxX+T.boxW : T.boxX;
      b.lines.forEach((line,i)=>spacedText(g,line,x,y+i*b.lineH,b.size*.1,p.sigAlign));
    } else if (b.type === 'photo') {
      const x = b.align === 'right' ? T.boxX+T.boxW-b.w : b.align==='left' ? T.boxX : T.boxX+(T.boxW-b.w)/2;
      const im = imgOf(b.pic.src);
      if (im) {
        if (b.pic.fit === 'contain') {
          const k = Math.min(b.w/im.width,b.h/im.height);
          g.drawImage(im,x+(b.w-im.width*k)/2,y+(b.h-im.height*k)/2,im.width*k,im.height*k);
        } else drawCover(g,im,x,y,b.w,b.h);
      } else if (st.canvas && isOpen() && st.previewMode !== false) {
        g.fillStyle=p.paperColor;g.fillRect(x,y,b.w,b.h);
        g.strokeStyle=p.sigColor;g.lineWidth=1;g.strokeRect(x+.5,y+.5,b.w-1,b.h-1);
      }
      if (b.caps.length) {
        g.font=`${b.capSize}px ${font}`;g.fillStyle=p.sigColor;g.textBaseline='top';g.textAlign='left';
        b.caps.forEach((line,i)=>g.fillText(line,x,y+b.h+5+i*b.capSize*1.6));
      }
    }
    g.restore();
  }
}

function holeDims(p, base) {
  const s = base * p.holeSize;
  return ['rough', 'rect', 'round', 'torn'].includes(p.holeShape) ? [s, s * 1.15] : [s * 1.15, s * 1.15];
}
const keySeed = k => { let h = 7; for (const c of String(k)) h = (h * 31 + c.charCodeAt(0)) % 100003; return h; };

function layoutScraps(p, sw, sh, maxWidth = Infinity) {
  const step = sw * 1.2, seed = st.seed * 97, tilt = +p.scrapTilt;
  const items = [];
  const push = (k, x, y) => items.push({
    k, x: x + (rnd(k + seed, 2) - 0.5) * sw * 0.1, y: y + (rnd(k + seed, 3) - 0.5) * sh * 0.18,
    rot: (rnd(k + seed, 1) - 0.5) * 2 * tilt,
  });
  const holes = st.holes;
  if (p.arrange === 'stairs') {
    let x = 0, y = 0, diag = true;
    holes.forEach((h, k) => { push(k, x, y); if (diag) { x += step * 0.8; y += sh * 0.78; } else x += step; if (h.br) diag = !diag; });
  } else if (p.arrange === 'column') {
    const limit = Math.max(1, Math.min(20, Math.round(+p.columnLimit || 5)));
    const cols = [[]];
    holes.forEach((h, k) => {
      const col = cols[cols.length - 1];
      col.push(k);
      if (h.br || col.length >= limit) cols.push([]);
    });
    cols.filter(col => col.length).forEach((col, ci) => {
      const ch = (col.length - 1) * sh * 1.2;
      col.forEach((k, ri) => push(k, ci * step * 1.4, ri * sh * 1.2 - ch / 2));
    });
  } else {
    const settingLimit = Math.max(1, Math.min(20, Math.round(+p.rowLimit || 6)));
    const fitLimit = Number.isFinite(maxWidth)
      ? Math.max(1, Math.floor((maxWidth - sw) / (sw * 1.2)) + 1)
      : settingLimit;
    const limit = Math.max(1, Math.min(settingLimit, fitLimit));
    const rows = [[]];
    holes.forEach((h, k) => {
      const row = rows[rows.length - 1];
      row.push(k);
      if (h.br || row.length >= limit) rows.push([]);
    });
    rows.filter(row => row.length).forEach((row, ri) => {
      const rw = (row.length - 1) * step;
      row.forEach((k, j) => push(k, j * step - rw / 2, ri * sh * 1.45));
    });
  }
  if (!items.length) return { items, bw: 0, bh: 0 };
  const minX = Math.min(...items.map(i => i.x)) - sw / 2, maxX = Math.max(...items.map(i => i.x)) + sw / 2;
  const minY = Math.min(...items.map(i => i.y)) - sh / 2, maxY = Math.max(...items.map(i => i.y)) + sh / 2;
  const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
  items.forEach(i => { i.x -= cx; i.y -= cy; });
  return { items, bw: maxX - minX, bh: maxY - minY };
}

// v21: independent, exportable publication and real-app inspired static layouts.
// All text is user-provided / user-selected. These are editable mock pages, not live apps.
const PAGE_SKINS = {punch:{group:'打孔',name:'打孔海报',detail:'原生 Canvas'}};
// Independent CSS layouts. Each .css carries a JSON layout manifest inside a comment.
// CSS is mounted in a ShadowRoot, so it cannot accidentally restyle SillyTavern.


const CSS_STARTER = "/* @pk-template\n{\n  \"id\": \"plain_example\",\n  \"name\": \"自定义 · 示例排版\",\n  \"width\": 390,\n  \"html\": \"<article class=\\\"example\\\"><h1 data-pk=\\\"title\\\"></h1><div class=\\\"byline\\\" data-pk=\\\"author\\\"></div><section data-pk=\\\"body\\\"></section></article>\"\n}\n@end-pk-template */\n.pk-css-page{background:white;color:#252525;font-family:system-ui,\"PingFang SC\",sans-serif}\n.pk-css-page .example{padding:36px 25px 60px}\n.pk-css-page h1{font-size:24px;line-height:1.3;margin:0 0 12px}\n.pk-css-page .byline{font-size:13px;color:#888;margin:0 0 26px}\n.pk-css-page section{font-size:16px;line-height:1.85}\n.pk-css-page section p{margin:0 0 1em;white-space:pre-wrap}\n";

// Built-in CSS templates share the exact same import/export renderer as user CSS.
// The punch palette remains Canvas-only. All other page layouts are CSS.
const BUILTIN_CSS = {};

function cssActive() { return String(cur().pageSkin||'').startsWith('css:'); }
function cssEntries() { return store().cssTpl; }
// Display names and exported CSS filenames use stable, annotation-free template names.
// Keep template IDs unchanged so importing a new CSS still replaces the old one.
function cssTemplateName(id, name) {
  const stable = {
    app_postype: 'POSTYPE',
    xhs_note: '小红书',
    xhs_comments: '小红书评论',
    blank: '单页'
  };
  if (stable[id]) return stable[id];
  return String(name || id || '模板')
    .replace(/\s*[（(][^）)]*(?:修复|调整|修改|重做|无评论|无上一篇|横版|对齐|图标|更新|新版|v\d)[^）)]*[）)]\s*$/gi, '')
    .replace(/(?:\s*[-_· ]+)(?:v\d+(?:[._-]\d+)*|修复版|调整版|新版|最终版|无评论区|横版配图|无上一篇下一篇)\s*$/gi, '')
    .replace(/\s*·\s*/g, '-')
    .replace(/[\\/:*?"<>|]/g, '-')
    .replace(/-{2,}/g, '-')
    .trim() || String(id || '模板');
}
function cssClean(input) {
  const raw=String(input||'');
  // Keep imports local: reject scripts, external @imports, and gigantic content.
  if (raw.length>180000) throw new Error('CSS 文件太大（最大 180 KB）');
  const block=raw.match(/\/\*\s*@pk-template\s*([\s\S]*?)\s*@end-pk-template\s*\*\//i);
  if(!block)throw new Error('缺少 @pk-template 配置，请用示例 CSS 的格式');
  let meta;
  try { meta=JSON.parse(block[1]); } catch(e) {throw new Error('CSS 内的模板配置不是有效 JSON');}
  if(!meta || typeof meta.name!=='string'||!meta.name.trim()) throw new Error('需要模板名称 name');
  if(typeof meta.html!=='string'||!meta.html.includes('data-pk="body"')) throw new Error('页面结构里需要正文插槽 data-pk="body"');
  const css=raw.replace(block[0],'').trim();
  if(/@import\b/i.test(css) || /(?:expression\s*\(|javascript\s*:)/i.test(css)) throw new Error('CSS 不支持外部 @import 或脚本');
  if(/url\s*\(\s*(?!["']?data:)[^)]+\)/i.test(css)) throw new Error('为了导出稳定，CSS 暂不支持远程 url()；请用上传头像或纯 CSS 图形');
  const id=String(meta.id||meta.name).trim().toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff_-]+/g,'-').slice(0,60);
  if(!id || ['__proto__','constructor','prototype'].includes(id))throw new Error('模板 ID 不合法');
  return {id, name:cssTemplateName(id, meta.name.trim()).slice(0,64), html:meta.html, css, width:Math.min(640,Math.max(250,+meta.width||390))};
}
function cssSafeMarkup(html) {
  const tmpl=document.createElement('template');
  tmpl.innerHTML=html;
  tmpl.content.querySelectorAll('script,style,iframe,object,embed,form,link,meta,svg,foreignObject').forEach(x=>x.remove());
  tmpl.content.querySelectorAll('*').forEach(el=>{
    for(const att of Array.from(el.attributes)){
      const n=att.name.toLowerCase(),v=att.value;
      if(n.startsWith('on') || n==='srcdoc' || n==='contenteditable' || n==='style'||
        ((n==='href'||n==='src') && !/^data:image\/(?:png|jpeg|webp|gif);base64,/i.test(v))) el.removeAttribute(att.name);
    }
  });
  return tmpl.innerHTML;
}
function cssIconSvg(name){
  const shapes={
    'chevron-left':['path|m15 18-6-6 6-6'],
    'chevron-right':['path|m9 18 6-6-6-6'],
    'house':['path|m3 10 9-7 9 7','path|M5 9v11h14V9','path|M9 20v-7h6v7'],
    'share':['path|M12 16V3','path|m7 8 5-5 5 5','path|M5 13v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7'],
    'settings':['circle|12,12,3','path|M9.8 2.7h4.4l.7 2.4 2 .8 2.2-1.2 3.1 3.1L21 10l.8 2 .2 2.2-2.4.7-.8 2 1.2 2.2-3.1 3.1-2.2-1.2-2 .8-2.2.2-.7-2.4-2-.8-2.2 1.2-3.1-3.1L3.7 17l-.8-2L.5 14.2V9.8l2.4-.7.8-2-1.2-2.2 3.1-3.1 2.2 1.2 2-.8Z'],
    'list':['path|M9 6h12','path|M9 12h12','path|M9 18h12','path|M4 6h.01','path|M4 12h.01','path|M4 18h.01'],
    'heart':['path|M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78Z'],
    'message':['path|M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7A8.4 8.4 0 0 1 4 11.5 8.5 8.5 0 0 1 8.7 3.9a8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8v.5Z'],
    'repeat':['path|m17 2 4 4-4 4','path|M3 11V9a3 3 0 0 1 3-3h15','path|m7 22-4-4 4-4','path|M21 13v2a3 3 0 0 1-3 3H3'],
    'bookmark':['path|M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16Z']
  };
  if(!shapes[name])return null;
  const NS='http://www.w3.org/2000/svg',s=document.createElementNS(NS,'svg');
  s.setAttribute('viewBox','0 0 24 24');s.setAttribute('aria-hidden','true');
  for(const item of shapes[name]){
    const [type,arg]=item.split('|');const node=document.createElementNS(NS,type);
    if(type==='circle'){const [cx,cy,r]=arg.split(',');node.setAttribute('cx',cx);node.setAttribute('cy',cy);node.setAttribute('r',r);}
    else node.setAttribute('d',arg);
    s.appendChild(node);
  }
  return s;
}

// All structured CSS templates use the same complete source text for preview,
// in-place editing and PNG export. This prevents one edited note from replacing
// the entire multi-selection, and ensures that stray closing brackets are not
// treated as separate notes.
function marginNoteParts(text){
  const parts=[];
  const open={']':'[','】':'【','」':'「','』':'『','）':'（','》':'《','”':'“','’':'‘'};
  for(const item of String(text||'').replace(/\r/g,'').split(/\n+/)){
    const line=item.trim();
    if(!line)continue;
    // Only treat a line made entirely of closing brackets as a possible
    // continuation. Standalone punctuation, symbols and emoji are valid
    // user-selected paragraphs and must never disappear during editing/export.
    if(/^[\]】」』）》”’]+$/u.test(line)){
      if(parts.length){
        let previous=parts[parts.length-1];
        for(const char of line){
          if(previous.includes(open[char]) && !previous.endsWith(char))previous+=char;
        }
        parts[parts.length-1]=previous;
      } else {
        parts.push(line);
      }
      continue;
    }
    parts.push(line);
  }
  return parts;
}
function imessageReceivedParts(text){
  return String(text||'').replace(/\r/g,'').split(/\n+/).map(s=>s.trim()).filter(Boolean);
}

function cssFillTemplate(root, spec){
  // Hide modules the owner does not want, including older CSS files already imported.
  const templateId=String(spec?.id||'');
  // The margin-note template can contain many generated note rows.
  // Drop only generated rows before shared field binding on each redraw.
  if(templateId==='page_margin_note' && !st.inlineEditing){
    root.querySelectorAll('.pa-note[data-pa-generated="1"]').forEach(el=>el.remove());
  }
  if(templateId==='xhs_note') {
    root.querySelectorAll('.xhs-discuss').forEach(el=>el.remove());
    root.querySelectorAll('.xhs-placeholder-txt').forEach(el=>{el.textContent='点击图片占位上传配图';});
    root.querySelectorAll('.xhs-media .xhs-cover').forEach(el=>{
      // The slot itself is landscape, approximately 390 x 230 logical pixels.
      el.style.setProperty('aspect-ratio','390 / 230','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','0','important');
      el.style.setProperty('isolation','isolate','important');
    });
    root.querySelectorAll('.xhs-media').forEach(media=>{
      media.style.setProperty('position','relative','important');
      media.style.setProperty('isolation','isolate','important');
      media.style.setProperty('overflow','visible','important');
    });
    root.querySelectorAll('.xhs-media .xhs-pagecount').forEach(el=>{
      el.style.setProperty('position','absolute','important');
      el.style.setProperty('top','10px','important');
      el.style.setProperty('right','10px','important');
      el.style.setProperty('z-index','100','important');
      el.style.setProperty('pointer-events','none','important');
    });
  }

  if(templateId==='app_postype'||templateId==='postype') root.querySelectorAll('.ps-neighbor').forEach(el=>el.remove());
  if(templateId==='ao3_work'){
    // Only bind data entered by the user. Never bake a referenced work's tags
    // or summary into this template. The entire ratings block is optional.
    const p=cur();
    const meta=root.querySelector('[data-pk-section="ao3-metadata"]');
    if(meta)meta.hidden=p.ao3ShowMetadata===false;
    const rating=root.querySelector('[data-pk="ao3-rating"]');
    if(rating)rating.textContent=String(p.ao3Rating||'').trim()||'—';
    const rows=root.querySelector('[data-pk="ao3-meta-lines"]');
    if(rows){
      rows.replaceChildren();
      for(const line of String(p.ao3MetaLines||'').split(/\r?\n/).slice(0,30)){
        const value=line.trim();if(!value)continue;
        const split=value.search(/[:：]/),term=split>0?value.slice(0,split).trim():'',body=split>0?value.slice(split+1).trim():value;
        const wrap=document.createElement('div');wrap.className='ao3-meta-row';
        if(term){const dt=document.createElement('dt');dt.textContent=term+':';wrap.appendChild(dt);}
        const dd=document.createElement('dd');dd.textContent=body;wrap.appendChild(dd);
        rows.appendChild(wrap);
      }
    }
  }
  const p=cur(),n=names(),m=sharedCopy(p);
  const {title,subtitle,author,date}=m;
  // CSS templates supply geometry and hierarchy; editable content shares one
  // global font and ink colour with the native punch canvas.
  const sharedFont = fontStack(p);
  root.style.setProperty('--pk-shared-font',sharedFont);
  root.style.setProperty('--pk-shared-ink',p.ink||'#2b2b2b');
  root.querySelectorAll('[data-pk="title"],[data-pk="subtitle"],[data-pk="author"],[data-pk="note"],[data-pk="signature-extra"]').forEach(el=>{
    el.style.setProperty('font-family',sharedFont,'important');
    el.style.setProperty('color',p.ink||'#2b2b2b','important');
  });
  const values={title,subtitle,author,note:m.note,user:n.user||'用户',channel:String(p.postypeChannel||'').trim()||author,
    date};
  Object.entries(values).forEach(([key,val])=>root.querySelectorAll(`[data-pk="${key}"]`).forEach(el=>{el.textContent=val;if(key==='subtitle')el.hidden=!val;}));
  // Legacy CSS files may still have empty number slots: fill only if empty.
  // Numeric mock values now live in CSS template markup, not plugin settings.
  root.querySelectorAll('[data-pk="views"],[data-pk="likes"],[data-pk="comments"]').forEach(el=>{
    if(!el.textContent.trim())el.textContent='0';
  });
  // In Xiaohongshu note pages, the shared subtitle is a tag field. Convert
  // plain user-entered words into separate blue hashtags, without double '#'.
  // The text is always inserted through textContent, never as HTML.
  if(templateId==='xhs_note'){
    root.querySelectorAll('[data-pk="subtitle"]').forEach(el=>{
      const tags=String(subtitle||'')
        .replace(/＃/g,'#')
        .replace(/([^\s])#/g,'$1 #')
        .split(/[\s,，、;；|｜]+/)
        .map(v=>v.replace(/^#+/,'').trim()).filter(Boolean);
      el.replaceChildren();el.hidden=!tags.length;
      el.classList.add('pk-xhs-tags');
      el.style.setProperty('color','#326da3','important');
      const fragment=document.createDocumentFragment();
      for(const tag of tags){
        const span=document.createElement('span');span.className='pk-xhs-tag';
        span.textContent='#'+tag;
        span.style.setProperty('color','#326da3','important');
        fragment.appendChild(span);
        fragment.appendChild(document.createTextNode(' '));
      }
      el.appendChild(fragment);
    });
  }
  if(templateId==='threads_day'){
    // Threads uses short relative time for recent dated posts, not YYYY/MM/DD.
    const rawDate=String(date||'').trim();
    const dmatch=rawDate.match(/^(\d{4})[\/.-](\d{1,2})[\/.-](\d{1,2})(?:\s+(\d{1,2}):(\d{2}))?$/);
    let shortDate=rawDate;
    if(dmatch){
      const now=new Date(),yr=+dmatch[1],mo=+dmatch[2],dy=+dmatch[3];
      const at=Date.UTC(yr,mo-1,dy);
      if(new Date(at).getUTCFullYear()===yr&&new Date(at).getUTCMonth()===mo-1&&new Date(at).getUTCDate()===dy){
        const diff=Math.round((Date.UTC(now.getFullYear(),now.getMonth(),now.getDate())-at)/86400000);
        if(diff>=0&&diff<=30){
          shortDate=diff===0?'刚刚':diff+'天';
          if(diff===0&&dmatch[4]!=null){
            const minutes=Math.floor((now.getTime()-new Date(yr,mo-1,dy,+dmatch[4],+dmatch[5]).getTime())/60000);
            if(minutes>=0)shortDate=minutes<1?'刚刚':minutes<60?minutes+'分钟':Math.floor(minutes/60)+'小时';
          }
        }
      }
    }
    root.querySelectorAll('[data-pk="date"]').forEach(el=>{el.textContent=shortDate;});
    root.querySelectorAll('[data-pk-section="threads-comments"]').forEach(el=>{el.hidden=p.threadsShowComments===false;});
    const commentName=String(p.threadsReplyName||'').trim()||'评论者';
    const commentTime=String(p.threadsReplyTime||'').trim()||'1天';
    const commentText=String(p.threadsReplyText||'').trim()||'在「编辑信息 → 脆评论区」填写评论内容';
    for(const [slot,value] of [['threads-reply-name',commentName],['threads-reply-time',commentTime],['threads-reply-text',commentText]]){
      root.querySelectorAll('[data-pk="'+slot+'"]').forEach(el=>{if(el.textContent!==value)el.textContent=value;});
    }
    const mode=p.threadsReplyAvatarMode||'initial';
    const avatarSrc=postypeAvatarSrc({...p,postypeAvatarMode:mode,postypeAvatarImg:p.threadsReplyAvatarImg||''});
    const initial=Array.from(commentName)[0]||'?';
    root.querySelectorAll('[data-pk="threads-reply-avatar"]').forEach(el=>{
      const current=el.querySelector('img.pk-avatar-photo');
      if(!avatarSrc){if(current||el.textContent!==initial)el.textContent=initial;return;}
      if(current?.getAttribute('src')===avatarSrc)return;
      const img=document.createElement('img');
      img.className='pk-avatar-photo';img.alt=commentName;
      img.style.cssText='width:100%;height:100%;object-fit:cover;object-position:center;border-radius:inherit;display:block;transform:none;';
      if(!avatarSrc.startsWith('data:')&&!avatarSrc.startsWith('blob:'))img.crossOrigin='anonymous';
      img.onerror=()=>{if(el.contains(img))el.textContent=initial;};
      el.replaceChildren(img);img.src=avatarSrc;
    });
  }
  root.querySelectorAll('[data-pk-section="author-card"]').forEach(el=>{el.hidden=p.postypeShowAuthor===false;});
  // The first signature line is the author; lines 2-4 are optional additional
  // byline lines. All typography controls belong to the CSS page, not Canvas.
  const align=['left','center','right'].includes(p.sigAlign)?p.sigAlign:'left';
  const signatureSize=Math.min(21,Math.max(12,12+((+p.sigSize||0.56)-0.3)*12));
  root.style.setProperty('--pk-signature-align',align);
  root.style.setProperty('--pk-signature-size',signatureSize.toFixed(2)+'px');
  root.style.setProperty('--pk-signature-color',p.sigColor||'#555555');
  // Notes are the only optional extra byline; title and author have dedicated slots.
  const extra=m.note ? m.note.split('\n').filter(Boolean) : [];
  root.querySelectorAll('[data-pk="signature-extra"]').forEach(el=>{
    el.textContent='';el.hidden=!extra.length;
    extra.forEach(value=>{const line=document.createElement('div');line.textContent=value;el.appendChild(line);});
  });
  root.querySelectorAll('[data-pk-icon]').forEach(el=>{
    const svg=cssIconSvg(el.dataset.pkIcon);
    if(svg){el.textContent='';el.appendChild(svg);}
  });
  // Profile avatars are independent of page illustrations. In particular,
  // dragging the cover image sliders must not recreate the avatar IMG: iOS
  // otherwise repeatedly reloads it and temporarily shows the first initial.
  const avatarSrc=postypeAvatarSrc(p),avatarInitial=Array.from(author)[0]||'?';
  root.querySelectorAll('[data-pk="avatar"]').forEach(el=>{
    const current=Array.from(el.children).find(child=>child.tagName==='IMG' && child.classList.contains('pk-avatar-photo'));
    if(!avatarSrc){
      if(current || el.textContent!==avatarInitial)el.textContent=avatarInitial;
      delete el.dataset.pkAvatarSrc;
      return;
    }
    if(current && current.getAttribute('src')===avatarSrc){
      // Keep the same element, image resource and cropping across every redraw.
      if(current.alt!==author)current.alt=author;
      return;
    }
    const img=document.createElement('img');
    img.className='pk-avatar-photo';img.alt=author;
    img.style.cssText='width:100%!important;height:100%!important;max-width:none!important;'+
      'object-fit:cover!important;object-position:center center!important;'+
      'transform:none!important;position:static!important;border-radius:inherit;display:block;';
    if(!avatarSrc.startsWith('data:')&&!avatarSrc.startsWith('blob:'))img.crossOrigin='anonymous';
    img.onerror=()=>{
      if(el.contains(img)){el.textContent=avatarInitial;el.dataset.pkAvatarSrc='';}
    };
    // Replace only if the actual avatar source changed, never on cover movement.
    el.replaceChildren(img);
    img.src=avatarSrc;
    el.dataset.pkAvatarSrc=avatarSrc;
  });
   // Real images are optional; without an image the CSS slot is its own placeholder.
   root.querySelectorAll('[data-pk="image"]').forEach(el=>{
     // The picture is cropped inside its own CSS slot. Never resize or move
     // the whole poster: the 3 sliders adjust this image only.
     const src=String(p.skinImg||'');
     el.dataset.pkUpload='skinImg';
     el.title='点击上传 / 替换图片';
     el.style.cursor='pointer';
     el.style.position='relative';
     el.style.overflow='hidden';
     el.style.backgroundImage='none';
     let photo=Array.from(el.children).find(n=>n.classList?.contains('pk-slot-photo'));
     if(src){
       if(!photo){
         photo=document.createElement('img');
         photo.className='pk-slot-photo';
         photo.alt='';
         photo.draggable=false;
         el.appendChild(photo);
       }
       if(photo.getAttribute('src')!==src)photo.src=src;
       const scale=Math.max(0.5,Math.min(3,Number(p.skinImgScale)||1));
       const x=Math.max(0,Math.min(100,Number(p.skinImgX??50)));
       const y=Math.max(0,Math.min(100,Number(p.skinImgY??50)));
       // Keep the complete image visible at its normal size. Only explicit
       // enlargement above 1x can crop, and only inside its own image slot.
       // The two position sliders set the focal point, never move the slot.
       const zoom=scale;
       photo.style.cssText='position:absolute!important;inset:0!important;display:block!important;'+
         'width:100%!important;height:100%!important;max-width:none!important;'+
         'object-fit:contain!important;object-position:'+x+'% '+y+'%!important;'+
         'transform:scale('+zoom+')!important;transform-origin:'+x+'% '+y+'%!important;'+
         'pointer-events:none!important;z-index:0!important;';
       Array.from(el.children).forEach(n=>{if(n!==photo)n.hidden=true;});
     } else {
       if(photo)photo.remove();
       Array.from(el.children).forEach(n=>{n.hidden=false;});
     }
   });
  // Content is injected as text nodes only. No material from screenshot examples is copied.
   const raw=st.chars.join('').replace(/\r/g,'');
   const lines=raw.split('\n');
   root.querySelectorAll('[data-pk="body"]').forEach(body=>{
     // Shared typography: one set of font/size/colour/spacing controls for Canvas and CSS.
     // Canvas works at 1080px design width; scale its text size down for a 390px webpage.
     const cssScale=390/1080;
     const fs=Math.max(12,Math.min(34,(+p.fontSize||46)*cssScale));
     body.style.setProperty('font-size',fs.toFixed(2)+'px','important');
     body.style.setProperty('line-height',String(+p.lineHeight||2),'important');
     body.style.setProperty('text-align',p.textAlign||'left','important');
     body.style.setProperty('color',p.ink||'#2b2b2b','important');
     body.style.setProperty('font-family',sharedFont,'important');
     body.style.setProperty('letter-spacing',Math.max(0,(+p.letterSpacing||0)*cssScale).toFixed(2)+'px','important');
     body.style.setProperty('--pk-body-indent',p.indent?'2em':'0');
     // Do not overwrite the live contenteditable node while an iOS keyboard is composing.
     if(st.inlineEditing && st.inlineBody===body)return;
     body.replaceChildren();
     for(const para of lines){
       const pp=document.createElement('p');pp.className='pk-css-paragraph';
       pp.textContent=para||' ';
       pp.style.textIndent=p.indent?'2em':'0';
       // Template CSS may style p separately. Shared controls must still win.
       for(const key of ['font-family','font-size','line-height','text-align','letter-spacing','color'])
         pp.style.setProperty(key,'inherit','important');
       body.appendChild(pp);
     }
   });

  if(templateId==='page_margin_note'){
    const original=root.querySelector('.pa-notes > .pa-note:not([data-pa-generated])');
    // Preserve in-place editing: don't replace contenteditable during typing.
    if(original && !(st.inlineEditing && st.inlineBody && root.contains(st.inlineBody))){
      const parent=original.parentElement;
      // A selected sentence can contain a line break before a closing quote.
      // Only meaningful text creates a note; never draw a new avatar for a lone ] / 】.
      // Keep brackets that really close the previous text, but drop duplicates.
      const textParts=marginNoteParts(raw);
      if(!textParts.length)textParts.push(' ');
      const fillNote=(note, value)=>{
        const body=note.querySelector('.pa-body');
        if(!body)return;
        const line=document.createElement('p');
        line.className='pk-css-paragraph';
        line.textContent=value;
        line.style.textIndent='0';
        body.replaceChildren(line);
        // This template intentionally uses red ink, independent of shared ink.
        body.style.setProperty('color','#aa414c','important');
        body.style.setProperty('line-height','1.65','important');
        note.querySelectorAll('.pa-author').forEach(el=>el.style.setProperty('color','#a63f4a','important'));
      };
      // Clone after the shared avatar/name binding, before changing the seed.
      // Preserve the CSS typography attached to the populated body.
      const prototype=original.cloneNode(true);
      fillNote(original,textParts[0]);
      for(const part of textParts.slice(1)){
        const note=prototype.cloneNode(true);
        note.dataset.paGenerated='1';
        // Generated notes are part of the full editable source, not disposable text.
        // Each note receives its own editor target; only the seed retains data-pk.
        note.querySelector('.pa-body')?.removeAttribute('data-pk');
        fillNote(note,part);
        parent.appendChild(note);
      }
    }
  }

  if(templateId==='imessage_dark') {
    // Model: work title = sender's initial blue messages; selected text =
    // received grey messages; optional kicker = a blue reply after the first
    // incoming line; note = the contact's saved name.
    const split=v=>String(v||'').replace(/\r/g,'').split(/\n+/).map(t=>t.trim()).filter(Boolean);
    const outgoing=root.querySelector('[data-pk="title"]');
    const incoming=root.querySelector('[data-pk="body"]');
    const contact=root.querySelector('[data-pk="note"]');
    if(contact) {
      contact.textContent=String(m.note||n.char||'联系人').trim();
      contact.style.setProperty('color','#f8f8f9','important');
      contact.style.setProperty('font-family','-apple-system,BlinkMacSystemFont,\"PingFang SC\",sans-serif','important');
    }
    const rawDate=String(date||'').trim();
    const timestamp=rawDate.match(/(?:^|\s)(\d{1,2}):(\d{2})(?:$|\s)/);
    let clock=timestamp ? timestamp[1].padStart(2,'0')+':'+timestamp[2]
       : new Date().toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',hour12:false});
    let displayedDate=rawDate;
    const day=rawDate.match(/^(\d{4})[\/.-](\d{1,2})[\/.-](\d{1,2})/);
    if(day){
      const now=new Date();
      const isToday=+day[1]===now.getFullYear()&&+day[2]===now.getMonth()+1&&+day[3]===now.getDate();
      displayedDate=(isToday?'今天':(+day[2])+'月'+(+day[3])+'日')+' '+clock;
    } else if(!rawDate) displayedDate='今天 '+clock;
    root.querySelectorAll('[data-pk="date"]').forEach(el=>{
      el.textContent=displayedDate;
      el.style.setProperty('color','#89898e','important');
    });
    const makeBubble=(value,side,tail=false)=>{
      const row=document.createElement('div');row.className='im-row im-'+side+(tail?' im-tail':'');
      const bubble=document.createElement('span');bubble.className='im-bubble';bubble.textContent=value;
      row.appendChild(bubble);return row;
    };
    const appendRows=(target,values,side)=>values.forEach((t,i)=>target.appendChild(makeBubble(t,side,i===values.length-1)));
    if(outgoing){
      outgoing.replaceChildren();appendRows(outgoing,split(String(title).replace(/[|｜]/g,'\n')),'out');
    }
    if(incoming&&!(st.inlineEditing&&st.inlineBody===incoming)){
      const left=imessageReceivedParts(st.chars.join(''));
      incoming.replaceChildren();
      const reply=split(String(subtitle).replace(/[|｜]/g,'\n'));
      if(reply.length){
        if(left.length)incoming.appendChild(makeBubble(left[0],'in',true));
        const group=document.createElement('div');group.className='im-reply-group';
        appendRows(group,reply,'out');incoming.appendChild(group);
        const receipt=document.createElement('div');receipt.className='im-read';receipt.textContent=clock+' 已讀';incoming.appendChild(receipt);
        appendRows(incoming,left.slice(1),'in');
      }else{
        const receipt=document.createElement('div');receipt.className='im-read';receipt.textContent=clock+' 已讀';
        incoming.appendChild(receipt);
        appendRows(incoming,left,'in');
      }
    }
    const avatar=root.querySelector('[data-pk="im-avatar"]');
    if(avatar){
      const mode=p.imessageAvatarMode||'system';
      const imageSrc=mode==='system'?'':postypeAvatarSrc({...p,postypeAvatarMode:mode,postypeAvatarImg:p.imessageAvatarImg||''});
      const old=avatar.querySelector('img.im-avatar-photo');
      avatar.classList.toggle('im-has-img',!!imageSrc);
      if(!imageSrc){if(old)old.remove();}
      else if(old?.getAttribute('src')!==imageSrc){
        if(old)old.remove();
        const img=document.createElement('img');img.className='im-avatar-photo';img.alt='联系人头像';
        if(!/^(?:data:|blob:)/.test(imageSrc))img.crossOrigin='anonymous';
        img.onerror=()=>{img.remove();avatar.classList.remove('im-has-img');};
        avatar.appendChild(img);img.src=imageSrc;
      }
    }
    root.querySelectorAll('[data-pk-section="im-photo"]').forEach(el=>{
      el.hidden=!p.imessageShowImage;
      el.classList.toggle('im-left',p.imessageImageSide==='left');
    });
    root.querySelectorAll('[data-pk="im-image"]').forEach(el=>{
      el.dataset.pkUpload='imessageImage';
      el.title='点击上传或替换消息图片';
      const src=String(p.imessageImage||'').trim();
      const old=el.querySelector('img.im-upload-photo');
      el.classList.toggle('im-has-img',!!src);
      if(!src){if(old)old.remove();}
      else if(old?.getAttribute('src')!==src){
        if(old)old.remove();
        const img=document.createElement('img');img.className='im-upload-photo';img.alt='聊天图片';
        if(!/^(?:data:|blob:)/.test(src))img.crossOrigin='anonymous';
        img.onerror=()=>{img.remove();el.classList.remove('im-has-img');};
        el.appendChild(img);img.src=src;
      }
    });
  }
}
function cssSpecSource(spec) {
  const meta={id:spec.id,name:cssTemplateName(spec.id,spec.name),width:spec.width,html:spec.html};
  return '/* @pk-template\n'+JSON.stringify(meta,null,2)+'\n@end-pk-template */\n\n'+spec.css;
}
function cssTemplateRecord() {
  const id=String(cur().pageSkin||'').slice(4);
  const spec=cssEntries()[id] || (!store().cssHidden?.[id] ? BUILTIN_CSS[id] : null) || null;
  return spec && typeof spec.html==='string' && typeof spec.css==='string' && spec.html.includes('data-pk="body"') ? spec : null;
}
function fillCssList(){
  if(!st.ov)return;
  const dest=st.ov.querySelector('.pk-css-list');if(!dest)return;
  dest.textContent='';
  const hidden=store().cssHidden || {};
  const entries=[{id:'punch',name:'打孔海报',builtIn:true},...Object.values(BUILTIN_CSS).map(r=>({...r,builtIn:true})),...Object.values(cssEntries()).filter(r=>r && typeof r==='object' && typeof r.id==='string' && typeof r.html==='string' && !BUILTIN_CSS[r.id]).map(r=>({...r,builtIn:false}))];
  entries.forEach(rec=>{
    if(rec.id!=='punch' && hidden[rec.id] && !cssEntries()[rec.id])return;
    const line=document.createElement('div');line.className='pk-css-item';
    const item=document.createElement('button');item.type='button';item.dataset.skin=rec.id==='punch'?'punch':'css:'+rec.id;
    item.innerHTML='<span class="pk-skin-name"></span><i class="fa-solid fa-check"></i>';
    item.querySelector('.pk-skin-name').textContent=cssTemplateName(rec.id, cssEntries()[rec.id]?.name||rec.name);
    line.append(item);
    if(rec.id!=='punch'){
      const exportBtn=document.createElement('button');exportBtn.type='button';exportBtn.dataset.cssexport=rec.id;exportBtn.textContent='导出';exportBtn.title='导出 CSS';line.append(exportBtn);
      const remove=document.createElement('button');remove.type='button';remove.dataset.cssdel=rec.id;remove.textContent='删除';remove.title='从模板列表隐藏或删除';line.append(remove);
    }
    dest.appendChild(line);
  });
  syncSkinSelection();
}
// Real CSS layout width. This changes line wrapping and the exported file,
// not just a visual transform on the preview.
function cssLayoutWidth(spec=cssTemplateRecord()) {
  const override=Number(cur().cssPageWidth);
  return Math.round(Number.isFinite(override) && override>=300 ? Math.min(900,override) : (+spec?.width||390));
}
function cssMountSheet(){
  if(!st.ov)return null;
  const spec=cssTemplateRecord();if(!spec)return null;
  const holder=st.ov.querySelector('.pk-css-holder');
  if(!holder)return null;
  let shadow=holder.shadowRoot;
  if(!shadow) shadow=holder.attachShadow({mode:'open'});
  const signature=cur().pageSkin+'|'+spec.css+'|'+spec.html;
  // The overlay can be recreated while the CSS signature is unchanged.
  if(st.cssSignature!==signature || !shadow.querySelector('.pk-css-page')){
    shadow.innerHTML='';
    const sheetStyle=document.createElement('style');sheetStyle.textContent=`:host{display:block}*{box-sizing:border-box} .pk-css-page{width:${spec.width}px;min-height:0;background:#fff;color:#171717;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;font-size:16px;line-height:1.7} [hidden]{display:none!important} .pk-css-page img{max-width:100%}\n`+spec.css;
    const page=document.createElement('div');page.className='pk-css-page';page.innerHTML=cssSafeMarkup(spec.html);
    shadow.append(sheetStyle,page);st.cssSignature=signature;
  }
  const page=shadow.querySelector('.pk-css-page');
  // Explicitly override template width: CSS !important declarations must not
  // make screen preview and exported layout disagree.
  page.style.setProperty('width',cssLayoutWidth(spec)+'px','important');
  cssFillTemplate(page,spec);
  cssApplyNaturalHeight(page);
  return {holder,shadow,page,spec};
}
// For every CSS template, the image height follows its rendered content.
// Older template skins sometimes set a 390/500/760px minimum on the outside
// wrapper. Those are display floors, not content, and caused blank exports.
// Preserve the template's *actual* top/bottom padding and inner layout.
function cssApplyNaturalHeight(page){
  page.style.setProperty('min-height','0px','important');
  page.style.setProperty('height','auto','important');
  // Only relax the outside layout shell; keep the real dimensions of
  // cover photos, embedded artwork, individual cards and chat bubbles.
  for(const root of page.children){
    root.style.setProperty('min-height','0px','important');
    // A few templates impose a second large screen-height floor on the
    // primary body region (for example iMessage chat and XHS comments).
    // Remove only these large floors, not smaller card/photo constraints.
    for(const region of root.children){
      const min=parseFloat(window.getComputedStyle(region).minHeight)||0;
      if(min>=300)region.style.setProperty('min-height','0px','important');
    }
  }
}
function cssContentHeight(page){
  cssApplyNaturalHeight(page);
  return Math.max(1,Math.ceil(page.scrollHeight));
}
function cssSize(){
  if(!st.ov||!cssActive())return;
  const sheet=st.ov.querySelector('.pk-css-holder');const page=sheet?.shadowRoot?.querySelector('.pk-css-page');
  const spec=cssTemplateRecord();if(!page||!spec)return;
  const stage=st.ov.querySelector('.pk-stage');
  // v30 hides the whole stage on its standalone settings screen. Its width is 0
  // during that state; measuring it produced the tiny POSTYPE preview on return.
  if (!stage || !stage.getClientRects().length || stage.clientWidth < 120) return;
  const cs=window.getComputedStyle(stage);
  const padding=(parseFloat(cs.paddingLeft)||0)+(parseFloat(cs.paddingRight)||0);
  const aw=Math.max(100,stage.clientWidth-padding);
  const width=cssLayoutWidth(spec);
  page.style.setProperty('width',width+'px','important');
  const scale=(aw/width)*(st.editing?1:st.zoom);
  const height=cssContentHeight(page);
  page.style.transformOrigin='top left';page.style.transform=`scale(${scale})`;
  sheet.style.width=(width*scale)+'px';sheet.style.height=(height*scale)+'px';
  st.W=width;st.H=height;st.tl=null;st.pieces=[];st.edgeY=null;
  if(st.editing)updateEditorBounds();
}
function renderImportedCss(){
  if(!st.ov)return;
  st.ov.classList.add('css-active');
  const r=cssMountSheet();
  if(!r){st.ov.classList.remove('css-active','pk-margin-scroll');return;}
  // Do not change the layout of other CSS templates.
  st.ov.classList.toggle('pk-margin-scroll',r.spec.id==='page_margin_note');
  cssSize();
  if(r.page.querySelector('img')){
    r.page.querySelectorAll('img').forEach(im=>{
      if(!im.complete){
        // Only one pending listener pair per image even after many renders.
        if(im.dataset.pkSizeWatch==='1')return;
        im.dataset.pkSizeWatch='1';
        const onSettle=()=>{delete im.dataset.pkSizeWatch;cssSize();};
        im.addEventListener('load',onSettle,{once:true});
        im.addEventListener('error',onSettle,{once:true});
      }
    });
  }
}
function cssUnMount(){ if(st.ov)st.ov.classList.remove('css-active','pk-margin-scroll'); }
// SVG foreignObject uses its own viewport for @media queries. Resolve those
// rules against the live preview viewport before serializing; otherwise a
// 640px export silently drops mobile text and gets cropped at the bottom.
function cssFlattenViewportMedia(styleElement){
  const rules=styleElement?.sheet?.cssRules;
  if(!rules)return styleElement?.textContent||'';
  const flatten=rules=>Array.from(rules).map(rule=>{
    if(rule.type===window.CSSRule.MEDIA_RULE){
      let matched=false;
      try{matched=window.matchMedia(rule.conditionText).matches;}catch(_){ }
      return matched?flatten(rule.cssRules):'';
    }
    if(rule.type===window.CSSRule.SUPPORTS_RULE){
      return '@supports '+rule.conditionText+'{'+flatten(rule.cssRules)+'}';
    }
    return rule.cssText;
  }).join('\n');
  return flatten(rules);
}

async function cssTemplateExport(){
  // Flush the same complete source used by the preview and the inline editor.
  if(st.inlineEditing)finishInlineEdit(true);
  const mounted=cssMountSheet();
  const root=mounted?.shadow;
  const page=mounted?.page,spec=mounted?.spec;
  if(!page||!spec)throw new Error('CSS 页面尚未准备好');
  const raw=st.chars.join('');
  const originalSkin=cur().pageSkin;
  const originalSettings=JSON.stringify(cur());
  const ensureCurrent=()=>{
    if(!page.isConnected||st.chars.join('')!==raw||cur().pageSkin!==originalSkin
      ||JSON.stringify(cur())!==originalSettings||st.inlineEditing)
      throw new Error('导出期间页面已修改，请重新点击导出，避免保存旧内容');
  };
  if(spec.id==='page_margin_note'){
    const expected=marginNoteParts(raw).length;
    const actual=page.querySelectorAll('.pa-notes > .pa-note').length;
    if(expected && actual!==expected)throw new Error('批注段落未完整渲染，请重新打开预览后再导出');
  }else if(spec.id==='imessage_dark'){
    const expected=imessageReceivedParts(raw).length;
    const actual=page.querySelectorAll('.im-body > .im-row.im-in').length;
    if(actual!==expected)throw new Error('iMessage 气泡未完整渲染，请重新打开预览后再导出');
  }
  const w=cssLayoutWidth(spec);
  page.style.setProperty('width',w+'px','important');
  // Image aspect ratios can change layout after loading. Wait before taking
  // the final dimensions, otherwise previews may fit but PNGs get clipped.
  await Promise.all(Array.from(page.querySelectorAll('img')).map(async im=>{
    if(!im.getAttribute('src') || im.complete)return;
    try{await im.decode();}catch{}
  }));
  // A failed iMessage upload removes its IMG and leaves the placeholder behind;
  // without this check the PNG could silently omit a specifically chosen photo.
  if(spec.id==='imessage_dark' && cur().imessageShowImage && String(cur().imessageImage||'').trim()){
    const photos=Array.from(page.querySelectorAll('[data-pk="im-image"] img.im-upload-photo'));
    if(!photos.length || !photos.some(im=>im.naturalWidth>0))
      throw new Error('iMessage 聊天图片加载失败，请重新上传图片后导出');
  }
  // The preview and PNG must use the same final geometry, after fonts/images
  // have settled. A brief timeout avoids hanging indefinitely on an offline font.
  if(document.fonts?.ready){
    try{await Promise.race([document.fonts.ready,new Promise(done=>setTimeout(done,1200))]);}catch(_){ }
  }
  ensureCurrent();
  const h=cssContentHeight(page);
  if(h>7000)throw new Error('内容超过单张图片支持的高度，请减少段落后分批导出');
  const pageBox=page.getBoundingClientRect();
  // Use rendered geometry so relative positions are identical in preview/export,
  // even when the preview is scaled to fit a phone screen.
  const sx=w/Math.max(1,pageBox.width),sy=sx;
  const rectOf=node=>{
    const r=node.getBoundingClientRect();
    return {x:(r.left-pageBox.left)*sx,y:(r.top-pageBox.top)*sy,w:r.width*sx,h:r.height*sy};
  };
  const pictures=[];
  const blank='data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=';
  const clone=page.cloneNode(true);
  // Collect and load the *real* photos before drawing: WebKit often loses
  // nested <img> tags when serializing HTML inside SVG foreignObject.
  const realPhotos=Array.from(page.querySelectorAll('img'));
  const copyPhotos=Array.from(clone.querySelectorAll('img'));
  const missingPhotos=[];
  const photoLoads=realPhotos.map(async(node,i)=>{
    const src=node.currentSrc||node.getAttribute('src')||node.src;
    if(!src)return;
    const visual=rectOf(node);
    if(visual.w<=0||visual.h<=0)return;
    const host=node.parentElement;
    const clipHost=host && (getComputedStyle(host).overflow==='hidden'||getComputedStyle(host).overflowX==='hidden')?host:null;
    const clipBox=clipHost?rectOf(clipHost):null;
    const radius=clipHost?getComputedStyle(clipHost).borderRadius:'0';
    const css=window.getComputedStyle(node);
    const fit=css.objectFit||'fill',position=(css.objectPosition||'50% 50%').split(/\s+/);
    const pct=v=>v?.endsWith('%')?Math.max(0,Math.min(1,parseFloat(v)/100)):0.5;
    const posX=pct(position[0]),posY=pct(position[1]||position[0]);
    let image=node;
    if(!node.complete||!node.naturalWidth){
      image=new Image();if(!src.startsWith('data:')&&!src.startsWith('blob:'))image.crossOrigin='anonymous';
      image.src=src;
      try{await image.decode();}catch{ missingPhotos.push(src); return; }
    }
    if(!image.naturalWidth||!image.naturalHeight){ missingPhotos.push(src); return; }
    pictures.push({image,visual,clipBox,radius,fit,posX,posY});
    // The opaque image is drawn separately after the HTML SVG has been rendered.
    // This also prevents huge embedded photos from exhausting WebKit memory.
    if(copyPhotos[i])copyPhotos[i].setAttribute('src',blank);
  });
  await Promise.all(photoLoads);
  if(missingPhotos.length)throw new Error('有 '+missingPhotos.length+' 张图片加载失败，已停止导出，避免生成缺图海报。请重新上传或检查图片链接');
  // Even failed remote assets must not be serialized as untrusted URLs.
  copyPhotos.forEach(img=>img.setAttribute('src',blank));
  clone.style.transform='none';
  const wrapper=document.createElement('div');wrapper.setAttribute('xmlns','http://www.w3.org/1999/xhtml');
  wrapper.style.cssText=`width:${w}px;height:${h}px;overflow:hidden;background:#fff`;
  const sty=document.createElement('style');
  sty.textContent=cssFlattenViewportMedia(root.querySelector('style'));
  wrapper.append(sty,clone);
  const serialized=new XMLSerializer().serializeToString(wrapper);
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><foreignObject width="100%" height="100%">${serialized}</foreignObject></svg>`;
  const data='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);
  const budget=/iPhone|iPad|iPod/.test(window.navigator?.userAgent||'')?4800000:9500000;
  const density=(+cur().width||1080)/390;
  const ratio=Math.min(density,Math.sqrt(budget/(w*h)));
  let failedPaints=0;
  const drawImages=(ctx)=>{
    for(const p of pictures){
      const b=p.visual,clip=p.clipBox;
      try{
        ctx.save();
        if(clip){
          const r=p.radius==='50%'?Math.min(clip.w,clip.h)/2:Math.max(0,Math.min(clip.w/2,parseFloat(p.radius)||0));
          ctx.beginPath();
          if(typeof ctx.roundRect==='function')ctx.roundRect(clip.x,clip.y,clip.w,clip.h,r);
          else ctx.rect(clip.x,clip.y,clip.w,clip.h);
          ctx.clip();
        }
        let x=b.x,y=b.y,width=b.w,height=b.h;
        const iw=p.image.naturalWidth,ih=p.image.naturalHeight;
        if(p.fit==='contain'||p.fit==='cover'){
          const k=p.fit==='contain'?Math.min(width/iw,height/ih):Math.max(width/iw,height/ih);
          const destW=iw*k,destH=ih*k;
          x+=(width-destW)*p.posX;y+=(height-destH)*p.posY;
          width=destW;height=destH;
        }
        ctx.drawImage(p.image,x,y,width,height);
      }catch(e){ failedPaints++; }
      finally{ctx.restore();}
    }
    // The page counter must stay above the image (it is part of the CSS UI).
    if(String(spec.id)==='xhs_note'){
      const badge=page.querySelector('.xhs-pagecount');
      if(badge){
        const b=rectOf(badge),css=getComputedStyle(badge);
        if(b.w>0&&b.h>0){
          ctx.save();
          ctx.fillStyle=css.backgroundColor&&css.backgroundColor!=='rgba(0, 0, 0, 0)'?css.backgroundColor:'#999aa0';
          ctx.beginPath();if(ctx.roundRect)ctx.roundRect(b.x,b.y,b.w,b.h,b.h/2);else ctx.rect(b.x,b.y,b.w,b.h);ctx.fill();
          const fontSize=(parseFloat(css.fontSize)||14),weight=css.fontWeight||'400';
          ctx.font=weight+' '+fontSize+'px '+(css.fontFamily||'sans-serif');
          ctx.fillStyle=css.color||'#fff';ctx.textAlign='center';ctx.textBaseline='middle';
          ctx.fillText(badge.textContent.trim(),b.x+b.w/2,b.y+b.h/2);
          ctx.restore();
        }
      }
    }
  };
  return new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>{
      try{
        const c=document.createElement('canvas');c.width=Math.round(w*ratio);c.height=Math.round(h*ratio);
        const ctx=c.getContext('2d');
        ctx.setTransform(ratio,0,0,ratio,0,0);
        ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);
        ctx.drawImage(img,0,0,w,h);
        drawImages(ctx);
        if(failedPaints)throw new Error('有 '+failedPaints+' 张图片绘制失败，请重新上传后导出');
        const url=c.toDataURL('image/png');
        if(!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(url))throw new Error('导出图片编码失败，iOS WebKit 可能限制 CSS 页面截图');
        resolve(url);
      }catch(e){reject(e);}
    };
    img.onerror=()=>reject(new Error('CSS 页面无法转换成 PNG（请检查字体和资源）'));
    img.src=data;
  });
}
function activePageTemplate() {
  const p=cur();
  return p.pageSkin||'punch';
}
function skinTabs() {
  return '<div class="pk-css-list pk-skin-list pk-skin-list-flat"></div>';
}
function syncSkinSelection() {
  if (!st.ov) return;
  const active=activePageTemplate();
  st.ov.querySelectorAll('[data-skin]').forEach(el=>el.classList.toggle('on',el.dataset.skin===active));
}
// Helpers retained for imported CSS templates.
function postypeAvatarSrc(p) {
  const mode=p.postypeAvatarMode||'char';
  if(mode==='initial') return '';
  if(mode==='custom') return typeof p.postypeAvatarImg==='string'?p.postypeAvatarImg:'';
  const c=ctx(), side=mode==='user'?'user':'char';
  const resolve=(raw)=>{
    if(typeof raw!=='string'||!raw.trim())return '';
    raw=raw.trim();
    if(/^(?:data:|blob:|https?:\/\/|\/)/i.test(raw))return raw;
    // Character and persona cards use image filenames, never use the author's
    // printed name as an image URL.
    const clean=raw.replace(/^\.?\/?(?:characters\/|User Avatars\/)/i,'');
    const dir=side==='user'?'User Avatars':'characters';
    return '/'+dir+'/'+clean.split('/').map(encodeURIComponent).join('/');
  };
  if(side==='char') {
    const chars=c.characters||[];
    const idx=c.characterId??c.characterIndex;
    const byId=chars?.[idx];
    const byName=chars.find?.(v=>v?.name && (v.name===st.speaker||v.name===c.name2));
    const actor=byId?.avatar?byId:byName;
    const raw=actor?.avatar||actor?.avatar_url||c.characterAvatar||'';
    if(raw)return resolve(raw);
  }else {
    const raw=c.userAvatar||c.user_avatar||c.personaAvatar||c.persona_avatar||'';
    if(raw)return resolve(raw);
  }
  const selectors=side==='user'
    ? ['.mes.is_user .avatar img','.mes[is_user="true"] .avatar img','#user_avatar_block img','.avatar img[src*="User%20Avatars"]','.user_avatar img','.st-user-avatar img']
    : ['.mes:not(.is_user) .avatar img','.mes[is_user="false"] .avatar img','#character_avatar img','.avatar img[src*="/characters/"]','.ch_avatar img','.st-char-avatar img','.character_select .avatar img'];
  for(const selector of selectors){
    const images=Array.from(document.querySelectorAll(selector));
    for(let i=images.length-1;i>=0;i--){
      const el=images[i], u=el?.currentSrc||el?.getAttribute('src')||el?.src;
      if(u && !/default-avatar|unknown-avatar/i.test(u))return u;
    }
  }
  return '';
}

function render(preview) {
  // A deleted template can remain in undo history or an older preset. Avoid a blank preview.
  if(cssActive() && !cssTemplateRecord()) {
    cur().pageSkin='punch'; persist(); syncSkinSelection();
    if(isOpen()) toast('warning','原 CSS 模板已不存在，已改用打孔海报');
  }
  if (cssActive()) return renderImportedCss();
  cssUnMount();
  if ((cur().pageSkin || 'punch') !== 'punch') cur().pageSkin = 'punch';
  if (!st.canvas) return;
  st.previewMode = !!preview;
  const p = cur(), cv = st.canvas, g = cv.getContext('2d');
  // Use the same logical page width for native Canvas and CSS templates.
  // 'width' controls export density; cssPageWidth controls real composition width.
  const W = Math.round((+p.width || 1080) * cssLayoutWidth() / 390), font = fontStack(p);
  // Content-first height: the selected text and scraps decide the poster's length.
  const single = p.layoutMode === 'single';
  const effectiveSigPlace = single ? 'text' : p.sigPlace;
  const showPieces = !single || !!p.singleScraps;
  const activeEditorial = single && !!p.pubOn && (!st.editing || st.inlineEditing);
  const split = Math.min(0.85, Math.max(0.12, +p.split || 0.45));
  // Honor the divider's saved position; 0.45 preserves the old default layout.
  const baseColH = single ? 0 : Math.max(190,Math.round(W * 0.38 * split / 0.45));
  const baseTextH = Math.max(160, Math.round(p.padY * 2 + p.fontSize * 2.2));
  let colH = baseColH;
  const sigs = sigLines(p);
  let fs = +p.fontSize;
  let sigFs = Math.round(fs * p.sigSize), sigLH = sigFs * 1.6;
  const sigPad = Math.max(40, p.padX * 0.6);
  let sigArea = sigs.length ? sigs.length * sigLH + sigPad : 0;
  // The collage grows vertically when a grid would otherwise cancel the size slider.
  // Its width is fixed: a large row automatically wraps to the next line.
  if (!single && st.holes.length && (p.arrange === 'rows' || p.arrange === 'column')) {
    const [wantedW, wantedH] = holeDims(p, fs);
    const usableW = W - 2 * p.padX;
    const desired = layoutScraps(p, wantedW, wantedH, usableW);
    const reserve = effectiveSigPlace === 'scrap' ? Math.max(36, sigArea) : 36;
    colH = Math.max(colH, Math.min(4500, Math.ceil(desired.bh / 0.92 + reserve + 72)));
  }
  let reserveSig = (effectiveSigPlace === 'text' && sigs.length && (!activeEditorial || p.pubSigPosition === 'footer')) ? sigArea : 0;
  let T = layoutText(g, p, font, W, fs);
  if (activeEditorial) T = layoutEditorial(g, p, T, fs, font, sigFs, sigLH, sigs);
  // 长文不再强行挤进固定画幅：正文区随内容向下延长。
  // 对极端超长消息仍限定画布高度，避免移动端 Canvas 内存溢出。
  const maxTextH = Math.max(baseTextH, 9500 - colH);
  while (p.padY * 2 + T.h + reserveSig > maxTextH && fs > 14) {
    fs = Math.max(14, Math.floor(fs * 0.93));
    sigFs = Math.round(fs * p.sigSize);
    sigLH = sigFs * 1.6;
    sigArea = sigs.length ? sigs.length * sigLH + sigPad : 0;
    reserveSig = (effectiveSigPlace === 'text' && sigs.length && (!activeEditorial || p.pubSigPosition === 'footer')) ? sigArea : 0;
    T = layoutText(g, p, font, W, fs);
    if (activeEditorial) T = layoutEditorial(g, p, T, fs, font, sigFs, sigLH, sigs);
  }
  const needH = Math.ceil(p.padY * 2 + T.h + reserveSig);
  const textH = Math.max(baseTextH, Math.min(needH, maxTextH));
  const H = colH + textH;
  const top = !single && p.scrapPos === 'top';
  const textY = single ? 0 : (top ? colH : 0), colY = single ? 0 : (top ? 0 : textH);
  // iOS WebKit has a modest canvas memory budget. For very long pages,
  // reduce bitmap resolution instead of allocating enormous backing stores.
  // All layout / hit-testing remain in logical W x H coordinates.
  const isIOS = /iPad|iPhone|iPod/.test(window.navigator?.userAgent || '');
  const pixelBudget = isIOS ? 5500000 : 11000000;
  const bitmapScale = Math.min(1, Math.sqrt(pixelBudget / (W * H)));
  const bw = Math.max(1, Math.floor(W * bitmapScale));
  const bh = Math.max(1, Math.floor(H * bitmapScale));
  // Keep the existing bitmap during slider drags instead of reallocating it.
  if (cv.width !== bw) cv.width = bw;
  if (cv.height !== bh) cv.height = bh;
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.clearRect(0, 0, bw, bh);
  g.setTransform(bw / W, 0, 0, bh / H, 0, 0);
  Object.assign(st, { W, textY, textH, edgeY: single ? null : (top ? colH : textH), H });

  // The image belongs only to the scrap area, never the full poster.
  // Keep the backing colour/texture across the poster for punched-out holes.
  g.fillStyle = p.backColor;
  g.fillRect(0, 0, W, H);
  const scrapImg = single ? null : imgOf(p.backImg);
  if (scrapImg) drawCover(g, scrapImg, 0, colY, W, colH,
    p.backImgScale, p.backImgX, p.backImgY);
  if (p.backTex && p.backTex !== 'none') {
    g.fillStyle = g.createPattern(texCanvas(p.backTex), 'repeat');
    g.fillRect(0, 0, W, H);
  }

  // Paint the paper directly. Fragments later sample the same source layer
  // with local transforms; no full-size offscreen canvases are necessary.
  const paperImg = imgOf(p.paperImg);
  const paperStyle = { scale:p.paperImgScale, x:p.paperImgX, y:p.paperImgY };
  g.save();
  g.translate(0, textY);
  fillLayer(g, 0, 0, W, textH, p.paperColor, p.paperTex, paperImg, paperStyle);
  g.restore();

  const vertical = single ? ({ top:0, middle:0.5, bottom:1 }[p.textVAlign] ?? 0.5) : 0.5;
  const ty = +p.padY + Math.max(0, textH - needH) * vertical;
  st.tl = { x: T.boxX, y: textY + ty, w: T.boxW, h: T.h, fs, lh: T.lh, font };
  if (activeEditorial) paintEditorial(g,p,T,font,ty,textY);
  const [hw, hh] = holeDims(p, fs);
  st.hole = [hw, hh];
  const holeMap = new Map(st.editing ? [] : st.holes.map((h, k) => [h.i, { br: h.br, k }]));
  const rects = [];
  T.boxes.forEach(b => {
    b.y0 = textY + ty + b.line * T.lh + (b.flowShift || 0); b.y1 = b.y0 + T.lh;
    const h = holeMap.get(b.i);
    if (!h) return;
    rects[h.k] = { x: b.ax + b.w / 2 - hw / 2, y: ty + b.line * T.lh + (b.flowShift || 0) + T.lh / 2 - hh / 2, w: hw, h: hh, k: h.k, br: h.br };
  });
  const frects = (st.editing ? [] : st.free).map(f => ({ x: f.x - hw / 2, y: f.y - hh / 2, w: hw, h: hh, k: 300 + f.id, id: f.id }));
  const all = rects.filter(Boolean).concat(frects);
  // Repaint just the holes from the backing color / texture. The backing
  // photo is intentionally limited to the scrap area, never to the holes.
  const backingPattern = p.backTex && p.backTex !== 'none' ? g.createPattern(texCanvas(p.backTex), 'repeat') : null;
  all.forEach(r => {
    const path = shapePath(p.holeShape, r.x, textY + r.y, r.w, r.h, r.k);
    g.save(); g.clip(path);
    g.fillStyle = p.holeMode === 'color' ? p.holeColor : p.backColor;
    g.fillRect(r.x, textY + r.y, r.w, r.h);
    if (p.holeMode !== 'color' && backingPattern) {
      g.fillStyle = backingPattern;
      g.fillRect(r.x, textY + r.y, r.w, r.h);
    }
    g.restore();
  });
  all.forEach(r => {
    if (p.holeShade) {
      g.save(); g.clip(shapePath(p.holeShape, r.x, textY + r.y, r.w, r.h, r.k));
      g.fillStyle = 'rgba(0,0,0,.12)'; g.fillRect(r.x, textY + r.y, r.w, r.h * 0.1); g.fillRect(r.x, textY + r.y, r.w * 0.06, r.h);
      g.restore();
    }
    if (preview && r.br) {
      const m = fs * 0.3, bx = r.x + r.w, by = textY + r.y + r.h;
      g.fillStyle = '#d24a3a';
      g.beginPath(); g.moveTo(bx, by); g.lineTo(bx - m, by); g.lineTo(bx, by - m); g.closePath(); g.fill();
    }
  });
  g.font = `${fs}px ${font}`; g.textBaseline = 'middle'; g.textAlign = 'left'; g.fillStyle = p.ink;
  if (!st.editing) T.boxes.forEach(b => { if (!holeMap.has(b.i)) g.fillText(b.ch, b.ax, (b.y0 + b.y1) / 2); });
  st.boxes = T.boxes;

  const areaTop = single ? textY + 36 : colY + 36;
  const areaBot = single ? textY + textH - Math.max(40, sigArea) : colY + colH - (effectiveSigPlace === 'scrap' ? Math.max(36, sigArea) : 36);
  const areaH = Math.max(40, areaBot - areaTop), maxW = W - 2 * p.padX;
  let [sw, sh] = holeDims(p, fs);
  const ccx = W / 2, ccy = (areaTop + areaBot) / 2;
  const pieces = [];
  const placed = [];
  if ((st.editing && !st.inlineEditing) || !showPieces) { /* 单区默认只有孔洞，不画碎片 */ } else if (p.arrange !== 'scatter' && st.holes.length) {
    const S = layoutScraps(p, sw, sh, maxW);
    const f = Math.min(1, maxW / (S.bw || 1), areaH * 0.92 / (S.bh || 1));
    sw *= f; sh *= f;
    S.items.forEach(it => {
      const x = ccx + it.x * f, y = ccy + it.y * f;
      placed.push([x, y]);
      pieces.push({ key: 'h' + st.holes[it.k].i, k: it.k, ch: st.chars[st.holes[it.k].i], crop: rects[it.k], x, y, rot: it.rot });
    });
  }
  const loose = [];
  if ((!st.editing || st.inlineEditing) && showPieces && p.arrange === 'scatter') st.holes.forEach((h, k) => loose.push({ key: 'h' + h.i, k, ch: st.chars[h.i], crop: rects[k] }));
  if (showPieces) frects.forEach(r => loose.push({ key: 'f' + r.id, k: r.k, ch: '', crop: r }));
  for (let d = 0; showPieces && d < +p.deco; d++) {
    const k = 500 + d;
    loose.push({ key: 'd' + d, k, ch: '', crop: { x: rnd(k + st.seed, 11) * (W - hw), y: rnd(k + st.seed, 12) * Math.max(1, textH - hh), w: hw, h: hh } });
  }
  const x0 = p.padX * 0.6 + sw / 2, x1 = W - p.padX * 0.6 - sw / 2;
  const y0 = areaTop + sh / 2, y1 = Math.max(y0, areaBot - sh / 2);
  const minD = Math.max(sw, sh) * 1.2;
  loose.forEach(it => {
    const sd = keySeed(it.key) + st.seed * 131;
    let best = [x0, y0], bestD = -1;
    for (let a = 0; a < 30; a++) {
      const x = x0 + rnd(sd + a, 61) * (x1 - x0), y = y0 + rnd(sd + a, 62) * (y1 - y0);
      const d = placed.length ? Math.min(...placed.map(q => Math.hypot(q[0] - x, q[1] - y))) : Infinity;
      if (d >= minD) { best = [x, y]; break; }
      if (d > bestD) { bestD = d; best = [x, y]; }
    }
    placed.push(best);
    pieces.push(Object.assign(it, { x: best[0], y: best[1], rot: (rnd(sd, 63) - 0.5) * 2 * p.scrapTilt * 1.5 }));
  });

  const ss = Math.min(sw, sh) * 0.86;
  st.pieces = [];
  pieces.forEach(pc => {
    const o = st.off[pc.key] || { x: 0, y: 0 };
    const x = pc.x + o.x, y = pc.y + o.y, crop = pc.crop || { x: 0, y: 0, w: hw, h: hh };
    const jitter = +p.scrapVar || 0;
    const scale = Math.max(0.45, 1 + (rnd(keySeed(pc.key), 97) - 0.5) * 2 * jitter);
    const pw = sw * scale, ph = sh * scale, pss = ss * scale;
    st.pieces.push({ key: pc.key, x, y, w: pw, h: ph });
    g.save();
    g.translate(x, y); g.rotate(pc.rot);
    const path = shapePath(p.holeShape, -pw / 2, -ph / 2, pw, ph, pc.k);
    if (p.scrapShadow) {
      g.shadowColor = 'rgba(0,0,0,.28)'; g.shadowBlur = 8; g.shadowOffsetX = 2; g.shadowOffsetY = 3;
      g.fillStyle = p.paperColor; g.fill(path);
      g.shadowColor = 'transparent';
    }
    g.clip(path);
    // Sample the original paper region directly through the clipped shape.
    // This costs no extra large canvas even when the source page is long.
    g.save();
    g.translate(-pw / 2, -ph / 2);
    g.scale(pw / crop.w, ph / crop.h);
    g.translate(-crop.x, -crop.y);
    fillLayer(g, 0, 0, W, textH, p.paperColor, p.paperTex, paperImg, paperStyle);
    g.restore();
    if (pc.ch) {
      g.font = `${pss}px ${font}`; g.fillStyle = p.ink; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(pc.ch, (rnd(pc.k, 4) - 0.5) * 3 * scale, (rnd(pc.k, 5) - 0.5) * 3 * scale + pss * 0.03);
    }
    g.restore();
  });

  if (sigs.length && (!activeEditorial || p.pubSigPosition === 'footer')) {
    g.font = `${sigFs}px ${font}`; g.fillStyle = p.sigColor; g.textBaseline = 'middle';
    const sigEdge = Math.min(60, Math.max(22, W * 0.035));
    const sx = { left: sigEdge, center: W / 2, right: W - sigEdge }[p.sigAlign] ?? W - sigEdge;
    const base = effectiveSigPlace === 'text'
      ? (textY + textH - sigPad * 0.55)
      : (colY + colH - sigPad * 0.6);
    sigs.forEach((t, i) => spacedText(g, t, sx, base - (sigs.length - i - 0.5) * sigLH, sigFs * 0.12, p.sigAlign));
  }

  if (preview && !st.editing && !single) {
    const hy = st.edgeY;
    g.save();
    g.shadowColor = 'rgba(0,0,0,.25)'; g.shadowBlur = 10; g.shadowOffsetY = 2;
    g.fillStyle = 'rgba(255,255,255,.96)';
    g.fill(shapePath('round', W / 2 - 70, hy - 10, 140, 20, 0));
    g.restore();
    g.fillStyle = 'rgba(0,0,0,.35)';
    [-20, 0, 20].forEach(dx => { g.beginPath(); g.arc(W / 2 + dx, hy, 3.5, 0, Math.PI * 2); g.fill(); });
  }
  if (st.editing) updateEditorBounds();
}

function insertHole(i) {
  let at = st.holes.findIndex(h => h.i > i);
  if (at < 0) at = st.holes.length;
  st.holes.splice(at, 0, { i, br: false });
}
function toggle(i) {
  if (/\s/.test(st.chars[i])) return;
  const k = st.holes.findIndex(h => h.i === i);
  if (k < 0) insertHole(i);
  else if (!st.holes[k].br) st.holes[k].br = true;
  else st.holes.splice(k, 1);
  schedule(); historyPush();
}
function randomHoles(n) {
  const taken = new Set(st.holes.map(h => h.i)), pool = [];
  st.chars.forEach((c, i) => { if (!NO_RANDOM.test(c) && !taken.has(i)) pool.push(i); });
  for (let t = 0; t < n && pool.length; t++) insertHole(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
  render(true); updatePreviewZoom(); historyPush('random');
}
function matchSentence(str) {
  st.holes = []; st.off = {};
  const used = new Set(), miss = [];
  let pos = 0;
  const find = (ch, from) => { for (let j = from; j < st.chars.length; j++) if (st.chars[j] === ch && !used.has(j)) return j; return -1; };
  for (const ch of Array.from(str.replace(/\r/g, ''))) {
    if (ch === '/' || ch === '\n') { if (st.holes.length) st.holes[st.holes.length - 1].br = true; continue; }
    if (/\s/.test(ch)) continue;
    let i = find(ch, pos);
    if (i < 0) i = find(ch, 0);
    if (i < 0) { miss.push(ch); continue; }
    used.add(i); st.holes.push({ i, br: false }); pos = i + 1;
  }
  render(true); updatePreviewZoom(); historyPush('match');
  if (miss.length) toast('warning', '正文里找不到：' + miss.join(''));
}
function hitTest(e) {
  const r = st.canvas.getBoundingClientRect();
  const x = (e.clientX - r.left) * st.W / r.width;
  const y = (e.clientY - r.top) * st.H / r.height;
  return st.boxes.find(b => x >= b.ax - 2 && x <= b.ax + b.w + 2 && y >= b.y0 && y <= b.y1);
}

function loadMessage(id, selText) {
  const m = ctx().chat[id], picked = normalize(selText || '');
  if (!m || !picked) return false;
  st.isUser = !!m.is_user; st.speaker = m.name || '';
  st.base = picked;
  st.custom = null; st.customIsRendered=false; st.raw = '\u0000';
  buildText();
  return true;
}

function upload(file, cb, preserveAlpha = false) {
  // Preserve the existing click-to-upload behavior; report errors rather than
  // silently leaving an empty placeholder when HEIC/unsupported files fail.
  if(!file)return;
  const valid=/^image\//i.test(file.type||'') || /\.(?:png|jpe?g|gif|webp|bmp|heic|heif|avif)$/i.test(file.name||'');
  if(!valid){toast('error','请选择图片文件');return;}
  if(file.size>40*1024*1024){toast('error','图片超过 40 MB，请先压缩');return;}
  const fr=new FileReader();
  const bad=()=>toast('error','图片读取失败或格式不支持，请尝试 JPG / PNG');
  fr.onerror=bad;
  fr.onload=()=>{
    const im=new Image();
    im.onerror=bad;
    im.onload=()=>{
      try{
        if(!im.width||!im.height)throw Error('空白图片');
        const max=1600,r=Math.min(1,max/Math.max(im.width,im.height));
        const c=document.createElement('canvas');
        c.width=Math.max(1,Math.round(im.width*r));
        c.height=Math.max(1,Math.round(im.height*r));
        const g=c.getContext('2d');
        if(!g)throw Error('Canvas 不可用');
        g.drawImage(im,0,0,c.width,c.height);
        // Preserve transparency for all PNG/WebP assets, including CSS avatars
        // and page illustrations, rather than flattening them to black-backed JPEGs.
        const kind=preserveAlpha||/image\/(png|webp|gif|avif)/i.test(file.type)
          ?'image/png':'image/jpeg';
        const output=c.toDataURL(kind,.85);
        if(!/^data:image\/(?:png|jpeg);base64,[A-Za-z0-9+/=]+$/.test(output))throw Error('图片转换失败');
        cb(output);
      }catch(_){bad();}
    };
    im.src=fr.result;
  };
  try{fr.readAsDataURL(file);}catch(_){bad();}
}

function download(url, name) {
  const a = document.createElement('a');
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
}

const ui = {
  sl: (label, k, min, max, step) => `<div class="pk-row pk-tunable"><span class="pk-l">${label}</span><div class="pk-sl" data-sl="${k}" data-min="${min}" data-max="${max}" data-step="${step}"><div class="pk-sl-tr"><div class="pk-sl-fill"></div></div><div class="pk-sl-th"></div></div><span class="pk-v" data-v="${k}"></span><button class="pk-tune-open" type="button" data-tune="${k}" title="在预览中调整" aria-label="预览调节${label}">↗</button></div>`,
  seg: (label, k, opts) => `<div class="pk-row"><span class="pk-l">${label}</span><div class="pk-seg" data-seg="${k}">${opts.map(([v, t]) => `<b data-v="${v}">${t}</b>`).join('')}</div></div>`,
  tg: (label, k) => `<div class="pk-row pk-tgrow"><span class="pk-l">${label}</span><div class="pk-tg" data-tg="${k}"><i></i></div></div>`,
  col: (label, k) => `<label class="pk-col"><input type="color" data-col="${k}"><span data-colv="${k}"></span><em>${label}</em></label>`,
  pick: (label, k, list, cls) => `${label ? `<div class="pk-sub">${label}</div>` : ''}<div class="pk-pick ${cls || ''}" data-pick="${k}">${list.map(([v, t]) => `<b data-v="${v}"><i></i><span>${t}</span></b>`).join('')}</div>`,
  inp: (label, k, ph) => `<div class="pk-row"><span class="pk-l">${label}</span><input class="pk-in" data-k="${k}" placeholder="${ph || ''}" autocomplete="off"></div>`,
  img: (label, k) => `<div class="pk-row"><span class="pk-l">${label}</span><input class="pk-in" data-img="${k}" placeholder="图片链接" autocomplete="off"><div class="pk-btn pk-sm" data-up="${k}">上传</div><div class="pk-btn pk-sm pk-ghost" data-clr="${k}">清除</div></div>
    <div class="pk-img-adjust" data-img-adjust="${k}" hidden>
      ${ui.sl('缩放', k+'Scale', 0.5, 3, 0.05)}
      ${ui.sl('左右', k+'X', 0, 100, 1)}
      ${ui.sl('上下', k+'Y', 0, 100, 1)}
      <div class="pk-row pk-btns"><div class="pk-btn pk-ghost" data-imgreset="${k}"><i class="fa-solid fa-rotate-left"></i> 重置位置</div></div>
    </div>`,
  grp: (title, body, open) => `<div class="pk-grp${open ? ' open' : ''}"><header data-fold="1"><span>${title}</span><i class="fa-solid fa-chevron-down pk-arrow"></i></header><div class="pk-grp-b">${body}</div></div>`,
};

function shapeThumb(shape) {
  const c = document.createElement('canvas');
  c.width = c.height = 72;
  const q = c.getContext('2d');
  q.fillStyle = '#5b6168';
  q.fill(shapePath(shape, 14, 14, 44, 44, 3));
  return c.toDataURL();
}

// 编辑框直接叠在海报正文的真实坐标上，不改原消息，只改本张海报。
function updateEditorBounds() {
  if(cssActive() && st.editing && st.ov){
    const ta=st.ov.querySelector('.pk-edta');
    Object.assign(ta.style,{left:'12px',top:'12px',width:'calc(100% - 24px)',height:'calc(100% - 24px)',transform:'none',fontSize:'17px',lineHeight:'1.65',background:'#fff'});
    return;
  }
  if (!st.editing || !st.ov || !st.tl || !st.canvas) return;
  const cv = st.canvas, ta = st.ov.querySelector('.pk-edta');
  const p = cur(), tl = st.tl;
  const r = cv.getBoundingClientRect(), stage = st.ov.querySelector('.pk-stage'), sr = stage.getBoundingClientRect();
  if (!r.width || !cv.width) return;
  const k = r.width / (st.W || cv.width);
  // iPhone 小字号输入自动放大页面：内部用 >=16px，视觉上缩回海报大小。
  const ios = /iP(hone|ad|od)/.test(window.navigator.userAgent) ||
    (window.navigator.platform === 'MacIntel' && window.navigator.maxTouchPoints > 1);
  const zoom = ios ? 1 : Math.max(1, 16 / Math.max(1, tl.fs * k));
  const targetFont = ios ? Math.max(16, tl.fs * k) : tl.fs * k * zoom;
  const editH = Math.max(tl.lh * 2, st.textY + st.textH - p.padY * 0.55 - tl.y);
  Object.assign(ta.style, {
    left: (r.left - sr.left + stage.scrollLeft + tl.x * k) + 'px',
    top: (r.top - sr.top + stage.scrollTop + tl.y * k) + 'px',
    width: (tl.w * k * zoom) + 'px',
    height: (editH * k * zoom) + 'px',
    transformOrigin: 'top left', transform: ios ? 'none' : `scale(${1 / zoom})`,
    fontFamily: tl.font, fontSize: targetFont + 'px',
    lineHeight: (ios ? Math.max(16, tl.fs * k) * p.lineHeight : tl.lh * k * zoom) + 'px',
    letterSpacing: (p.letterSpacing * k * zoom) + 'px',
    textIndent: p.indent ? '2em' : '0', color: p.ink, textAlign: p.textAlign,
  });
}
let keyboardFrame = 0;
let keyboardCoolingUntil = 0;
let fieldTimer = 0;
let pendingField = null;
const compositionFields = new WeakSet();
const keyboardTarget = el => el && el.matches && el.matches('input.pk-in:not([type=file]),textarea.pk-in,.pk-edta[contenteditable],[contenteditable=true]');
function keyboardIsOpen() {
  return st.ov && st.ov.classList.contains('pk-keyboard');
}
function flushField() {
  clearTimeout(fieldTimer); fieldTimer = 0;
  if (!pendingField) return;
  const entry = pendingField; pendingField = null;
  if (entry.type === 'replacement') {
    const r = cur().reps[entry.index];
    if (!r) return;
    if (r[entry.side] === entry.value) return;
    r[entry.side] = entry.value;
    persist(); buildText(); schedule(); historyPush('rep-edit');
  } else {
    setKey(entry.key, entry.value);
  }
}
function queueField(entry) {
  pendingField = entry;
  clearTimeout(fieldTimer);
  // Never repaint a long Canvas while the iOS keyboard is still composing / visible.
  if (!keyboardIsOpen()) fieldTimer = setTimeout(flushField, 360);
}
function syncKeyboardViewport() {
  if (!st.ov || !keyboardIsOpen()) return;
  const vv = window.visualViewport;
  const height = vv ? vv.height : window.innerHeight;
  const top = vv ? vv.offsetTop : 0;
  if (!height || height < 80) return;
  st.ov.style.setProperty('--pk-kb-height', Math.round(height) + 'px');
  st.ov.style.setProperty('--pk-kb-top', Math.round(top) + 'px');
  // Keep the active input inside the scrollable settings panel, without scrolling the host chat.
  const active = document.activeElement;
  if (!keyboardTarget(active) || !st.ov.contains(active)) return;
  if (active.classList.contains('pk-edta')) {
    // Align position only; never repaint Canvas or rewrite font metrics during composition.
    const cv = st.canvas, stage = st.ov.querySelector('.pk-stage'), tl = st.tl;
    if (cv && stage && tl) {
      const r = cv.getBoundingClientRect(), sr = stage.getBoundingClientRect();
      const k = r.width / (st.W || cv.width);
      const x = r.left - sr.left + stage.scrollLeft + tl.x * k;
      const y = r.top - sr.top + stage.scrollTop + tl.y * k;
      const dx = parseFloat(active.style.left), dy = parseFloat(active.style.top);
      if (!Number.isFinite(dx) || Math.abs(dx - x) > 1) active.style.left = x + 'px';
      if (!Number.isFinite(dy) || Math.abs(dy - y) > 1) active.style.top = y + 'px';
      const a = active.getBoundingClientRect();
      const b = stage.getBoundingClientRect();
      if (a.top > b.bottom - 52) stage.scrollTop += a.top - (b.top + 16);
      else if (a.top < b.top + 6) stage.scrollTop += a.top - (b.top + 12);
    }
    return;
  }
  const scroller = active.closest('.pk-panel');
  if (!scroller || !scroller.clientHeight) return;
  const a = active.getBoundingClientRect(), b = scroller.getBoundingClientRect();
  if (a.bottom > b.bottom - 12) scroller.scrollTop += a.bottom - (b.bottom - 12);
  else if (a.top < b.top + 8) scroller.scrollTop += a.top - (b.top + 8);
}
function queueKeyboardViewport() {
  if (keyboardFrame || !keyboardIsOpen()) return;
  keyboardFrame = requestAnimationFrame(() => {
    keyboardFrame = 0;
    syncKeyboardViewport();
  });
}
function keyboardDismiss() {
  if (!st.ov) return;
  if (st.ov.classList.contains('pk-keyboard')) keyboardCoolingUntil = Date.now() + 320;
  st.ov.classList.remove('pk-keyboard');
  st.ov.style.removeProperty('--pk-kb-height');
  st.ov.style.removeProperty('--pk-kb-top');
  if (keyboardFrame) { window.cancelAnimationFrame(keyboardFrame); keyboardFrame = 0; }
  if (keyboardRenderPending) {
    clearTimeout(keyboardRenderTimer);
    keyboardRenderTimer = setTimeout(() => {
      keyboardRenderTimer = 0;
      if (keyboardRenderPending && !keyboardIsOpen()) schedule(true);
    }, Math.max(20, keyboardCoolingUntil - Date.now() + 16));
  }
}
function syncVisualViewport() {
  if (!st.ov || !st.editing || keyboardIsOpen()) return;
  const vv = window.visualViewport;
  const h = vv ? vv.height : window.innerHeight;
  st.ov.style.setProperty('--pk-view-height', Math.round(h) + 'px');
  // Do not repaint a large canvas during keyboard animation.
}

// Edit in the poster itself. CSS templates edit their real text node; Canvas uses
// a precisely positioned overlay on top of the existing print, not a new view.
function inlineCssBody(){
  return st.ov?.querySelector('.pk-css-holder')?.shadowRoot?.querySelector('[data-pk="body"]')||null;
}
function inlineBodyText(body){
  // innerText preserves Safari contenteditable line breaks; textContent is a fallback.
  if(!body)return '';
  return String(body.innerText ?? body.textContent ?? '').replace(/\r/g,'').replace(/\n{3,}/g,'\n\n').replace(/\n$/,'');
}
function editableCssTargets(id,body){
  const root=body?.getRootNode();
  if(id==='page_margin_note'){
    return Array.from(root?.querySelectorAll('.pa-notes .pa-note .pa-body')||[]);
  }
  if(id==='imessage_dark'){
    let bubbles=Array.from(body?.querySelectorAll('.im-row.im-in .im-bubble')||[]);
    // An empty incoming conversation must still allow a new reply to be typed.
    if(!bubbles.length&&body){
      const row=document.createElement('div');row.className='im-row im-in im-tail';
      const bubble=document.createElement('span');bubble.className='im-bubble';
      row.appendChild(bubble);body.appendChild(row);bubbles=[bubble];
    }
    return bubbles;
  }
  return body?[body]:[];
}
function structuredCssResult(kind,targets){
  if(kind==='page_margin_note'||kind==='imessage_dark'){
    return targets.map(inlineBodyText).map(s=>s.trim()).filter(Boolean).join('\n');
  }
  return inlineBodyText(targets[0]);
}
function beginInlineEdit(){
  if(!st.ov||st.inlineEditing)return;
  const ov=st.ov, ta=ov.querySelector('.pk-edta');
  panel(null);ov.classList.remove('pk-categories');
  st.inlineEditing=true;st.editing=true;st.inlineOriginal=st.custom!=null?st.custom:st.base;
  st.zoom=1;ov.classList.add('pk-inline-editing');
  if(cssActive()){
    const body=inlineCssBody();
    if(!body){st.inlineEditing=false;st.editing=false;ov.classList.remove('pk-inline-editing');return;}
    const templateId=String(cur().pageSkin||'').slice(4);
    st.inlineBody=body;
    st.inlineKind=templateId;
    st.inlineBodies=editableCssTargets(templateId,body);
    if(!st.inlineBodies.length){
      st.inlineBody=null;st.inlineEditing=false;st.editing=false;
      ov.classList.remove('pk-inline-editing');return;
    }
    for(const target of st.inlineBodies){
      target.contentEditable='true';
      target.spellcheck=false;
      target.style.setProperty('-webkit-user-select','text','important');
      target.style.setProperty('user-select','text','important');
      target.style.setProperty('-webkit-touch-callout','default','important');
      target.style.setProperty('outline','1px dashed #8d98a6','important');
      target.style.setProperty('outline-offset','3px','important');
      target.style.setProperty('cursor','text','important');
      target.style.setProperty('min-height','1.4em','important');
    }
    // The first field is focused, but ALL notes / received bubbles are editable.
    st.inlineBodies[0].focus({preventScroll:true});
  }else{
    ta.innerText=st.inlineOriginal;
    // Draw once. No Canvas regeneration while typing (avoids iOS keyboard freezes).
    render(true);updatePreviewZoom(false);updateEditorBounds();
    ta.style.backgroundColor=cur().paperColor||'#fff';
    ta.focus({preventScroll:true});
  }
}
function finishInlineEdit(save){
  if(!st.ov||!st.inlineEditing)return;
  const ov=st.ov, ta=ov.querySelector('.pk-edta');
  const wasCss=cssActive();
  const targets=wasCss?(st.inlineBodies||[st.inlineBody].filter(Boolean)):[];
  let result=st.inlineOriginal;
  if(save) result=wasCss ? structuredCssResult(st.inlineKind,targets) : inlineBodyText(ta);
  // Restore every contenteditable target, not just the first paragraph.
  (wasCss?document.activeElement:ta)?.blur?.();
  for(const target of targets){
    target.removeAttribute('contenteditable');
    ['-webkit-user-select','user-select','-webkit-touch-callout','outline','outline-offset','cursor','min-height'].forEach(key=>target.style.removeProperty(key));
  }
  st.inlineBody=null;st.inlineBodies=[];st.inlineKind='';
  st.inlineEditing=false;st.editing=false;
  ov.classList.remove('pk-inline-editing');
  keyboardDismiss();
  if(save && result!==st.inlineOriginal){
    st.custom=result;st.customIsRendered=true;
    buildText();historyPush('inline-edit');
  }
  st.inlineOriginal='';
  fillEditorialImages();
  render(true);updatePreviewZoom(false);
}

function buildOverlay() {
  const ov = document.createElement('div');
  ov.id = 'pk-overlay';
  ov.innerHTML = `
  <div class="pk-modal">
    <div class="pk-head pk-edit-only">
      <div class="pk-ic" data-act="close" title="关闭"><i class="fa-solid fa-xmark"></i></div>
      <div class="pk-history">
        <button class="pk-tool" type="button" data-act="undo" aria-label="撤销" title="撤销"><i class="fa-solid fa-arrow-rotate-left"></i></button>
        <button class="pk-tool" type="button" data-act="redo" aria-label="重做" title="重做"><i class="fa-solid fa-arrow-rotate-right"></i></button>
      </div>
      <div class="pk-hr"><div class="pk-btn pk-pri" data-act="save">导出 <i class="fa-solid fa-arrow-up-right-from-square"></i></div></div>
    </div>
    <div class="pk-stage">
      <canvas></canvas><div class="pk-css-holder"></div>
      <div class="pk-edta" contenteditable="plaintext-only" spellcheck="false" role="textbox" aria-multiline="true" aria-label="在海报上直接修改正文"></div>
    </div>
    <div class="pk-preview-tools pk-edit-only">
      <div class="pk-zoom-tools">
        <button class="pk-tool" type="button" data-act="zoom-out" aria-label="缩小" title="缩小"><i class="fa-solid fa-magnifying-glass-minus"></i></button>
        <button class="pk-tool" type="button" data-act="zoom-reset" title="按屏幕宽度显示"><span class="pk-zoom-label">适宽</span></button>
        <button class="pk-tool" type="button" data-act="zoom-in" aria-label="放大" title="放大"><i class="fa-solid fa-magnifying-glass-plus"></i></button>
      </div>
      <div class="pk-main-tools">
        <button class="pk-tool pk-edit-tool" type="button" data-act="edit" aria-label="编辑正文" title="编辑正文"><i class="fa-solid fa-pen"></i><span>编辑文字</span></button>
        <button class="pk-tool pk-settings-tool" type="button" data-act="open-style" aria-label="更改样式" title="更改样式"><i class="fa-solid fa-palette"></i><span>更改样式</span></button>
        <button class="pk-tool pk-settings-tool" type="button" data-act="open-template" aria-label="模板" title="模板"><i class="fa-solid fa-layer-group"></i><span>模板</span></button>
      </div>
      <div class="pk-inline-actions" aria-label="正文编辑操作">
        <button class="pk-inline-cancel" type="button" data-act="ed-cancel">取消</button>
        <span>正在原位编辑正文</span>
        <button class="pk-inline-done" type="button" data-act="ed-ok">完成</button>
      </div>
      <div class="pk-cat-tools" hidden>
        <button class="pk-tool" type="button" data-act="cats-close" aria-label="返回预览"><i class="fa-solid fa-arrow-left"></i></button>
        <button class="pk-cat" type="button" data-open-tab="text">文字</button>
        <button class="pk-cat" type="button" data-open-tab="punch">样式</button>
        <button class="pk-cat" type="button" data-open-tab="paper">模板</button>
      </div>
    </div>
    <div class="pk-tune-bar pk-edit-only">
      <button class="pk-tool" type="button" data-act="tune-back" aria-label="返回设置"><i class="fa-solid fa-arrow-left"></i></button>
      <div class="pk-tune-slot"></div>
      <button class="pk-tool pk-tune-done" type="button" data-act="tune-done">完成</button>
    </div>
    <div class="pk-live-grip" aria-label="拖动调整预览和设置的高度">
      <span class="pk-grip-lines"></span>
      <button type="button" data-act="live-toggle" class="pk-live-toggle">仅设置</button>
    </div>
    <div class="pk-settings-layer pk-edit-only">
      <div class="pk-settings-head"><button type="button" class="pk-tool pk-workback" data-act="panel-close" aria-label="返回预览" title="返回预览"><i class="fa-solid fa-arrow-left"></i><span>预览</span></button><span class="pk-settings-title">设置</span><button type="button" class="pk-tool pk-kb-done" data-act="keyboard-done">完成</button></div>
      <div class="pk-tabs">
      <b data-tab="text">编辑信息</b><b data-tab="punch">样式</b><b data-tab="paper">模板</b>
      </div>
      <div class="pk-panel">
      <div class="pk-pane" data-pane="text">
        ${ui.grp('作品信息', `
          ${ui.inp('作品名', 'pubTitle', '{{user}}（默认）')}
          ${ui.inp('副标题', 'pubKicker', '可留空')}
          ${ui.inp('作者', 'pubAuthor', '{{char}}（默认）')}
          ${ui.inp('备注', 'pubNote', '题记 / 说明，可留空')}
          ${ui.inp('日期', 'pubDate', '默认今天')}
          <div data-template-fields hidden>
            <div data-template-field="channel">${ui.inp('频道', 'postypeChannel', '默认与作者相同')}</div>
            <div data-template-field="avatar">
              ${ui.seg('头像', 'postypeAvatarMode', [['char','角色'],['user','用户'],['custom','自选'],['initial','文字']])}
              <div data-postype-custom>
                ${ui.inp('头像链接', 'postypeAvatarImg', '上传或粘贴头像链接')}
                <div class="pk-row pk-btns"><div class="pk-btn" data-up="postypeAvatarImg">上传头像</div><div class="pk-btn pk-ghost" data-clr="postypeAvatarImg">清除</div></div>
              </div>
            </div>
            <div data-template-field="author-card">${ui.tg('作者卡片', 'postypeShowAuthor')}</div>
          </div>
          <div class="pk-sig-presets">
            <div class="pk-sub">作品信息预设</div>
            <div class="pk-chips pk-sigchips"></div>
            <div class="pk-row"><input class="pk-in pk-signame" placeholder="预设名" autocomplete="off"><div class="pk-btn" data-act="sig-save">保存</div></div>
          </div>`, true)}
        <div data-skin-editor>${ui.grp('页面插图', `
          <div data-nonpostype-image>${ui.img('插图', 'skinImg')}<div class="pk-note">调整仅作用于插图占位框，不影响头像。支持链接、上传或点击占位框。</div></div>`, true)}</div>
        <div data-ao3-options hidden>
          ${ui.grp('AO3 作品信息', `
            ${ui.tg('显示 Rating／作品信息', 'ao3ShowMetadata')}
            <div data-ao3-meta-fields>
              ${ui.inp('Rating', 'ao3Rating', '由你填写，可留空')}
              <div class="pk-row" style="align-items:flex-start"><span class="pk-l" style="padding-top:10px">其他作品信息</span><textarea class="pk-in" data-k="ao3MetaLines" placeholder="每行一项：字段名: 内容（全部自行填写）" rows="5" style="height:auto;min-height:110px;line-height:1.5;padding-top:8px;padding-bottom:8px;resize:vertical"></textarea></div>
            </div>
            <div class="pk-note">作品名、作者、Summary、Notes 和正文沿用上方作品信息与当前选中的文字，不含示例同人文内容。</div>
          `,true)}
        </div>
        <div data-threads-options hidden>
          ${ui.grp('脆评论区', `
            ${ui.tg('显示评论区', 'threadsShowComments')}
            <div data-threads-comment-fields>
              ${ui.seg('评论头像', 'threadsReplyAvatarMode', [['char','角色'],['user','用户'],['custom','自选'],['initial','文字']])}
              <div data-threads-reply-custom>
                ${ui.inp('头像链接', 'threadsReplyAvatarImg', '图片链接或上传')}
                <div class="pk-row pk-btns"><div class="pk-btn" data-up="threadsReplyAvatarImg">上传头像</div><div class="pk-btn pk-ghost" data-clr="threadsReplyAvatarImg">清除</div></div>
              </div>
              ${ui.inp('评论姓名', 'threadsReplyName', '自行填写')}
              ${ui.inp('评论时间', 'threadsReplyTime', '例如：2小时 / 1天')}
              <div class="pk-row" style="align-items:flex-start"><span class="pk-l" style="padding-top:10px">评论文案</span><textarea class="pk-in" data-k="threadsReplyText" placeholder="输入评论正文，支持换行" rows="4" style="height:auto;min-height:110px;line-height:1.5;padding-top:8px;padding-bottom:8px;resize:vertical"></textarea></div>
            </div>
          `, true)}
        </div>
        <div data-imessage-options hidden>
          ${ui.grp('iMessage 设置', `
            <div class="pk-note">右侧消息默认读取当前用户名 {{user}}，也可在「右侧消息」里自定义；正文是左侧灰色消息；副标题是中间的蓝色回复；备注是联系人名称（留空自动显示 {{char}}）。正文换行分成多条灰色消息，右侧消息可用「｜」分隔成多条。</div>
            ${ui.seg('联系人头像', 'imessageAvatarMode', [['system','系统'],['char','角色'],['user','用户'],['custom','自选']])}
            <div data-imessage-avatar-custom>
              ${ui.inp('头像链接', 'imessageAvatarImg', '上传或粘贴图片链接')}
              <div class="pk-row pk-btns"><div class="pk-btn" data-up="imessageAvatarImg">上传头像</div><div class="pk-btn pk-ghost" data-clr="imessageAvatarImg">清除</div></div>
            </div>
            ${ui.tg('显示图片消息', 'imessageShowImage')}
            <div data-imessage-image-fields>
              ${ui.seg('图片方向', 'imessageImageSide', [['right','我 · 蓝色侧'],['left','对方 · 灰色侧']])}
              ${ui.inp('图片链接', 'imessageImage', '上传或粘贴图片链接')}
              <div class="pk-row pk-btns"><div class="pk-btn" data-up="imessageImage">上传图片</div><div class="pk-btn pk-ghost" data-clr="imessageImage">清除</div></div>
            </div>
          `, true)}
        </div>
        ${ui.grp('替换', `
          ${ui.tg('启用', 'repOn')}
          <div class="pk-repbox"><div class="pk-reps"></div>
          <div class="pk-row pk-btns"><div class="pk-btn" data-act="rep-add">添加规则</div></div></div>`)}

      </div>

      <div class="pk-pane" data-pane="punch">
        ${ui.grp('页面设置', `
          <div class="pk-row pk-page-width"><span class="pk-l">页面宽度</span><input class="pk-in pk-width-edit" data-width-edit type="number" inputmode="numeric" min="300" max="900" step="10" aria-label="页面宽度"><span class="pk-width-unit">px</span></div>
          <div class="pk-row pk-btns pk-width-presets"><button class="pk-btn" type="button" data-widthpreset="390">390</button><button class="pk-btn" type="button" data-widthpreset="420">420</button><button class="pk-btn" type="button" data-widthpreset="440">440</button><button class="pk-btn" type="button" data-widthpreset="460">460</button></div>
          ${ui.seg('导出清晰度', 'width', [['1080', '标准'], ['1440', '高清']])}
          <div class="pk-note">宽度同步改变排版和导出；高度按内容自动延伸。</div>
        `, true)}
        ${ui.grp('字体', `
<div class="pk-font-tabs">${Object.keys(FONT_CATS).map(c => `<button type="button" data-fontcat="${esc(c)}">${esc(c)}</button>`).join('')}</div>
<div class="pk-fonts">${Object.entries(FONTS).filter(([, f]) => !f.hidden).map(([k, f]) => `<b data-font="${k}" style="${f.fam ? `font-family:'${f.fam}'` : f.stack ? `font-family:${f.stack.replace(/"/g, "'")}` : ''}">${f.name}</b>`).join('')}</div>
          <div class="pk-note">左右滑动浏览字体，点击立即预览。</div>`, true)}
        ${ui.grp('文字排版', `
          <div class="pk-cols">${ui.col('字色', 'ink')}${colorRail('ink')}</div>
          ${ui.seg('对齐', 'textAlign', [['left', '左'], ['center', '中'], ['right', '右'], ['justify', '两端']])}
          ${ui.sl('字号', 'fontSize', 24, 80, 1)}
          ${ui.sl('行距', 'lineHeight', 1.2, 3.2, 0.05)}
          ${ui.sl('字距', 'letterSpacing', 0, 20, 1)}
          ${ui.sl('边距', 'padX', 20, 240, 2)}
          ${ui.tg('首行缩进', 'indent')}`, false)}
        <div data-punch-only class="pk-punch-suite">
          ${ui.grp('打孔器', `
        ${ui.grp('打孔器文案样式', `
          <div data-double-only>${ui.seg('位置', 'sigPlace', [['scrap', '碎片区'], ['text', '正文区']])}</div>
          ${ui.seg('文案对齐', 'sigAlign', [['left', '左'], ['center', '中'], ['right', '右']])}
          ${ui.sl('文案字号', 'sigSize', 0.3, 1, 0.02)}
          <div class="pk-cols">${ui.col('文案颜色', 'sigColor')}${colorRail('sigColor')}</div>`, false)}
        ${ui.grp('打孔与碎片', `
          <div class="pk-sub">选字</div>
          <div class="pk-row pk-btns">
            <div class="pk-btn" data-act="random">随机挖孔</div>
            <div class="pk-step"><b data-act="minus">−</b><span class="pk-cnt"></span><b data-act="plus">+</b></div>
            <div class="pk-btn pk-ghost" data-act="clear">清空</div>
          </div>
          <div class="pk-row"><input class="pk-in pk-sentence" placeholder="输入要挖的字句" autocomplete="off"><div class="pk-btn" data-act="match">选中</div></div>
          ${ui.pick('孔形', 'holeShape', SHAPES, 'pk-shapes')}
          ${ui.sl('大小', 'holeSize', 0.6, 2.5, 0.05)}
          ${ui.tg('孔边阴影', 'holeShade')}
          <div data-pieces-only>
            <div class="pk-sub">碎片排列</div>
            ${ui.seg('位置', 'scrapPos', [['top', '上方'], ['bottom', '下方']])}
            ${ui.seg('排列', 'arrange', [['rows', '成行'], ['stairs', '阶梯'], ['scatter', '散落'], ['column', '竖排']])}
            <div data-layout-only="rows">${ui.sl('每行', 'rowLimit', 1, 20, 1)}</div>
            <div data-layout-only="column">${ui.sl('每列', 'columnLimit', 1, 20, 1)}</div>
            ${ui.sl('大小错落', 'scrapVar', 0, 0.65, 0.01)}
            ${ui.sl('倾斜', 'scrapTilt', 0, 0.5, 0.01)}
            ${ui.sl('装饰', 'deco', 0, 20, 1)}
            ${ui.tg('投影', 'scrapShadow')}
            <div class="pk-row pk-btns"><div class="pk-btn" data-act="reseed">重新排列</div></div>
          </div>
          <div class="pk-sub">孔洞颜色</div>
          ${ui.seg('孔内', 'holeMode', [['back', '底板'], ['color', '纯色']])}
          <div class="pk-cols">${ui.col('孔色', 'holeColor')}${colorRail('holeColor')}</div>
`, true)}
        <div data-punch-only>
        ${ui.grp('纸张颜色与纹样', `
          <div class="pk-cols">${ui.col('纸张颜色', 'paperColor')}${colorRail('paperColor')}</div>
          ${ui.pick('纸张纹样', 'paperTex', TEX)}
          <div data-double-only>
            <div class="pk-cols">${ui.col('碎片区底色', 'backColor')}${colorRail('backColor')}</div>
            ${ui.pick('碎片区纹样', 'backTex', TEX)}
          </div>`, true)}
        ${ui.grp('打孔器图片', `
          ${ui.img('纸张图片', 'paperImg')}
          <div data-double-only>${ui.img('碎片区图片', 'backImg')}</div>`, true)}
        ${ui.grp('打孔配色模板', `
          <div class="pk-chips pk-tpl-grid"></div>
          <div class="pk-row"><input class="pk-in pk-tplname" placeholder="模板名" autocomplete="off"><div class="pk-btn" data-act="tpl-save">保存</div></div>
          <div class="pk-row pk-btns"><div class="pk-btn" data-act="tpl-export">导出</div><div class="pk-btn" data-act="tpl-import">导入</div><div class="pk-btn pk-ghost" data-act="reset">恢复默认</div></div>`, false)}
        </div>
          `, false)}
        </div>

      </div>

      <div class="pk-pane" data-pane="paper">
        ${ui.grp('模板', `${skinTabs()}<div class="pk-css-manager"><div class="pk-btn" data-act="css-import">导入 CSS</div><div class="pk-btn pk-ghost" data-act="css-example">示例 CSS</div></div>`, true)}
      </div>
    </div>
    </div>
  </div>
  <input type="file" class="pk-file" accept="image/*" hidden>
  <input type="file" class="pk-cssfile" accept=".css,text/css" hidden>
  <input type="file" class="pk-jsonfile" accept=".json,application/json" hidden>
  <input type="file" class="pk-fontfile" accept=".ttf,.otf,.woff,.woff2,font/*" hidden>`;
  document.body.appendChild(ov);
  st.canvas = ov.querySelector('canvas');

  const $ = s => ov.querySelector(s);
  const cv = st.canvas, fileIn = $('.pk-file'), jsonIn = $('.pk-jsonfile');
  let upKey = '';
  fontCategory(ov, '常用');
  // Load only font samples actually visible in the scrollable settings pane.
  if (window.IntersectionObserver) {
    const fontWatcher = new window.IntersectionObserver(entries => {
      entries.forEach(e => {
        if (!e.isIntersecting) return;
        const f = FONTS[e.target.dataset.font];
        if (f && f.css) ensureFont(f, f.name);
        fontWatcher.unobserve(e.target);
      });
    }, { root: ov.querySelector('.pk-panel'), rootMargin: '48px' });
    ov.querySelectorAll('.pk-fonts [data-font]').forEach(b => fontWatcher.observe(b));
    ov._pkFontObserver = fontWatcher;
  }

  ['touchstart', 'touchmove', 'touchend', 'wheel'].forEach(t => ov.addEventListener(t, e => e.stopPropagation(), { passive: true }));
  const liveGrip=ov.querySelector('.pk-live-grip');
  if(liveGrip) {
    let gripDrag=null;
    liveGrip.addEventListener('pointerdown',e=>{
      if(e.target.closest('[data-act]') || !ov.classList.contains('pk-live'))return;
      e.preventDefault();e.stopPropagation();
      const modal=ov.querySelector('.pk-modal');
      const layer=ov.querySelector('.pk-settings-layer');
      if(!modal||!layer)return;
      gripDrag={id:e.pointerId,y:e.clientY,h:layer.getBoundingClientRect().height,modalH:modal.clientHeight};
      try{liveGrip.setPointerCapture(e.pointerId);}catch(_){ }
    });
    liveGrip.addEventListener('pointermove',e=>{
      if(!gripDrag || gripDrag.id!==e.pointerId)return;
      e.preventDefault();
      const newH=gripDrag.h+(gripDrag.y-e.clientY);
      const pct=Math.min(66,Math.max(26,newH/Math.max(1,gripDrag.modalH)*100));
      ov.style.setProperty('--pk-live-panel-h',pct.toFixed(1)+'%');
    });
    const end=e=>{if(gripDrag?.id===e.pointerId){gripDrag=null;requestAnimationFrame(()=>updatePreviewZoom(false));}};
    liveGrip.addEventListener('pointerup',end);
    liveGrip.addEventListener('pointercancel',end);
  }

  ov.querySelectorAll('.pk-shapes b').forEach(b => { b.querySelector('i').style.backgroundImage = `url(${shapeThumb(b.dataset.v)})`; });

  // iOS: sliders should never inherit the text-input keyboard render lock.
  // Update the visual state on each pointer move, but save history only once.
  ov.querySelectorAll('.pk-sl').forEach(el => {
    const k = el.dataset.sl, min = +el.dataset.min, max = +el.dataset.max, step = +el.dataset.step;
    let active = false, dirty = false, activeId = null;
    const set = x => {
      const r = el.getBoundingClientRect();
      if (r.width <= 0) return;
      const t = Math.min(1, Math.max(0, (x - r.left) / r.width));
      const v = +(Math.round((min + t * (max - min) - min) / step) * step + min).toFixed(4);
      if (cur()[k] === v) return;
      cur()[k] = v;
      syncOne(k);
      schedule(true);
      dirty = true;
    };
    const end = e => {
      if (!active || (e && activeId != null && e.pointerId != null && e.pointerId !== activeId)) return;
      active = false; activeId = null;
      el.classList.remove('drag');
      if (dirty) { dirty = false; persist(); historyPush('set:' + k); }
    };
    el.addEventListener('pointerdown', e => {
      if (e.button != null && e.button !== 0) return;
      e.preventDefault(); e.stopPropagation();
      // Pointerdown preventDefault does not always blur an iOS text field.
      if (keyboardTarget(document.activeElement)) {
        flushField();
        document.activeElement.blur();
        keyboardDismiss();
      }
      active = true; activeId = e.pointerId;
      try { el.setPointerCapture(e.pointerId); } catch (_) {}
      el.classList.add('drag');
      set(e.clientX);
    });
    el.addEventListener('pointermove', e => {
      if (!active || e.pointerId !== activeId) return;
      e.preventDefault(); e.stopPropagation(); set(e.clientX);
    });
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
    el.addEventListener('lostpointercapture', end);
  });

  const scale = () => (st.W || cv.width) / cv.getBoundingClientRect().width;
  const toCanvas = (cx, cy) => {
    const r = cv.getBoundingClientRect(), s = (st.W || cv.width) / r.width;
    return [(cx - r.left) * s, (cy - r.top) * s, s];
  };
  const pieceAt = (cx, cy) => {
    const [x, y] = toCanvas(cx, cy);
    for (let i = st.pieces.length - 1; i >= 0; i--) {
      const pc = st.pieces[i];
      if (Math.abs(x - pc.x) <= pc.w / 2 + 8 && Math.abs(y - pc.y) <= pc.h / 2 + 8) return pc;
    }
    return null;
  };
  const onEdge = (cx, cy) => {
    if (st.edgeY == null || cur().layoutMode === 'single') return false;
    const [, y, s] = toCanvas(cx, cy);
    return Math.abs(y - st.edgeY) <= 22 * s;
  };
  let drag = null, moved = false;
  cv.addEventListener('touchstart', e => {
    if (st.editing || st.zoom > 1) return;
    const t = e.touches[0];
    if (t && (pieceAt(t.clientX, t.clientY) || onEdge(t.clientX, t.clientY))) e.preventDefault();
  }, { passive: false });
  cv.addEventListener('pointerdown', e => {
    if (st.editing || st.zoom > 1) return;
    const pc = pieceAt(e.clientX, e.clientY);
    const edge = !pc && onEdge(e.clientX, e.clientY);
    if (!pc && !edge) return;
    e.preventDefault();
    try { cv.setPointerCapture(e.pointerId); } catch (err) { }
    if (pc) { const o = st.off[pc.key] || { x: 0, y: 0 }; drag = { key: pc.key, sx: e.clientX, sy: e.clientY, ox: o.x, oy: o.y }; }
    else drag = { edge: true, sy: e.clientY };
    moved = false;
  });
  cv.addEventListener('pointermove', e => {
    if (!drag) return;
    e.preventDefault();
    const dx = e.clientX - (drag.sx || 0), dy = e.clientY - drag.sy;
    if (Math.abs(dy) + (drag.edge ? 0 : Math.abs(dx)) > 3) moved = true;
    if (drag.edge) {
      const p = cur(), canvasY = toCanvas(e.clientX, e.clientY)[1];
      const wantedH = p.scrapPos === 'top' ? canvasY : st.H - canvasY;
      // Convert the dragged fragment height to the ratio used by render().
      p.split = +Math.min(0.85, Math.max(0.12, 0.45 * wantedH / Math.max(1,st.W * 0.38))).toFixed(3);
      persist(); schedule(); return;
    }
    const s = scale();
    st.off[drag.key] = { x: drag.ox + dx * s, y: drag.oy + dy * s };
    schedule();
  });
  const endDrag = () => { if (drag) { if (moved) historyPush('drag'); drag = null; setTimeout(() => { moved = false; }, 0); } };
  cv.addEventListener('pointerup', endDrag); cv.addEventListener('pointercancel', endDrag);
  cv.addEventListener('click', e => {
    if (st.editing) return;
    if (moved || pieceAt(e.clientX, e.clientY) || onEdge(e.clientX, e.clientY)) return;
    const b = hitTest(e);
    if (b) { toggle(b.i); return; }
    if ((cur().pageSkin||'punch')!=='punch') return;
    const [x, y] = toCanvas(e.clientX, e.clientY);
    if (y < st.textY || y > st.textY + st.textH) return;
    const py = y - st.textY, [hw, hh] = st.hole;
    const i = st.free.findIndex(f => Math.abs(f.x - x) < hw / 2 && Math.abs(f.y - py) < hh / 2);
    if (i >= 0) st.free.splice(i, 1); else st.free.push({ id: ++st.fid, x, y: py });
    schedule(); historyPush();
  });

  // iOS IME may fire many provisional input events. Only commit after a pause or blur.
  const typedField = el => {
    if (el.dataset.k != null) return { type: 'setting', key: el.dataset.k, value: el.value };
    if (el.dataset.rf != null) return { type: 'replacement', index: +el.dataset.rf, side: 'from', value: el.value };
    if (el.dataset.rt != null) return { type: 'replacement', index: +el.dataset.rt, side: 'to', value: el.value };
    return null;
  };
  const acceptTextInput = e => {
    const el = e.target;
    if (e.isComposing || compositionFields.has(el)) return;
    const entry = typedField(el);
    if (entry) queueField(entry);
  };
  ov.addEventListener('compositionstart', e => {
    if (!typedField(e.target)) return;
    compositionFields.add(e.target);
    clearTimeout(fieldTimer);
  });
  ov.addEventListener('compositionend', e => {
    compositionFields.delete(e.target);
    acceptTextInput(e);
  });
  ov.addEventListener('input', e=>{
    const el=e.target;
    if(el.dataset.pubedit==='width') {
      updateEditorialImage(el.dataset.pubid,'width',+el.value,true);
      const label=el.parentElement.querySelector('span');if(label) label.textContent=el.value+'%';
    }
  });
  ov.addEventListener('input', acceptTextInput);
  ov.addEventListener('change', e => {
    const el=e.target;
    if(el.hasAttribute('data-width-edit')) {
      const n = Math.round(Number(el.value));
      if(Number.isFinite(n)) setKey('cssPageWidth',Math.min(900,Math.max(300,n)));
      syncOne('cssPageWidth');
      return;
    }
    if(el.dataset.pubedit && !compositionFields.has(el)) {
      const key=el.dataset.pubedit;
      updateEditorialImage(el.dataset.pubid,key,['width','after'].includes(key)?+el.value:el.value);
    }
    if (typedField(e.target) && !compositionFields.has(e.target)) {
      const entry = typedField(e.target);
      pendingField = entry; flushField();
    }
  });
  ov.addEventListener('focusin', e => {
    const focused=e.composedPath?.().find(node=>keyboardTarget(node))||e.target;
    if (!keyboardTarget(focused) || window.innerWidth > 520) return;
    ov.querySelector('.pk-modal')?.style.removeProperty('height');
    ov.classList.add('pk-keyboard');
    queueKeyboardViewport();
  });
  ov.addEventListener('focusout', e => {
    const focused=e.composedPath?.().find(node=>keyboardTarget(node))||e.target;
    if (!keyboardTarget(focused)) return;
    if (!compositionFields.has(focused)) flushField();
    // Focus may be moving between two inputs; don't collapse modal in between.
    setTimeout(() => {
      if (st.ov !== ov) return;
      if (!keyboardTarget(document.activeElement) || !ov.contains(document.activeElement)) {
        keyboardDismiss();
        if(st.ov?.classList.contains('panel')) queueFitSettingsView();
        if (st.editing && !cssActive()) updateEditorBounds();
      }
    }, 100);
  });
  ov.querySelectorAll('[data-col]').forEach(el => el.addEventListener('input', () => setKey(el.dataset.col, el.value)));
  ov.querySelectorAll('[data-img]').forEach(el => el.addEventListener('change', () => setKey(el.dataset.img, el.value.trim())));

  $('.pk-fontfile').addEventListener('change', e => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    f.arrayBuffer().then(buf => useFontBuffer(buf).then(() => idb('readwrite', s => s.put(buf, 'font')))).then(() => {
      const p = cur(); p.fontName = f.name.replace(/\.\w+$/, ''); persist();
      p.fontKey = ''; setKey('fontKey', 'upload'); toast('success', '字体已载入：' + p.fontName);
    }).catch(() => toast('error', '这个字体文件读不了'));
  });
  fileIn.addEventListener('change', () => {
    const f = fileIn.files[0]; fileIn.value = '';
    const dest=upKey;upKey='';
    if (f && dest) upload(f, url => {
      if (dest.startsWith('pub:')) { updateEditorialImage(dest.slice(4),'src',url); fillEditorialImages(); }
      else setKey(dest,url);
    }, dest.startsWith('pub:'));
  });
  // ShadowRoot events are retargeted to the host; use composedPath to locate the text glyph.
  const cssHolder=ov.querySelector('.pk-css-holder');
  cssHolder.addEventListener('click',e=>{
    if(st.editing||(ov.classList.contains('panel')&&!ov.classList.contains('pk-live')))return;
    const imageSlot=e.composedPath().find(node=>node?.dataset?.pkUpload);
    if(imageSlot){
      upKey=imageSlot.dataset.pkUpload||'skinImg';
      fileIn.click();
      return;
    }
    // Ordinary CSS page text is not punchable. Clicks are reserved for image placeholders.
  });
  const cssIn=$('.pk-cssfile');
  cssIn.addEventListener('change',()=>{
    const f=cssIn.files[0];cssIn.value='';if(!f)return;
    if(f.size>200000){toast('error','CSS 文件过大');return;}
    f.text().then(txt=>{
      const spec=cssClean(txt);
      cssEntries()[spec.id]=spec;
      if(store().cssHidden)delete store().cssHidden[spec.id];
      persist();fillCssList();
      const templateKey='css:'+spec.id;
      if(cur().pageSkin===templateKey){
        st.cssSignature=''; // force rebuilding the ShadowRoot with new CSS/HTML
        schedule(true);
        syncSkinSelection();
      } else setKey('pageSkin',templateKey);
      panel(null);
      toast('success','已导入 CSS：'+spec.name);
    }).catch(e=>toast('error',e.message||'CSS 读取失败'));
  });
  jsonIn.addEventListener('change', () => {
    const f = jsonIn.files[0]; jsonIn.value = '';
    if (!f) return;
    const fr = new FileReader();
    fr.onload = () => {
      try {
        const d = JSON.parse(fr.result);
        if(!d || typeof d!=='object' || Array.isArray(d))throw Error('格式错误');
        const name = String(d.name || f.name.replace(/\.json$/i, '')).trim().slice(0,80);
        const source=d.preset||d;
        if(!name || ['__proto__','prototype','constructor'].includes(name)||!source||typeof source!=='object'||Array.isArray(source))throw Error('格式错误');
        // Reject unrelated JSON files rather than accidentally saving them as broken presets.
        if(!Object.keys(source).some(k=>k in BASE))throw Error('不是海报预设');
        if(('reps' in source && !Array.isArray(source.reps)) || ('pubImages' in source && !Array.isArray(source.pubImages)))throw Error('预设中的列表格式错误');
        const pre=clone(source);delete pre.name;
        store().tpl[name]=pre;persist();fillTpl();toast('success','已导入：'+name);
      } catch (e) { toast('error', '模板文件格式不对'); }
    };
    fr.readAsText(f);
  });

  ov.addEventListener('click', e => {
    if (e.target === ov) { close(); return; }
    const t = e.target.closest('[data-font],[data-act],[data-up],[data-clr],[data-imgreset],[data-fold],[data-tab],[data-tg],.pk-seg b,.pk-pick b,[data-tpl],[data-tpldel],[data-sigtpl],[data-sigtpldel],[data-repdel],[data-fontcat],[data-layout-tpl],[data-zine-tpl],[data-skin],[data-cssdel],[data-cssexport],[data-skin-group],[data-pubupload],[data-pubremove],[data-tune],[data-widthpreset],[data-color-key]');
    if (!t) return;
    const s = store(), p = cur();
    if(t.dataset.colorKey){setKey(t.dataset.colorKey,t.dataset.colorValue);return;}
    if(t.dataset.widthpreset) {setKey('cssPageWidth',+t.dataset.widthpreset);return;}
    if (t.dataset.tune) { startTune(t.dataset.tune); return; }
    if(t.dataset.cssexport){
      const id=t.dataset.cssexport;
      const spec=cssEntries()[id]||BUILTIN_CSS[id];
      if(!spec)return;
      const raw=cssSpecSource(spec);
      download('data:text/css;charset=utf-8,'+encodeURIComponent(raw),cssTemplateName(id,spec.name)+'.css');return;
    }
    if(t.dataset.cssdel){
      e.preventDefault();e.stopPropagation();
      const id=t.dataset.cssdel;
      if(cssEntries()[id])delete cssEntries()[id];
      if(BUILTIN_CSS[id])store().cssHidden[id]=true;
      if(cur().pageSkin==='css:'+id)cur().pageSkin='punch';
      st.cssSignature='';persist();fillCssList();syncAll();schedule(true);
      toast('success','已从模板列表移除');return;
    }
    if (t.dataset.skin) {
      flushField();
      const key=t.dataset.skin;
      if(key.startsWith('css:')&&(cssEntries()[key.slice(4)] || (!store().cssHidden[key.slice(4)] && BUILTIN_CSS[key.slice(4)]))){
        setKey('pageSkin',key);syncSkinSelection();panel(null);return;
      }
      if (key==='singlepage' || key==='punch') {
        // Both are direct, peer-level templates. Single page has no independent fragment zone.
        p.pageSkin='punch';
        p.layoutMode='double';
        p.singleScraps=false;
        if(key==='singlepage')p.pubOn=false;
        persist();syncAll();schedule(true);historyPush('page-template');
      } else if(PAGE_SKINS[key]) {
        setKey('pageSkin',key);
      }
      syncSkinSelection();panel(null);return;
    }
    if (t.dataset.pubupload) { upKey='pub:'+t.dataset.pubupload; fileIn.click(); return; }
    if (t.dataset.pubremove) {
      p.pubImages=(p.pubImages||[]).filter(x=>String(x.id)!==t.dataset.pubremove);
      persist(); fillEditorialImages(); schedule(true); historyPush('pub-remove');return;
    }
    if (t.dataset.zineTpl) {
      const preset=ZINE_LAYOUTS[t.dataset.zineTpl];
      if(!preset || p.layoutMode!=='single') return;
      Object.assign(p,preset,{pubOn:true}); delete p.name;
      persist();syncAll();schedule(true);historyPush('zine-template');return;
    }
    if (t.dataset.fontcat) { fontCategory(ov, t.dataset.fontcat); return; }
    if (t.dataset.layoutTpl) {
      const layout = TEXT_LAYOUTS[t.dataset.layoutTpl];
      if (!layout || p.layoutMode !== 'single') return;
      for (const [k,v] of Object.entries(layout)) if (k !== 'title') p[k] = v;
      persist(); syncAll(); schedule(true); historyPush('text-layout');
      return;
    }
    if (t.dataset.font) {
      if (t.dataset.font === 'upload' && (!fontUp.ok || cur().fontKey === 'upload')) { $('.pk-fontfile').click(); return; }
      setKey('fontKey', t.dataset.font); if(!st.livePreview)panel(null); return;
    }
    if (t.dataset.fold) { t.parentElement.classList.toggle('open'); queueFitSettingsView(); return; }
    if (t.dataset.tab) { panel(t.dataset.tab); return; }
    if (t.dataset.tg) { setKey(t.dataset.tg, !p[t.dataset.tg]); return; }
    if (t.parentElement && t.parentElement.dataset.seg) { const k = t.parentElement.dataset.seg; setKey(k, k === 'width' ? +t.dataset.v : t.dataset.v); return; }
    if (t.parentElement && t.parentElement.dataset.pick) { setKey(t.parentElement.dataset.pick, t.dataset.v); return; }
    if (t.dataset.up) { upKey = t.dataset.up; fileIn.click(); return; }
    if (t.dataset.clr) { setKey(t.dataset.clr, ''); return; }
    if (t.dataset.imgreset) {
      const k = t.dataset.imgreset;
      if (!['paperImg','backImg','skinImg'].includes(k)) return;
      p[k + 'Scale'] = 1;
      p[k + 'X'] = 50;
      p[k + 'Y'] = 50;
      persist();
      ['Scale','X','Y'].forEach(s => syncOne(k + s));
      schedule(); historyPush('img-reset:' + k);
      return;
    }
    if (t.dataset.repdel != null) { p.reps.splice(+t.dataset.repdel, 1); persist(); fillReps(); buildText(); schedule(); historyPush('rep-del'); return; }
    if (t.dataset.tpldel) { e.stopPropagation(); delete s.tpl[t.dataset.tpldel]; persist(); fillTpl(); return; }
    if (t.dataset.tpl) {
      const n = t.dataset.tpl, src = s.tpl[n] || BUILTIN[n];
      if (!src) return;
      const shared=Object.fromEntries(['pubTitle','pubKicker','pubAuthor','pubNote','pubDate'].map(k=>[k,p[k]]));
      s.cur = Object.assign(clone(BASE), clone(src), shared);
      persist(); syncAll(); buildText(); schedule(); historyPush('template');
      toast('success', '已套用：' + n); panel(null); return;
    }
    if (t.dataset.sigtpldel) { e.stopPropagation(); delete s.sigTpl[t.dataset.sigtpldel]; persist(); fillSigTpl(); return; }
    if (t.dataset.sigtpl) {
      const n = t.dataset.sigtpl, src = s.sigTpl[n];
      if (!src) return;
      if('pubTitle' in src || 'pubAuthor' in src) {
        SIG_KEYS.forEach(k => { if(k in src) p[k]=src[k]; });
      } else {
        if(src.sig1 && src.sig1 !== '{{char}}') p.pubTitle=src.sig1;
        p.pubAuthor='{{char}}';
        p.pubNote=[src.sig2==='{{user}}'?'':src.sig2,src.sig3,src.sig4].filter(Boolean).join('\n');
        for(const k of ['sigAlign','sigPlace','sigSize','sigColor']) if(k in src)p[k]=src[k];
      }
      persist(); syncAll(); buildText(); schedule(); historyPush('sig-preset');
      toast('success', '已套用署名：' + n); panel(null); return;
    }
    const act = t.dataset.act;
    if (act === 'close') { close(); return; }
    if (act === 'keyboard-done') { if (st.editing) { ov.querySelector('[data-act="ed-ok"]').click(); return; } if (keyboardTarget(document.activeElement)) document.activeElement.blur(); flushField(); keyboardDismiss(); return; }
    if (act === 'settings') { panel(st.lastTab || 'punch'); return; }
    if (act === 'open-text') { panel('text'); return; }
    if (act === 'open-style') { panel('punch'); return; }
    if (act === 'open-template') { panel('paper'); return; }
    if (act === 'live-toggle') {
      st.livePreview=!st.livePreview;
      panel(st.lastTab||'punch');
      return;
    }
    if (act === 'panel-close') { panel(null); return; }
    if (act === 'tune-back') { stopTune(true); return; }
    if (act === 'tune-done') { stopTune(false); return; }
    if (act === 'zoom-in') { changeZoom(1); return; }
    if (act === 'zoom-out') { changeZoom(-1); return; }
    if (act === 'zoom-reset') { changeZoom(0); return; }
    if (act === 'css-width-reset') { setKey('cssPageWidth',0); return; }
    if (act === 'undo') { historyTravel(-1); return; }
    if (act === 'redo') { historyTravel(1); return; }
    if (act === 'edit') { beginInlineEdit(); return; }
    if (act === 'ed-ok') { finishInlineEdit(true); return; }
    if (act === 'ed-cancel') { finishInlineEdit(false); return; }
    if (act === 'pub-add-photo') {
      if(!Array.isArray(p.pubImages)) p.pubImages=[];
      if(p.pubImages.length>=8) { toast('info','最多可插入 8 张图片');return; }
      const id='p'+Date.now().toString(36)+Math.random().toString(36).slice(2,5);
      p.pubOn=true;
      p.pubImages.push({id,src:'',after:0,width:80,align:'center',ratio:'4:3',fit:'cover',caption:''});
      persist();syncLayoutControls();syncOne('pubOn');fillEditorialImages();historyPush('pub-add');
      upKey='pub:'+id; fileIn.click();return;
    }
    if (act === 'rep-add') { p.reps.push({ from: '', to: '' }); persist(); fillReps(); historyPush('rep-add'); }
    if (act === 'random') randomHoles(+p.randomCount || 1);
    if (act === 'minus' || act === 'plus') setKey('randomCount', Math.min(99, Math.max(1, (+p.randomCount || 1) + (act === 'plus' ? 1 : -1))));
    if (act === 'clear') { st.holes = []; st.free = []; st.off = {}; schedule(); historyPush('clear'); }
    if (act === 'reseed') { st.seed++; st.off = {}; schedule(); historyPush('reseed'); }
    if (act === 'match') matchSentence($('.pk-sentence').value);
    if (act === 'sig-save') {
      const n = $('.pk-signame').value.trim();
      if (!n || ['__proto__','constructor','prototype'].includes(n)) { toast('info', '请输入有效的预设名'); return; }
      s.sigTpl[n] = Object.fromEntries(SIG_KEYS.map(k => [k, p[k]]));
      persist(); fillSigTpl(); toast('success', '已保存署名：' + n); return;
    }
    if (act === 'tpl-save') {
      const n = $('.pk-tplname').value.trim();
      if (!n || ['__proto__','constructor','prototype'].includes(n)) { toast('info', '请输入有效的模板名'); return; }
      s.tpl[n] = clone(p); persist(); fillTpl(); toast('success', '已保存：' + n);
    }
    if (act === 'tpl-export') {
      const n = $('.pk-tplname').value.trim() || '打孔海报模板';
      download('data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify({ name: n, preset: p }, null, 2)), n + '.json');
    }
    if (act === 'tpl-import') jsonIn.click();
    if (act === 'css-import') cssIn.click();
    if (act === 'css-example') download('data:text/css;charset=utf-8,'+encodeURIComponent(CSS_STARTER),'CSS模板.css');
    if (act === 'reset') { s.cur = clone(BASE); persist(); syncAll(); buildText(); schedule(); historyPush('reset'); }
    if (act === 'save') {
      // Commit pending IME/settings input before exporting the artwork.
      flushField();
      if(st.inlineEditing) finishInlineEdit(true);
      // One-tap export. Do not enter the old '图片已生成' result screen: keep the
      // editable preview visible even after saving, including on iPhone.
      if(st.exportBusy) return;
      st.exportBusy=true;
      const button=ov.querySelector('[data-act="save"]');
      if(button)button.classList.add('pk-saving');
      const finish=url=>{
        // One export action, without an additional success toast that repeats
        // the host app's own download/export-complete notification.
        download(url,'海报_'+Date.now()+'.png');
      };
      const done=()=>{st.exportBusy=false;if(button)button.classList.remove('pk-saving');};
      if(cssActive()){
        cssTemplateExport().then(finish).catch(err=>toast('error',String(err.message||err))).finally(done);
      } else {
        try{render(false);const url=st.canvas.toDataURL('image/png');render(true);finish(url);}
        catch(err){render(true);toast('error','导出失败，请改用上传的图片素材');}
        finally{done();}
      }
      return;
    }
  });
  return ov;
}

function stopTune(returnSettings = false) {
  if (!st.ov || !st.tuning) return;
  const ov = st.ov, tune = st.tuning;
  if (tune.placeholder.parentNode) tune.placeholder.replaceWith(tune.row);
  st.tuning = null;
  ov.classList.remove('pk-tuning');
  if (returnSettings) panel(tune.tab);
  else panel(null);
}

function startTune(k) {
  const ov = st.ov;
  if (!ov || st.tuning) return;
  const sl = ov.querySelector(`[data-sl="${k}"]`);
  const row = sl?.closest('.pk-row');
  const slot = ov.querySelector('.pk-tune-slot');
  if (!row || !slot || !row.parentNode) return;
  const tab = st.lastTab || 'punch';
  const placeholder = document.createComment('pk-slider-position');
  row.parentNode.insertBefore(placeholder, row);
  slot.appendChild(row);
  st.tuning = { row, placeholder, tab };
  ov.classList.remove('panel', 'pk-categories');
  ov.querySelector('.pk-modal')?.style.removeProperty('height');
  ov.classList.add('pk-tuning');
  syncOne(k);
  updatePreviewZoom(false);
}

function fitSettingsView() {
  const ov=st.ov;
  if (!ov || !ov.classList.contains('panel') || ov.classList.contains('pk-live') || ov.classList.contains('pk-keyboard') || st.editing) return;
  const modal=ov.querySelector('.pk-modal');
  const pane=ov.querySelector('.pk-pane.on');
  if(!modal||!pane)return;
  const visible=window.visualViewport?.height||window.innerHeight;
  const upper=Math.min(visible*0.86,760);
  // Two compact headers + content. When text contains many options the
  // content area scrolls; short panels no longer reserve a full empty page.
  const needed=Math.max(250,Math.ceil(pane.scrollHeight+88));
  modal.style.setProperty('height',Math.min(upper,needed)+'px','important');
}
function queueFitSettingsView() {
  requestAnimationFrame(()=>{
    if(st.ov && st.ov.classList.contains('panel')) fitSettingsView();
  });
}

function panel(tab) {
  // Commit any iOS textarea input before leaving or switching settings tabs.
  flushField();
  const ov = st.ov;
  if (!ov) return;
  if (st.tuning) {
    const t = st.tuning;
    if (t.placeholder.parentNode) t.placeholder.replaceWith(t.row);
    st.tuning = null;
    ov.classList.remove('pk-tuning');
  }
  ov.classList.toggle('panel', !!tab);
  ov.classList.toggle('pk-live', !!tab && st.livePreview !== false);
  ov.classList.remove('pk-categories');
  const liveBtn=ov.querySelector('[data-act="live-toggle"]');
  if(liveBtn)liveBtn.textContent=st.livePreview===false?'显示预览':'仅设置';
  if(!tab) ov.querySelector('.pk-modal')?.style.removeProperty('height');
  if (tab) st.lastTab = tab;
  ov.querySelectorAll('.pk-tabs b').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
  ov.querySelectorAll('.pk-pane').forEach(x => x.classList.toggle('on', x.dataset.pane === tab));
  const title = ov.querySelector('.pk-settings-title');
  if (title) title.textContent = ({text:'编辑信息',punch:'更改样式',paper:'所有模板'})[tab] || '设置';
  const btn = ov.querySelector('[data-act="settings"]');
  if (btn) btn.setAttribute('aria-expanded', tab ? 'true' : 'false');
  if(tab) {queueFitSettingsView(); if(st.livePreview!==false) requestAnimationFrame(()=>{ if(isOpen()) updatePreviewZoom(false); });}
  // Refresh after the stage becomes visible and its flex width is real again.
  if (!tab && cssActive()) {
    requestAnimationFrame(() => {
      if (st.ov === ov && isOpen() && !ov.classList.contains('panel')) {
        cssSize();
        requestAnimationFrame(() => { if(st.ov === ov && isOpen()) cssSize(); });
      }
    });
  }
}

function syncRepUI() {
  if (!st.ov) return;
  const box = st.ov.querySelector('.pk-repbox');
  if (box) box.hidden = !cur().repOn;
}

function fillReps() {
  const n = names();
  const hint = f => (f || '').replace(/{{char}}/gi, n.char).replace(/{{user}}/gi, n.user);
  st.ov.querySelector('.pk-reps').innerHTML = (cur().reps || []).map((r, i) => `
    <div class="pk-rep">
      <div class="pk-repf"><input class="pk-in" data-rf="${i}" value="${esc(r.from)}" placeholder="原词" autocomplete="off">${/{{(char|user)}}/i.test(r.from) ? `<em>${esc(hint(r.from))}</em>` : ''}</div>
      <i class="fa-solid fa-arrow-right"></i>
      <input class="pk-in" data-rt="${i}" value="${esc(r.to)}" placeholder="替换成" autocomplete="off">
      <b data-repdel="${i}"><i class="fa-solid fa-xmark"></i></b>
    </div>`).join('');
  syncRepUI();
}

function syncLayoutControls() {
  if (!st.ov) return;
  const p=cur();
  const single=p.layoutMode==='single';
  // One global editor: changing the active template never removes controls.
  // Only value-dependent suboptions (e.g. row/column, custom avatar) may toggle.
  st.ov.querySelectorAll('[data-layout-only]').forEach(el=>{el.hidden=el.dataset.layoutOnly!==p.arrange;});
  st.ov.querySelectorAll('[data-double-only]').forEach(el=>{el.hidden=single;});
  st.ov.querySelectorAll('[data-single-only]').forEach(el=>{el.hidden=!single;});
  st.ov.querySelectorAll('[data-punch-only],[data-css-width-only],[data-css-only],[data-skin-editor],[data-nonpostype-image]').forEach(el=>{el.hidden=false;});
  const id=String(p.pageSkin||'').replace(/^css:/,'');
  const isPostype=cssActive()&&(id==='app_postype'||id==='postype');
  const isThreads=cssActive()&&id==='threads_day';
  const isIMessage=cssActive()&&id==='imessage_dark';
  // The shared avatar controls belong to every imported template that actually
  // declares an avatar slot, not just POSTYPE / Threads.
  const templateHtml=cssActive()?String(cssTemplateRecord()?.html||''):'';
  const hasTemplateAvatar=/data-pk\s*=\s*(?:["']avatar["']|avatar(?=[\s>]))/i.test(templateHtml);
  st.ov.querySelectorAll('[data-imessage-options]').forEach(el=>{el.hidden=!isIMessage;});
  st.ov.querySelectorAll('[data-imessage-image-fields]').forEach(el=>{el.hidden=!p.imessageShowImage;});
  st.ov.querySelectorAll('[data-imessage-avatar-custom]').forEach(el=>{el.hidden=p.imessageAvatarMode!=='custom';});
  for(const [key,plain,im] of [
    ['pubTitle','作品名','右侧消息'],['pubKicker','副标题','右侧回复'],
    ['pubNote','备注','联系人备注'],['pubDate','日期','时间']]){
    const label=st.ov.querySelector('[data-k="'+key+'"]')?.closest('.pk-row')?.querySelector('.pk-l');
    if(label)label.textContent=isIMessage?im:plain;
  }
  st.ov.querySelectorAll('[data-skin-editor]').forEach(el=>{el.hidden=isIMessage;});
  st.ov.querySelectorAll('[data-template-fields]').forEach(el=>{el.hidden=!(isPostype||hasTemplateAvatar);});
  st.ov.querySelectorAll('[data-template-field]').forEach(el=>{
    el.hidden=el.dataset.templateField==='avatar' ? !hasTemplateAvatar : !isPostype;
  });
  st.ov.querySelectorAll('[data-ao3-options]').forEach(el=>{el.hidden=!(cssActive()&&id==='ao3_work');});
  st.ov.querySelectorAll('[data-ao3-meta-fields]').forEach(el=>{el.hidden=p.ao3ShowMetadata===false;});
  st.ov.querySelectorAll('[data-threads-options]').forEach(el=>{el.hidden=!isThreads;});
  st.ov.querySelectorAll('[data-threads-comment-fields]').forEach(el=>{el.hidden=p.threadsShowComments===false;});
  st.ov.querySelectorAll('[data-pieces-only]').forEach(el=>{el.hidden=single;});
  st.ov.querySelectorAll('[data-postype-custom]').forEach(el=>{el.hidden=p.postypeAvatarMode!=='custom';});
  st.ov.querySelectorAll('[data-threads-reply-custom]').forEach(el=>{el.hidden=p.threadsReplyAvatarMode!=='custom';});
  syncOne('cssPageWidth');
  syncSkinSelection();
  queueFitSettingsView();
}

function setKey(k, v) {
  const p = cur();
  const switchHoleColor = k === 'holeColor' && p.holeMode !== 'color';
  if (switchHoleColor) { p.holeMode='color'; syncOne('holeMode'); }
  if (p[k] === v && !switchHoleColor) return;
  p[k] = v;
  persist();
  if (k === 'repOn') { buildText(); syncRepUI(); }
  if (k === 'arrange' || k === 'layoutMode' || k === 'singleScraps' || k === 'pubOn' || k === 'pageSkin' || k === 'skinImg' || k === 'postypeAvatarMode' || k === 'threadsReplyAvatarMode' || k === 'threadsShowComments' || k === 'ao3ShowMetadata' || k === 'imessageShowImage' || k === 'imessageAvatarMode') syncLayoutControls();
  if (k === 'paperColor' || k === 'backColor') syncTex();
  syncOne(k);
  if (k !== 'randomCount') schedule();
  historyPush('set:' + k);
}

function fmt(v, step) { const d = (String(step).split('.')[1] || '').length; return (+v).toFixed(d); }

function syncOne(k) {
  const ov = st.ov, p = cur(), v = p[k];
  ov.querySelectorAll(`[data-color-key="${k}"]`).forEach(b=>b.classList.toggle('on',String(b.dataset.colorValue).toLowerCase()===String(v||'').toLowerCase()));
  ov.querySelectorAll(`[data-sl="${k}"]`).forEach(el => {
    const min = +el.dataset.min, max = +el.dataset.max;
    const effective = k==='cssPageWidth' && !(+v>=300) ? cssLayoutWidth() : v;
    const t = Math.min(1, Math.max(0, (effective - min) / (max - min))) * 100;
    el.querySelector('.pk-sl-fill').style.width = t + '%';
    el.querySelector('.pk-sl-th').style.left = t + '%';
    const lab = ov.querySelector(`[data-v="${k}"]`); if (lab) lab.textContent = fmt(effective, el.dataset.step);
  });
  if(k==='cssPageWidth') {
    ov.querySelectorAll('[data-width-edit]').forEach(input=>{if(input!==document.activeElement)input.value=String(cssLayoutWidth());});
    ov.querySelectorAll('[data-widthpreset]').forEach(b=>b.classList.toggle('on',+b.dataset.widthpreset===cssLayoutWidth()));
  }
  ov.querySelectorAll(`[data-seg="${k}"] b`).forEach(b => b.classList.toggle('on', String(v) === b.dataset.v));
  ov.querySelectorAll(`[data-pick="${k}"] b`).forEach(b => b.classList.toggle('on', v === b.dataset.v));
  ov.querySelectorAll(`[data-tg="${k}"]`).forEach(el => el.classList.toggle('on', !!v));
  ov.querySelectorAll(`[data-k="${k}"]`).forEach(el => { if (el !== document.activeElement) el.value = v; });
  ov.querySelectorAll(`[data-col="${k}"]`).forEach(el => { el.value = v; });
  ov.querySelectorAll(`[data-colv="${k}"]`).forEach(el => { el.style.background = v; });
  ov.querySelectorAll(`[data-img="${k}"]`).forEach(el => {
    const s = typeof v==='string'?v:'';
    if (el !== document.activeElement) el.value = s.startsWith('data:') ? '' : s;
    el.placeholder = s.startsWith('data:') ? '已上传图片' : '图片链接';
  });
  if (k === 'paperImg' || k === 'backImg' || k === 'skinImg') {
    const box = ov.querySelector(`[data-img-adjust="${k}"]`);
    if (box) box.hidden = !v;
  }
  if (['textBoxWidth','textBoxX','textVAlign','fontSize','padX','padY','lineHeight','letterSpacing','textAlign','indent'].includes(k)) {
    ov.querySelectorAll('[data-layout-tpl]').forEach(b => {
      const spec = TEXT_LAYOUTS[b.dataset.layoutTpl];
      b.classList.toggle('on', Object.entries(spec).every(([key,value]) => key === 'title' || p[key] === value));
    });
  }
  if (k === 'randomCount') ov.querySelector('.pk-cnt').textContent = v;
  if (k === 'fontKey') {
    ov.querySelectorAll('[data-font]').forEach(b => b.classList.toggle('on', b.dataset.font === v));
    const up = ov.querySelector('[data-font="upload"]');
    if (up) up.textContent = p.fontName && fontUp.ok ? p.fontName : '上传字体';
    // Do not preload every webfont when opening the panel on iOS.
    // The selected font is loaded by fontStack() during render.
  }
}

function syncTex() {
  const p = cur();
  [['paperTex', p.paperColor], ['backTex', p.backColor]].forEach(([k, c]) => {
    st.ov.querySelectorAll(`[data-pick="${k}"] b`).forEach(b => { b.querySelector('i').style.backgroundImage = `url(${texSwatch(b.dataset.v, c)})`; });
  });
}

function syncAll() {
  Object.keys(BASE).forEach(k => { if (k !== 'reps') syncOne(k); });
  syncTex();
  fillReps();
  fillEditorialImages();
  syncLayoutControls();
  if (st.ov) st.ov.querySelectorAll('[data-zine-tpl]').forEach(b => {
    const spec=ZINE_LAYOUTS[b.dataset.zineTpl];
    b.classList.toggle('on',!!cur().pubOn && Object.entries(spec).every(([k,v])=>k==='name'||cur()[k]===v));
  });
  if (st.ov) st.ov.querySelectorAll('[data-layout-tpl]').forEach(b => {
    const preset = TEXT_LAYOUTS[b.dataset.layoutTpl];
    b.classList.toggle('on', Object.entries(preset).every(([k,v]) => k === 'title' || cur()[k] === v));
  });
}

function fillMes() {
  st.editing = false;
  
  syncAll();
}

function fillTpl() {
  const saved=store();
  const card=(name,user)=>{
    const spec=(user?saved.tpl[name]:BUILTIN[name])||{};
    const p=Object.assign({},BASE,spec);
    const paper=esc(p.paperColor||'#fbfaf6'), back=esc(p.backColor||'#bdb9b1');
    return `<div class="pk-chip pk-tpl-card" data-tpl="${esc(name)}" role="button" tabindex="0" title="${esc(name)}" aria-label="套用配色：${esc(name)}"><span class="pk-palette-circle" style="--pk-half-one:${paper};--pk-half-two:${back}"></span>${user?`<span class="pk-tpl-del" data-tpldel="${esc(name)}" title="删除：${esc(name)}" aria-label="删除：${esc(name)}">×</span>`:''}</div>`;
  };
  st.ov.querySelector('.pk-tpl-grid').innerHTML=Object.keys(BUILTIN).map(n=>card(n,false)).join('')+Object.keys(saved.tpl).map(n=>card(n,true)).join('');
}

function fillEditorialImages() {
  if (!st.ov) return;
  const list = st.ov.querySelector('.pk-photo-list');
  if (!list) return;
  const imgs = Array.isArray(cur().pubImages) ? cur().pubImages : [];
  const paraCount = Math.max(1, st.chars.filter(c=>c==='\n').length+1);
  const options = Array.from({length: Math.min(paraCount,50)+1},(_,i)=>`<option value="${i}">${i===0?'正文前':`第 ${i} 段后`}</option>`).join('');
  list.innerHTML=imgs.map((it,i)=>{
    const id=esc(it.id);
    const photoSrc=typeof it.src==='string'?it.src:'';
    const opt=(name, choices)=>`<label>${name}<select data-pubedit="${choices[0]}" data-pubid="${id}">${choices.slice(1).map(([v,label])=>`<option value="${v}" ${it[choices[0]]===v?'selected':''}>${label}</option>`).join('')}</select></label>`;
    return `<div class="pk-photo-slot" data-photo-id="${id}">
      <div class="pk-photo-slot-top"><strong>插图 ${i+1}</strong><button type="button" class="pk-btn pk-sm" data-pubupload="${id}">上传</button><button type="button" class="pk-btn pk-sm pk-ghost" data-pubremove="${id}">删除</button></div>
      <input class="pk-in" type="url" data-pubedit="src" data-pubid="${id}" autocomplete="off" placeholder="${photoSrc.startsWith('data:')?'已上传图片':'图片链接'}" value="${photoSrc.startsWith('data:')?'':esc(photoSrc)}">
      <div class="pk-photo-meta"><label>插入位置<select data-pubedit="after" data-pubid="${id}">${options.replace(`value="${Math.min(paraCount,Math.max(0,+it.after||0))}"`,`value="${Math.min(paraCount,Math.max(0,+it.after||0))}" selected`)}</select></label>
      ${opt('横向位置',['align',['left','靠左'],['center','居中'],['right','靠右']])}
      ${opt('图片比例',['ratio',['natural','原比例'],['1:1','正方形'],['4:3','4:3'],['3:4','3:4'],['16:9','16:9']])}
      ${opt('显示方式',['fit',['cover','裁切铺满'],['contain','完整显示']])}</div>
      <label>图片宽度</label><div class="pk-photo-control"><input type="range" data-pubedit="width" data-pubid="${id}" min="30" max="100" step="5" value="${+it.width||80}"><span>${+it.width||80}%</span></div>
      <input class="pk-in" data-pubedit="caption" data-pubid="${id}" autocomplete="off" placeholder="图片说明（可空）" value="${esc(it.caption||'')}">
    </div>`;
  }).join('');
}
function updateEditorialImage(id, key, value, live=false) {
  const p=cur(), list=Array.isArray(p.pubImages)?p.pubImages:[];
  const at=list.findIndex(e=>String(e.id)===String(id));
  if(at<0 || list[at][key]===value) return;
  list[at][key]=value;
  if(!live) persist();
  // Preserve the iOS composition guard for caption / URL editing; range changes stay live.
  if(!live && (key==='caption' || key==='src')) schedule(); else schedule(true);
  if(!live) historyPush('pub-image:'+key);
}

function fillSigTpl() {
  if (!st.ov) return;
  const s = store();
  const chip = n => `<div class="pk-chip" data-sigtpl="${esc(n)}">${esc(n)}<i class="fa-solid fa-xmark" data-sigtpldel="${esc(n)}"></i></div>`;
  st.ov.querySelector('.pk-sigchips').innerHTML = Object.keys(s.sigTpl || {}).map(chip).join('');
}

function close() { if (st.ov) { if(st.inlineEditing)finishInlineEdit(false); panel(null); flushField(); if (keyboardTarget(document.activeElement)) document.activeElement.blur(); keyboardDismiss(); st.editing = false; st.ov.classList.remove('show'); } }

// Use the rendered message text when a known message is used as an editor host;
// fall back to the stored message when the chat DOM has not been mounted.
function wholeMessageText(id, mes) {
  const message=ctx().chat?.[id];
  if(!message)return '';
  const holder=mes||Array.from(document.querySelectorAll('#chat .mes[mesid]'))
    .find(el=>Number(el.getAttribute('mesid'))===id);
  const body=holder?.querySelector('.mes_text');
  const visible=body ? String(body.innerText||body.textContent||'') : '';
  if(normalize(visible))return normalize(visible);
  const raw=String(message.mes||'');
  return normalize(raw.replace(/<[^>]*>/g,''));
}
function openById(id, selText) {
  const picked = normalize(selText || wholeMessageText(id));
  if (!picked) { toast('info', '当前消息没有可用文字'); return; }
  beginMessageDraft(id);
  if (!st.ov) { st.ov = buildOverlay(); fillTpl(); fillSigTpl(); fillCssList(); }
  if (!loadMessage(id, picked)) { toast('info', '没有可用的消息'); return; }
  keyboardDismiss();
  if (!st.chars.length) { toast('info', '选中的内容没有文字'); return; }
  st.seed = 0; st.holes = []; st.off = {}; st.free = []; st.fid = 0;
  if (String(cur().pageSkin || '').startsWith('css:') && !cssTemplateRecord()) { cur().pageSkin = 'punch'; persist(); }
  st.zoom = 1; st.lastTab = 'text';
  st.ov.querySelector('.pk-sentence').value = '';
  fillMes();
  
  panel(null);
  st.ov.classList.add('show');
  render(true); updatePreviewZoom(true); resetHistory();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => schedule());
}

// 句子拾取匣：单独保存收藏数据，不覆盖原有模板与海报设置。
let snippetBox=null, snippetBar=null, snippetPicking=false;
let snippetTapFromFloating=false;
let snippetActionMenu=null, snippetActionTimer=0;
function hideSnippetActionMenu(){
  clearTimeout(snippetActionTimer);snippetActionTimer=0;
  snippetActionMenu?.remove();snippetActionMenu=null;
}
function showSnippetActionMenu(text,messageId,clientX,clientY){
  if(!snippetTapFromFloating)return;
  hideSnippetActionMenu();
  const menu=document.createElement('div');menu.id='pk-snip-action-menu';
  menu.setAttribute('role','group');menu.setAttribute('aria-label','已收藏的句子');
  const info=document.createElement('span');info.className='pk-snip-action-saved';info.textContent='✓ 已收藏';
  const beauty=document.createElement('button');beauty.type='button';
  const pickedCount=snippetMarks.filter(item=>String(item?.text||'').trim()).length;
  beauty.innerHTML='<i class="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i>repo 美化'+(pickedCount>1?'（'+pickedCount+'段）':'');
  beauty.addEventListener('click',e=>{
    e.preventDefault();e.stopPropagation();
    // Take a snapshot BEFORE stopping the picker (which clears snippetMarks).
    // Earlier versions passed only the last tapped sentence, even if several
    // were highlighted. One selected span becomes one margin-note paragraph.
    const chosen=snippetMarks.filter(item=>String(item?.text||'').trim());
    if(new Set(chosen.map(item=>item.roleKey||'unclassified')).size>1){
      snippetToast('不同角色的句子请分别美化，避免混淆说话人','error');
      hideSnippetActionMenu();return;
    }
    if(chosen.length>1 && chosen.every(item=>item.messageId===chosen[0].messageId)){
      chosen.sort((a,b)=>Number(a.start||0)-Number(b.start||0));
    }
    const selectedText=chosen.length>1
      ? chosen.map(item=>String(item.text).trim()).join('\n\n')
      : text;
    const preferred=chosen.find(item=>Number.isInteger(item.messageId))?.messageId;
    const reference=chosen[0]||{messageId};
    const chosenId=snippetDraftMessageId({
      messageId:Number.isInteger(preferred)?preferred:messageId,
      roleKey:reference.roleKey,
      sourceChat:String(ctx().chatId??ctx().chatName??'')
    });
    if(chosenId===null){
      snippetToast('当前聊天找不到可用于美化的来源消息，请先切换到相应聊天','error');
      hideSnippetActionMenu();return;
    }
    hideSnippetActionMenu();stopSnippetPicking(false);
    openById(chosenId,selectedText);
  });
  menu.append(info,beauty);document.body.appendChild(menu);snippetActionMenu=menu;
  const vv=window.visualViewport;
  const left=vv?.offsetLeft||0,top=vv?.offsetTop||0;
  const width=vv?.width||window.innerWidth,height=vv?.height||window.innerHeight;
  const w=menu.offsetWidth||205,h=menu.offsetHeight||39;
  const x=Math.max(left+7,Math.min(left+width-w-7,clientX-w/2));
  const below=clientY+12;
  const y=below+h>top+height-8?clientY-h-14:below;
  menu.style.left=Math.round(x)+'px';menu.style.top=Math.round(Math.max(top+7,y))+'px';
  snippetActionTimer=setTimeout(hideSnippetActionMenu,5500);
}
const snippetChatIdentity=()=>String(ctx().chatId??ctx().chatName??'');
let snippetQuickTarget=null; // null = library picker, otherwise {id, chatKey, message} for one message
let snippetView='library', snippetFilter='all', snippetSearch='', snippetDetailId=null;
let snippetImportMode='merge';
const snippetCollapsed = new Set();
const snippetVisibleCounts = new Map();
const SNIPPET_PAGE_SIZE=75;
let snippetMergeEditor = null;
const snippetChosen=new Set();
const snippetMarks=[];
let snippetMarkHost=null, snippetMarkFrame=0;
const snippetDefaultPrefs={messageShortcut:true,tapShortcut:true,selectionShortcut:true,iconImage:'',iconSize:54,floatX:null,floatY:null,theme:'auto',accent:'#1b1b1d',highlight:'#f2bd68',fontSize:15,panelHeight:82,panelWidth:94,density:'normal',lightBg:'#ffffff',darkBg:'#191c20'};
const snippetStore=()=>{
  const s=store();
  if(!Array.isArray(s.pickedSentences))s.pickedSentences=[];
  return s.pickedSentences;
};
const snippetPrefs=()=>{
  const s=store();
  if(!s.snippetPrefs || typeof s.snippetPrefs!=='object')s.snippetPrefs={};
  // Respect users who explicitly disabled the earlier drag shortcut.
  if(s.snippetPrefs.tapShortcut===undefined&&s.snippetPrefs.dragShortcut===false)s.snippetPrefs.tapShortcut=false;
  for(const [key,value] of Object.entries(snippetDefaultPrefs))
    if(s.snippetPrefs[key]===undefined)s.snippetPrefs[key]=value;
  return s.snippetPrefs;
};
function snippetToast(message,type='info'){toast(type,message);}
function snippetCharAvatar(raw){
  if(typeof raw!=='string'||!raw.trim())return '';
  const s=raw.trim();
  if(/^(?:data:image\/|blob:|https?:\/\/|\/)/i.test(s))return s;
  return '/characters/'+s.replace(/^\.?\/?characters\//i,'').split('/').map(encodeURIComponent).join('/');
}
// ST also sets is_system on /hide messages. Only accept a hidden message
// as a source when its *actual* speaker name can be verified in this chat.
// Ordinary system/narrator messages must not inherit the active character.
function snippetMessageEligible(id){
  const c=ctx(), msg=Number.isInteger(id)?c.chat?.[id]:null;
  if(!msg)return false;
  if(!msg.is_system)return true;
  const name=typeof msg.name==='string'?msg.name.trim():'';
  if(!name)return false;
  if(msg.is_user)return name===String(c.name1||'').trim();
  return name===String(c.name2||'').trim()
    ||(Array.isArray(c.characters)&&c.characters.some(actor=>actor?.name===name));
}
function snippetCurrentCharacter(messageId){
  const c=ctx(), chat=c.chat||[], msg=Number.isInteger(messageId)?chat[messageId]:null;
  if(msg?.is_user){
    const name=String(msg.name||c.name1||'用户').trim()||'用户';
    const domAvatar=document.querySelector('#chat .mes[mesid="'+messageId+'"] .avatar img');
    const avatar=domAvatar?.currentSrc||domAvatar?.getAttribute('src')||snippetCharAvatar(c.user_avatar||c.userAvatar||'');
    return {roleKey:'user:'+name,roleName:name,avatar:avatar||''};
  }
  const chars=Array.isArray(c.characters)?c.characters:[];
  const idx=c.characterId??c.characterIndex;
  const fromMessage=msg&&!msg.is_user&&snippetMessageEligible(messageId)&&typeof msg.name==='string'?msg.name.trim():'';
  const active=chars[idx];
  const actor=chars.find(v=>v?.name&&fromMessage&&v.name===fromMessage) || (active?.name===fromMessage||!fromMessage?active:null) || chars.find(v=>v?.name===c.name2&&c.name2===fromMessage);
  const name=fromMessage||actor?.name||c.name2||'';
  // Use name as a portable grouping key across chats, not volatile message indices.
  const key=name?'char:'+name:'unclassified';
  const domAvatar=Number.isInteger(messageId)&&!msg?.is_user?document.querySelector('#chat .mes[mesid="'+messageId+'"] .avatar img'):null;
  const avatar=(domAvatar?.currentSrc||domAvatar?.getAttribute('src')||'')
    ||snippetCharAvatar(actor?.avatar||actor?.avatar_url||(!fromMessage?c.characterAvatar:'')||'');
  return {roleKey:key,roleName:name||'未分类',avatar:avatar||''};
}
function snippetRoleOf(item){
  const key=typeof item?.roleKey==='string'&&item.roleKey?item.roleKey:'unclassified';
  const name=typeof item?.roleName==='string'&&item.roleName?item.roleName:(key==='unclassified'?'未分类':key.replace(/^(?:char:|user:)/,''));
  return {key,name,avatar:typeof item?.avatar==='string'?item.avatar:''};
}
// Find a real chat message to host a saved quote in the editor.
// Imported/legacy unclassified quotes have no trustworthy role attribution:
// try their original current-chat message, then a usable recent message.
// Classified quotes must never be attributed to an unrelated speaker.
function snippetDraftMessageId(item){
  const chat=ctx().chat||[];
  const roleKey=snippetRoleOf(item).key;
  const matches=id=>snippetMessageEligible(id)
    &&(roleKey==='unclassified'||snippetCurrentCharacter(id).roleKey===roleKey);
  const usable=id=>Number.isInteger(id)&&id>=0&&matches(id)&&!!wholeMessageText(id);
  const currentChat=String(ctx().chatId??ctx().chatName??'');
  if(item?.sourceChat===currentChat && usable(item.messageId))return item.messageId;
  // Prefer visible speech. Hidden /hide messages are fallback sources only
  // when their actual speaker can still be verified (see helper above).
  for(let id=chat.length-1;id>=0;id--)if(!chat[id]?.is_system&&usable(id))return id;
  for(let id=chat.length-1;id>=0;id--)if(usable(id))return id;
  return null;
}
function addPickedSentence(text,sourceId,roleHint,span=null){
  const value=normalize(String(text||'')).trim();
  if(!value)return null;
  const arr=snippetStore();
  const role=roleHint||snippetCurrentCharacter(sourceId);
  const already=arr.find(x=>x.text===value&&snippetRoleOf(x).key===role.roleKey);
  if(already){snippetToast('这句话已经收藏过了');return already;}
  const id=snippetNewId();
  const rec={id,text:value,messageId:Number.isInteger(sourceId)?sourceId:null,
    sourceChat:String(ctx().chatId??ctx().chatName??''),roleKey:role.roleKey,roleName:role.roleName,
    avatar:role.avatar,savedAt:Date.now(),
    ...(span&&span.sourceOffsetMode==='message'&&Number.isInteger(span.start)&&Number.isInteger(span.end)
      ?{sourceStart:span.start,sourceEnd:span.end,sourceOffsetMode:'message'}:{})};
  // Never evict someone's earlier saved sentences silently.
  // The import validator already uses 5000 as the supported collection limit.
  if(arr.length>=5000){snippetToast('收藏已满 5000 句，请先导出备份或清理后再收藏','error');return null;}
  arr.unshift(rec);
  persist();snippetToast('已收藏：'+role.roleName,'success');
  if(snippetBar)snippetUpdatePickCount();
  return rec;
}
function snippetUpdatePickCount(){
  const el=snippetBar?.querySelector('[data-snip-count]');
  if(el)el.textContent=snippetMarks.length+' 句已标记';
  const merge=snippetBar?.querySelector('[data-snip-pick-merge]');
  if(merge)merge.disabled=snippetMarks.length<2;
}
// Keep real paragraph boundaries when the chat renderer splits text among
// multiple DOM nodes. Visual word-wrapping is NOT a paragraph boundary.
// The synthetic newline has no DOM range of its own, and cannot be selected.
function snippetNodeText(body){
  const walker=document.createTreeWalker(body,window.NodeFilter.SHOW_ELEMENT|window.NodeFilter.SHOW_TEXT);
  const chunks=[];let full='',n;
  const blocks=new Set(['P','DIV','LI','BLOCKQUOTE','PRE','H1','H2','H3','H4','H5','H6','DT','DD']);
  while((n=walker.nextNode())){
    if(n.nodeType===1){
      if(n.tagName==='BR' || (n!==body && blocks.has(n.tagName))) {
        if(full && !full.endsWith('\n')) full+='\n';
      }
      continue;
    }
    if(!n.textContent || n.parentElement?.closest('script,style,[hidden],[aria-hidden="true"]'))continue;
    const piece=n.textContent;
    chunks.push({node:n,start:full.length,end:full.length+piece.length});full+=piece;
  }
  return {full,chunks};
}
function snippetTextScope(node,body){
  const start=node?.nodeType===1?node:node?.parentElement;
  const target=start?.closest('p,li,blockquote,pre,h1,h2,h3,h4,h5,h6,dt,dd');
  return target&&body.contains(target)?target:body;
}
function snippetRangeFromOffsets(chunks,start,end){
  const ranges=[];
  for(const part of chunks){
    const a=Math.max(start,part.start),b=Math.min(end,part.end);
    if(a>=b)continue;
    const range=document.createRange();range.setStart(part.node,a-part.start);range.setEnd(part.node,b-part.start);
    ranges.push(range);
  }
  return ranges;
}
function clickedSentence(e,body){
  const caret=document.caretRangeFromPoint?.(e.clientX,e.clientY);
  const alt=!caret?document.caretPositionFromPoint?.(e.clientX,e.clientY):null;
  const node=caret?.startContainer||alt?.offsetNode;
  const offset=caret?.startOffset??alt?.offset;
  if(!node||!body.contains(node))return null;
  // Never infer a sentence through a neighboring <p>, <br> or block.
  // This also avoids a previous paragraph's closing bracket being selected.
  const scope=snippetTextScope(node,body);
  const {full,chunks}=snippetNodeText(scope);
  const source=chunks.find(v=>v.node===node);
  if(!source||!full.trim())return null;
  const position=Math.min(source.end-1,source.start+Math.max(0,Number(offset)||0));
  const lineStart=full.lastIndexOf('\n',position-1)+1;
  const nextNewline=full.indexOf('\n',position);
  const lineEnd=nextNewline<0?full.length:nextNewline;
  const isEnd=i=>'。！？!?'.includes(full[i])||(full[i]==='.'&&(i===lineEnd-1||/\s/.test(full[i+1]||'')));
  let start=position,end=position;
  while(start>lineStart&&!isEnd(start-1))start--;
  while(end<lineEnd&&!isEnd(end))end++;
  if(end<lineEnd)end++;
  while(end<lineEnd&&'”’」』）》"\'】]'.includes(full[end]))end++;
  // Bracketed dialogue is one passage, even when it contains more than one sentence.
  // This prevents a stranded '[' or ']' becoming a separate saved record.
  const openPairs={'[':']','【':'】','「':'」','『':'』'};
  const stack=[];let enclosure=null;
  for(let i=0;i<full.length;i++){
    const c=full[i];
    if(openPairs[c])stack.push({char:c,start:i});
    else if(stack.length&&openPairs[stack[stack.length-1].char]===c){
      const last=stack.pop();
      if(last.start<=position&&position<=i&&i-last.start<900){
        if(!enclosure||last.start<enclosure.start)enclosure={start:last.start,end:i+1};
      }
    }
  }
  // A complete enclosing quote is the selection; do NOT union it with the
  // sentence detected before it. That union selected two adjacent passages.
  if(enclosure && enclosure.start>=lineStart && enclosure.end<=lineEnd){
    start=enclosure.start;end=enclosure.end;
  }
  // Ignore whitespace and line boundaries, never store punctuation alone.
  while(start<end&&/\s/.test(full[start]))start++;
  while(end>start&&/\s/.test(full[end-1]))end--;
  const text=full.slice(start,end).trim();
  if(!text||!/[\p{L}\p{N}]/u.test(text))return null;
  if(text.length>900){snippetToast('选中的内容较长，请分两句拾取后合并，或手动添加');return null;}
  const ranges=snippetRangeFromOffsets(chunks,start,end);
  if(!ranges.length)return null;
  // Each click can be scoped to one <p>, where local offsets start at zero.
  // Resolve offsets again against the entire message before storing them,
  // so sorting/merging across paragraphs does not select the wrong text.
  const messageChunks=scope===body?chunks:snippetNodeText(body).chunks;
  const first=ranges[0],last=ranges[ranges.length-1];
  const firstPart=messageChunks.find(c=>c.node===first.startContainer);
  const lastPart=messageChunks.find(c=>c.node===last.endContainer);
  if(!firstPart||!lastPart)return null;
  const sourceStart=firstPart.start+first.startOffset;
  const sourceEnd=lastPart.start+last.endOffset;
  return {text,ranges,start:sourceStart,end:sourceEnd,body,sourceOffsetMode:'message'};
}
function snippetMarkRender(){
  snippetMarkFrame=0;
  if(!snippetPicking||!snippetMarkHost)return;
  snippetMarkHost.replaceChildren();
  const color=snippetPrefs().highlight;
  for(const entry of snippetMarks){
    for(const range of entry.ranges){
      for(const rect of Array.from(range.getClientRects())){
        if(!rect.width||!rect.height||rect.bottom<0||rect.top>window.innerHeight)continue;
        const paint=document.createElement('span');paint.className='pk-snip-highlight';
        Object.assign(paint.style,{top:rect.top-1+'px',left:rect.left-2+'px',width:rect.width+4+'px',height:rect.height+2+'px',background:color+'65',borderBottom:'2px solid '+color});
        snippetMarkHost.appendChild(paint);
      }
    }
  }
}
function snippetScheduleMarks(){
  if(snippetMarkFrame||!snippetPicking)return;
  snippetMarkFrame=requestAnimationFrame(snippetMarkRender);
}
function onSnippetClick(e){
  if(!snippetPicking||e.target?.closest?.('#pk-snip-bar')||e.target?.closest?.('#pk-snip-merge-overlay'))return;
  const body=e.target?.closest?.('#chat .mes[mesid] .mes_text');
  if(!body)return;
  // In quick mode, leave all other messages fully interactive.
  const clickedId=Number(body.closest('.mes[mesid]')?.getAttribute('mesid'));
  if(snippetQuickTarget && (snippetChatIdentity()!==snippetQuickTarget.chatKey || clickedId!==snippetQuickTarget.id || ctx().chat?.[clickedId]!==snippetQuickTarget.message))return;
  e.preventDefault();e.stopPropagation();
  const extracted=clickedSentence(e,body);
  if(!extracted){snippetToast('未能识别完整句子，可以手动添加');return;}
  const messageId=Number(body.closest('.mes[mesid]')?.getAttribute('mesid'));
  const sourceId=Number.isInteger(messageId)?messageId:null;
  if(!Number.isInteger(sourceId)||!ctx().chat?.[sourceId]){snippetToast('原消息不存在或已失效，请重新选择','error');return;}
  if(!snippetMessageEligible(sourceId)){snippetToast('系统消息不能作为收藏来源','error');return;}
  const role=snippetCurrentCharacter(sourceId);
  const existing=snippetMarks.find(v=>v.text===extracted.text&&v.roleKey===role.roleKey);
  if(existing){
    hideSnippetActionMenu();
    const at=snippetMarks.indexOf(existing);snippetMarks.splice(at,1);
    if(existing.newlyAdded){
      store().pickedSentences=snippetStore().filter(v=>v.id!==existing.id);persist();
    }
    snippetUpdatePickCount();snippetScheduleMarks();return;
  }
  // Save on tap, so nothing is lost when leaving picking mode; merge can replace them.
  const wasNew=!snippetStore().some(v=>v.text===extracted.text&&snippetRoleOf(v).key===role.roleKey);
  const item=addPickedSentence(extracted.text,sourceId,role,extracted);
  if(!item)return;
  snippetMarks.push({id:item.id,text:extracted.text,ranges:extracted.ranges,roleKey:role.roleKey,
    body,start:extracted.start,end:extracted.end,messageId:sourceId,newlyAdded:wasNew});
  snippetUpdatePickCount();snippetScheduleMarks();
  if(snippetTapFromFloating)showSnippetActionMenu(extracted.text,sourceId,e.clientX,e.clientY);
}
function stopSnippetPicking(returnToBox=true){
  hideSnippetActionMenu();
  snippetPicking=false;
  snippetQuickTarget=null;
  snippetTapFromFloating=false;
  syncSnippetTapHandle();
  document.querySelectorAll('#chat .mes.pk-snip-active-message').forEach(m=>m.classList.remove('pk-snip-active-message'));
  snippetMergeEditor?.remove();snippetMergeEditor=null;
  snippetBar?.remove();snippetBar=null;
  snippetMarks.length=0;
  snippetMarkHost?.remove();snippetMarkHost=null;
  if(snippetMarkFrame){window.cancelAnimationFrame(snippetMarkFrame);snippetMarkFrame=0;}
  document.removeEventListener('click',onSnippetClick,true);
  document.removeEventListener('scroll',snippetScheduleMarks,true);
  window.removeEventListener('scroll',snippetScheduleMarks);
  window.removeEventListener('resize',snippetScheduleMarks);
  window.visualViewport?.removeEventListener('scroll',snippetScheduleMarks);
  window.visualViewport?.removeEventListener('resize',snippetScheduleMarks);
  if(returnToBox)openSnippetBox();
}
function startSnippetPicking(options={}){
  hideRepoSelection();hideSnippetActionMenu();
  // Also called as a button handler (with MouseEvent); only explicit quick options scope it.
  closeSnippetBox();
  if(snippetPicking)stopSnippetPicking(false);
  const quick=options?.quick===true&&Number.isInteger(options.messageId)&&options.messageId>=0;
  snippetTapFromFloating=options?.fromFloating===true;
  snippetQuickTarget=quick?{id:options.messageId,chatKey:snippetChatIdentity(),message:ctx().chat?.[options.messageId]}:null;
  if(quick)document.querySelector('#chat .mes[mesid="'+options.messageId+'"]')?.classList.add('pk-snip-active-message');
  snippetPicking=true;
  snippetMarkHost=document.createElement('div');snippetMarkHost.id='pk-snip-mark-host';
  document.body.appendChild(snippetMarkHost);
  snippetBar=document.createElement('div');snippetBar.id='pk-snip-bar';
  snippetBar.innerHTML='<span>轻点正文选句 <small data-snip-count>0 句已标记</small></span><div class="pk-snip-pick-actions"><button type="button" data-snip-pick-merge disabled>合并</button><button type="button" data-snip-pick-done>完成</button></div>';
  if(quick)snippetBar.querySelector('span').firstChild.textContent='点击本条消息中的句子 ';
  if(snippetTapFromFloating)snippetBar.querySelector('span').firstChild.textContent='点句收藏并可直接美化 · 点图标退出 ';
  snippetBar.querySelector('[data-snip-pick-merge]').onclick=e=>{
    e.preventDefault();e.stopPropagation();snippetMergeFromPicking();
  };
  snippetBar.querySelector('[data-snip-pick-done]').onclick=e=>{
    e.preventDefault();e.stopPropagation();stopSnippetPicking(!snippetQuickTarget&&!snippetTapFromFloating);
  };
  document.body.appendChild(snippetBar);
  document.addEventListener('click',onSnippetClick,true);
  document.addEventListener('scroll',snippetScheduleMarks,true);
  window.addEventListener('scroll',snippetScheduleMarks,{passive:true});
  window.addEventListener('resize',snippetScheduleMarks);
  window.visualViewport?.addEventListener('scroll',snippetScheduleMarks);
  window.visualViewport?.addEventListener('resize',snippetScheduleMarks);
  syncSnippetTapHandle();
}
function closeSnippetBox(){snippetMergeEditor?.remove();snippetMergeEditor=null;snippetBox?.remove();snippetBox=null;}
// Pick legible label color for any user-selected accent, including pale pastels.
function snippetLuminance(hex){
  const parts=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255);
  const linear=parts.map(v=>v<=0.04045?v/12.92:((v+0.055)/1.055)**2.4);
  return linear[0]*0.2126+linear[1]*0.7152+linear[2]*0.0722;
}
function snippetContrast(a,b){
  const x=snippetLuminance(a),y=snippetLuminance(b);
  return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);
}
function snippetAccentText(hex){return snippetLuminance(hex)>0.179?'#191c20':'#ffffff';}
function snippetAccentInk(accent,background){
  if(snippetContrast(accent,background)>=4.5)return accent;
  // Colored text needs to contrast with the panel, not with its own fill.
  const dark='#191c20',light='#ffffff';
  return snippetContrast(dark,background)>=snippetContrast(light,background)?dark:light;
}
function snippetApplyAppearance(){
  if(!snippetBox)return;
  const p=snippetPrefs();
  for(const [name,def] of [['accent',snippetDefaultPrefs.accent],['highlight','#f2bd68'],['lightBg','#ffffff'],['darkBg','#191c20']])
    if(!/^#[0-9a-fA-F]{6}$/.test(String(p[name])))p[name]=def;
  for(const [name,lower,upper] of [['fontSize',12,20],['panelHeight',60,94],['panelWidth',78,99]])
    p[name]=Math.max(lower,Math.min(upper,Number(p[name])||lower));
  const dark=p.theme==='dark'||(p.theme==='auto'&&window.matchMedia?.('(prefers-color-scheme: dark)')?.matches);
  snippetBox.dataset.theme=dark?'dark':'light';
  snippetBox.style.setProperty('--sn-bg',dark?p.darkBg:p.lightBg);
  const accent=dark&&p.accent===snippetDefaultPrefs.accent?'#f4f4f5':p.accent;
  snippetBox.style.setProperty('--sn-accent',accent);
  snippetBox.style.setProperty('--sn-accent-fg',snippetAccentText(accent));
  snippetBox.style.setProperty('--sn-accent-ink',snippetAccentInk(accent,dark?p.darkBg:p.lightBg));
  snippetBox.style.setProperty('--sn-font-size',p.fontSize+'px');
  snippetBox.style.setProperty('--sn-panel-height',p.panelHeight+'dvh');
  snippetBox.style.setProperty('--sn-panel-width',p.panelWidth+'vw');
  snippetBox.dataset.density=p.density;
}
function snippetAvatarElement(role){
  const avatar=document.createElement('span');avatar.className='pk-snip-avatar';
  const url=role.avatar||'';
  if(url){
    const im=document.createElement('img');im.alt='';im.loading='lazy';im.src=url;
    im.onerror=()=>{im.remove();avatar.textContent=Array.from(role.name||'未')[0];};
    avatar.appendChild(im);
  }else avatar.textContent=Array.from(role.name||'未')[0];
  return avatar;
}
function snippetLabelTime(item){
  const t=Number(item.savedAt||0);
  if(!t)return '';
  const d=new Date(t);
  if(!Number.isFinite(d.getTime()))return '';
  return `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')}`;
}
function snippetMake(tag,cls,text){
  const el=document.createElement(tag);if(cls)el.className=cls;
  if(text!==undefined)el.textContent=text;return el;
}
function snippetButton(text,click,cls=''){
  const b=snippetMake('button',cls,text);b.type='button';b.onclick=click;return b;
}
function snippetSafeCopy(obj){
  return JSON.parse(JSON.stringify(obj,(k,v)=>['__proto__','constructor','prototype'].includes(k)?undefined:v));
}
const snippetNewId=()=>String(Date.now())+'-'+Math.random().toString(36).slice(2,10);
const snippetRecordKey=item=>snippetRoleOf(item).key+'\u0000'+item.text;
function snippetValidatedItems(items){
  if(!Array.isArray(items))throw Error('收藏列表格式错误');
  if(items.length>5000)throw Error('收藏记录超过 5000 条');
  const result=[],usedIds=new Set();
  for(const item of items){
    if(!item||typeof item!=='object'||Array.isArray(item)||typeof item.text!=='string')continue;
    const value=item.text.trim();
    if(!value||value.length>10000)continue;
    const copy=snippetSafeCopy(item);
    copy.text=value;
    copy.roleKey=typeof copy.roleKey==='string'&&copy.roleKey.trim()?copy.roleKey.trim().slice(0,200):'unclassified';
    copy.roleName=typeof copy.roleName==='string'?copy.roleName.slice(0,200):'';
    copy.avatar=typeof copy.avatar==='string'?copy.avatar.slice(0,12000):'';
    copy.sourceChat=typeof copy.sourceChat==='string'?copy.sourceChat.slice(0,300):'';
    copy.messageId=Number.isInteger(copy.messageId)&&copy.messageId>=0?copy.messageId:null;
    copy.savedAt=Number.isFinite(copy.savedAt)&&copy.savedAt>0?copy.savedAt:Date.now();
    let id=typeof copy.id==='string'&&copy.id.trim()&&copy.id.length<=120?copy.id:'';
    while(!id||usedIds.has(id))id=snippetNewId();
    copy.id=id;usedIds.add(id);
    // Source offsets are meaningful only as a valid ordered pair.
    if(!Number.isInteger(copy.sourceStart)||!Number.isInteger(copy.sourceEnd)||copy.sourceStart<0||copy.sourceEnd<=copy.sourceStart){
      delete copy.sourceStart;delete copy.sourceEnd;delete copy.sourceOffsetMode;
    } else if(copy.sourceOffsetMode!=='message') {
      // Legacy offsets were paragraph-local; never upgrade them implicitly.
      delete copy.sourceOffsetMode;
    }
    result.push(copy);
  }
  return result;
}
// Preserve existing IDs during merge, but never let an imported ID collide
// with a different saved sentence (selection and deletion are ID-based).
function snippetMergeItems(current, imported){
  const result=Array.isArray(current)?current.slice():[];
  const keys=new Set(result.filter(x=>x&&typeof x.text==='string').map(snippetRecordKey));
  const ids=new Set(result.filter(x=>x&&typeof x.id==='string').map(x=>x.id));
  for(const item of imported){
    const key=snippetRecordKey(item);
    if(keys.has(key))continue;
    const next={...item};
    while(!next.id||ids.has(next.id))next.id=snippetNewId();
    keys.add(key);ids.add(next.id);result.push(next);
  }
  if(result.length>5000)throw Error('合并后收藏超过 5000 条，请分批导入');
  return result;
}
function snippetExportData(){
  const data={format:'punch-poster-full-backup',version:1,
    exportedAt:new Date().toISOString(),pluginId:'6db7fd72-ea0f-4aeb-9acc-4c9134a64c1f',
    module:'punch-poster',settings:snippetSafeCopy(store())};
  const json=JSON.stringify(data,null,2);
  const blob=new window.Blob([json],{type:'application/json;charset=utf-8'});
  const url=window.URL.createObjectURL(blob);
  download(url,'打孔海报-完整备份.json');
  window.setTimeout(()=>window.URL.revokeObjectURL(url),30000);
}
function snippetImportData(file){
  if(!file)return;
  if(file.size>50000000){snippetToast('备份文件超过 50 MB','error');return;}
  file.text().then(raw=>{
    const data=JSON.parse(raw);
    const full=data?.format==='punch-poster-full-backup'&&data.module==='punch-poster'
      &&data.settings&&typeof data.settings==='object'&&!Array.isArray(data.settings);
    if(full){
      const incoming=snippetSafeCopy(data.settings);
      // Import is a trust boundary. Reject object keys that could alter a
      // dictionary prototype when merging or restoring external backup JSON.
      const forbidden=new Set(['__proto__','constructor','prototype']);
      if(Object.keys(incoming).some(k=>forbidden.has(k)))throw Error('备份包含不安全的字段名');
      if(!incoming.cur||typeof incoming.cur!=='object'||Array.isArray(incoming.cur))throw Error('备份缺少必要的插件设置');
      if(incoming.pickedSentences!==undefined)incoming.pickedSentences=snippetValidatedItems(incoming.pickedSentences);
      for(const key of ['tpl','sigTpl','cssTpl','cssHidden']){
        if(incoming[key]!==undefined&&(typeof incoming[key]!=='object'||!incoming[key]||Array.isArray(incoming[key])))
          throw Error('备份中的 '+key+' 格式错误');
      }
      if(incoming.cssTpl){
        // Count is deliberately not capped: users can import additional templates later.
        // The 50 MB backup size limit and per-template validation still apply.
        for(const [key,item] of Object.entries(incoming.cssTpl)){
          if(!item||typeof item!=='object'||Array.isArray(item)||
             typeof item.html!=='string'||!item.html.includes('data-pk="body"')||
             typeof item.css!=='string'||typeof item.id!=='string'||
             item.html.length>150000||item.css.length>180000||forbidden.has(key))
            throw Error('备份中的 CSS 模板损坏：'+key);
          // A backup must satisfy exactly the same restrictions as importing
          // a CSS file directly, including external resources and scripts.
          try{cssClean(cssSpecSource(item));}catch(e){throw Error('备份 CSS 模板不安全：'+key+'（'+e.message+'）');}
        }
      }
      if(incoming.tpl){
        for(const [key,item] of Object.entries(incoming.tpl))
          if(forbidden.has(key)||!item||typeof item!=='object'||Array.isArray(item))throw Error('备份中的预设损坏：'+key);
      }
      if(incoming.sigTpl){
        for(const [key,item] of Object.entries(incoming.sigTpl))
          if(forbidden.has(key)||!item||typeof item!=='object'||Array.isArray(item))throw Error('备份中的署名预设损坏：'+key);
      }
      if(incoming.cssHidden){
        for(const key of Object.keys(incoming.cssHidden))
          if(forbidden.has(key))throw Error('备份包含无效模板 ID：'+key);
      }
      if(incoming.snippetCollapsedRoles!==undefined){
        incoming.snippetCollapsedRoles=Array.isArray(incoming.snippetCollapsedRoles)
          ?incoming.snippetCollapsedRoles.filter(v=>typeof v==='string').slice(0,2000):[];
      }
      if(incoming.snippetPrefs!==undefined && (!incoming.snippetPrefs||typeof incoming.snippetPrefs!=='object'||Array.isArray(incoming.snippetPrefs)))
        incoming.snippetPrefs={};
      const existing=store();
      if(snippetImportMode==='replace'){
        if(!window.confirm('将用备份替换「打孔海报」的全部设置、CSS 模板、收藏和预设。请先保存当前备份。确定恢复？'))return;
        for(const key of Object.keys(existing))delete existing[key];
        Object.assign(existing,incoming);
      }else{
        // Validate the complete merge first; an error must not partially change
        // CSS templates or presets in the live extension settings object.
        const mergedSentences=snippetMergeItems(existing.pickedSentences,incoming.pickedSentences||[]);
        for(const key of ['tpl','sigTpl','cssTpl','cssHidden'])
          if(incoming[key]&&typeof incoming[key]==='object'&&!Array.isArray(incoming[key]))
            existing[key]={...incoming[key],...(existing[key]||{})};
        existing.pickedSentences=mergedSentences;
        for(const [key,val] of Object.entries(incoming))
          if(!(key in existing))existing[key]=val;
      }
      store();persist();syncSnippetTapHandle();snippetChosen.clear();snippetToast('完整插件数据已恢复','success');renderSnippetBox();
      if(st.ov){fillCssList();syncAll();schedule(true);}return;
    }
    // Backward compatibility: old sentence-only exports remain importable.
    const items=Array.isArray(data)?data:(data?.format==='punch-poster-sentences'&&Array.isArray(data.sentences)?data.sentences:null);
    if(!items)throw Error('不是有效的打孔海报完整备份或旧收藏备份');
    const valid=snippetValidatedItems(items);
    const replace=snippetImportMode==='replace';
    if(replace&&!window.confirm('此文件只有收藏数据。确定替换全部收藏吗？其余插件数据不会改动。'))return;
    store().pickedSentences=snippetMergeItems(replace?[]:snippetStore(),valid);
    if(data?.preferences&&typeof data.preferences==='object'&&replace)
      store().snippetPrefs={...snippetDefaultPrefs,...Object.fromEntries(Object.entries(data.preferences).filter(([k])=>k in snippetDefaultPrefs))};
    persist();syncSnippetTapHandle();snippetChosen.clear();snippetToast('旧版收藏数据已导入','success');renderSnippetBox();
  }).catch(error=>snippetToast(error.message||'备份导入失败','error'));
}
function snippetExportCss(spec){
  const raw=cssSpecSource(spec);
  download('data:text/css;charset=utf-8,'+encodeURIComponent(raw),cssTemplateName(spec.id,spec.name)+'.css');
}
function snippetImportCss(file){
  if(!file)return;
  file.text().then(text=>{
    const spec=cssClean(text);
    const prior=cssEntries()[spec.id];
    if(prior&&JSON.stringify(prior)!==JSON.stringify(spec)
      &&!window.confirm('已存在同名模板「'+spec.name+'」。确定覆盖吗？'))return;
    cssEntries()[spec.id]=spec;
    if(store().cssHidden)delete store().cssHidden[spec.id];
    persist();snippetToast('已导入模板：'+spec.name,'success');renderSnippetBox();
  }).catch(error=>snippetToast(error.message||'CSS 导入失败','error'));
}
function snippetMergePlan(ids,picking=false){
  const all=snippetStore();
  const records=ids.map(id=>all.find(item=>item.id===id)).filter(Boolean);
  if(records.length<2){snippetToast('至少选择两句才能合并');return null;}
  const keys=new Set(records.map(item=>snippetRoleOf(item).key));
  if(keys.size!==1){snippetToast('请先选择同一角色的句子合并，避免角色归属混乱','error');return null;}
  // Recover order of older paragraph-local records only if their saved text
  // occurs at a unique position in the current message. Never guess on repeats.
  const oldPositions=new Map();
  const sameSource=records.every(x=>x.messageId!=null&&x.messageId===records[0].messageId&&x.sourceChat===records[0].sourceChat);
  const activeChat=String(ctx().chatId??ctx().chatName??'');
  if(sameSource && records[0].sourceChat===activeChat){
    const body=document.querySelector('#chat .mes[mesid="'+records[0].messageId+'"] .mes_text');
    if(body){
      const text=snippetNodeText(body).full;
      for(const item of records){
        const pos=text.indexOf(item.text);
        if(pos>=0 && text.indexOf(item.text,pos+1)<0) oldPositions.set(item.id,pos);
      }
    }
  }
  const reliablePosition=item=>item.sourceOffsetMode==='message'&&Number.isInteger(item.sourceStart)
    ?item.sourceStart:oldPositions.get(item.id);
  records.sort((a,b)=>{
    const sameMsg=a.sourceChat===b.sourceChat&&a.messageId===b.messageId&&a.messageId!=null;
    const x=reliablePosition(a),y=reliablePosition(b);
    if(sameMsg&&Number.isInteger(x)&&Number.isInteger(y))return x-y;
    return (Number(a.savedAt)||0)-(Number(b.savedAt)||0);
  });
  // Merge exactly what was selected. Taking the whole substring between the
  // first and last saved offsets also imports *unselected* intervening text.
  // Use offsets only to order proven message-global selections; older saved
  // paragraph-local offsets are treated as untrusted for merge spacing.
  const proposal=records.map((item,index)=>{
    const prev=records[index-1];
    if(!prev)return item.text;
    const sameMessage=item.sourceChat===prev.sourceChat&&item.messageId===prev.messageId&&item.messageId!=null;
    if(!sameMessage)return '\n\n'+item.text;
    const reliable=prev.sourceOffsetMode==='message'&&item.sourceOffsetMode==='message';
    const gap=reliable&&Number.isInteger(prev.sourceEnd)&&Number.isInteger(item.sourceStart)
      ?item.sourceStart-prev.sourceEnd:null;
    return (gap!==null&&gap>=0&&gap<=2?'':'\n')+item.text;
  }).join('');
  return {records,proposal,picking};
}
function snippetOpenMergeEditor(plan){
  snippetMergeEditor?.remove();
  const overlay=document.createElement('div');overlay.id='pk-snip-merge-overlay';
  if(snippetBox){
    overlay.style.setProperty('--sn-accent',snippetBox.style.getPropertyValue('--sn-accent'));
    overlay.style.setProperty('--sn-accent-fg',snippetBox.style.getPropertyValue('--sn-accent-fg'));
  }
  const modal=snippetMake('div','pk-snip-merge-modal');
  modal.append(snippetMake('h3','','合并句子'),snippetMake('p','pk-snip-help','确认最终文字后，两条或多条收藏会合并成一条。原句可在这里调整。'));
  const editor=document.createElement('textarea');editor.className='pk-snip-merge-text';editor.value=plan.proposal;
  modal.appendChild(editor);
  const buttons=snippetMake('div','pk-snip-merge-actions');
  buttons.append(snippetButton('取消',()=>{overlay.remove();snippetMergeEditor=null;},'pk-snip-soft'),
    snippetButton('保存合并',()=>{
      const value=normalize(editor.value).trim();
      if(!value){snippetToast('合并后的文字不能为空','error');return;}
      const ids=new Set(plan.records.map(x=>x.id));
      const existing=snippetStore(),first=plan.records[0];
      const survivor={...first,text:value,savedAt:Math.min(...plan.records.map(x=>Number(x.savedAt)||Date.now()))};
      const sameMessage=first.messageId!=null && plan.records.every(x=>x.messageId===first.messageId&&x.sourceChat===first.sourceChat);
      if(!sameMessage){
        // Mixed-source text is a new composition, not a quote from the first
        // message. Keep role attribution, but never retain a false message ID.
        survivor.messageId=null;
        if(!plan.records.every(x=>x.sourceChat===first.sourceChat))survivor.sourceChat='';
      }
      // A composed sentence is not necessarily a contiguous span: some
      // sentences between its sources may have intentionally been skipped.
      // Keeping the min/max offset would misrepresent future selections.
      delete survivor.sourceStart;
      delete survivor.sourceEnd;
      delete survivor.sourceOffsetMode;
      const duplicate=existing.some(x=>!ids.has(x.id)&&snippetRecordKey(x)===snippetRecordKey({...first,text:value}));
      if(duplicate){snippetToast('已经收藏过相同的合并文字','error');return;}
      store().pickedSentences=[survivor,...existing.filter(x=>!ids.has(x.id))];
      for(const id of ids)snippetChosen.delete(id);
      persist();overlay.remove();snippetMergeEditor=null;
      if(plan.picking){
        const markGroup=snippetMarks.filter(x=>ids.has(x.id));
        const shared=markGroup[0]||{};
        const combined={...shared,id:survivor.id,text:survivor.text,
          messageId:survivor.messageId,
          ranges:markGroup.flatMap(x=>x.ranges||[])};
        for(let i=snippetMarks.length-1;i>=0;i--)if(ids.has(snippetMarks[i].id))snippetMarks.splice(i,1);
        snippetMarks.push(combined);
        snippetUpdatePickCount();snippetScheduleMarks();
      }else snippetRenderList(snippetBox?.querySelector('.pk-snip-list'));
      snippetToast('已合并成一条收藏','success');
    },'pk-snip-primary'));
  modal.appendChild(buttons);overlay.appendChild(modal);
  overlay.addEventListener('click',e=>{if(e.target===overlay){overlay.remove();snippetMergeEditor=null;}});
  document.body.appendChild(overlay);snippetMergeEditor=overlay;
  editor.focus();
}
function snippetMergeFromPicking(){
  const plan=snippetMergePlan(snippetMarks.map(x=>x.id),true);
  if(plan)snippetOpenMergeEditor(plan);
}
function snippetMergeFromLibrary(){
  const plan=snippetMergePlan([...snippetChosen],false);
  if(plan)snippetOpenMergeEditor(plan);
}

function snippetRenderLibrary(area){
  // Search is at the top of the page, before any collecting controls.
  const filters=snippetMake('div','pk-snip-filters');
  const input=document.createElement('input');input.type='search';
  input.placeholder='搜索句子、角色';input.setAttribute('aria-label','搜索句子或角色');
  input.value=snippetSearch;
  input.oninput=()=>{snippetSearch=input.value;snippetVisibleCounts.clear();snippetRenderList(area.querySelector('.pk-snip-list'));};
  const choose=document.createElement('select');choose.setAttribute('aria-label','按角色筛选');
  const known=new Map();
  for(const item of snippetStore().filter(item=>item&&typeof item.text==='string')){const role=snippetRoleOf(item);known.set(role.key,role.name);}
  for(const [id,name] of [['all','全部角色'],...known.entries()]){
    const option=document.createElement('option');option.value=id;option.textContent=name;choose.appendChild(option);
  }
  if(![...choose.options].some(o=>o.value===snippetFilter))snippetFilter='all';
  choose.value=snippetFilter;
  choose.onchange=()=>{snippetFilter=choose.value;snippetVisibleCounts.clear();snippetRenderList(area.querySelector('.pk-snip-list'));};
  filters.append(input,choose);area.appendChild(filters);
  const toolbar=snippetMake('div','pk-snip-toolbar');
  toolbar.append(snippetButton('＋ 拾取句子',startSnippetPicking,'pk-snip-primary'),
    snippetButton('手动添加',()=>{snippetView='manual';renderSnippetBox();},'pk-snip-soft'));
  area.appendChild(toolbar);
  const list=snippetMake('div','pk-snip-list');area.appendChild(list);
  const footer=snippetMake('footer','pk-snip-footer');
  footer.appendChild(snippetMake('span','pk-snip-selected'));
  const actions=snippetMake('div','pk-snip-footer-actions');
  const merge=snippetButton('合并选中',snippetMergeFromLibrary,'pk-snip-merge');
  const del=snippetButton('删除',()=>{
    if(!snippetChosen.size)return;
    if(!window.confirm('删除选中的 '+snippetChosen.size+' 句？此操作无法撤销。'))return;
    store().pickedSentences=snippetStore().filter(x=>!snippetChosen.has(x.id));
    snippetChosen.clear();persist();snippetRenderList(list);
  },'pk-snip-danger');
  actions.append(merge,del);footer.appendChild(actions);area.appendChild(footer);
  snippetRenderList(list);
}
function snippetRenderList(list){
  if(!list)return;
  list.replaceChildren();
  const records=snippetStore().filter(item=>item&&typeof item.text==='string'&&(snippetFilter==='all'||snippetRoleOf(item).key===snippetFilter)
    &&(!snippetSearch||item.text.toLowerCase().includes(snippetSearch.toLowerCase())
    ||snippetRoleOf(item).name.toLowerCase().includes(snippetSearch.toLowerCase())));
  const grouped=new Map();
  for(const item of records){const role=snippetRoleOf(item);if(!grouped.has(role.key))grouped.set(role.key,{role,items:[]});grouped.get(role.key).items.push(item);}
  if(!records.length)list.appendChild(snippetMake('div','pk-snip-empty',snippetStore().length?'没有找到相关句子':'尚无收藏。点「拾取句子」开始保存。'));
  for(const {role,items} of grouped.values()){
    const group=snippetMake('section','pk-snip-role-group');
    const head=snippetButton(' ',()=>{
      if(snippetCollapsed.has(role.key))snippetCollapsed.delete(role.key);else snippetCollapsed.add(role.key);
      const folded=snippetCollapsed.has(role.key);
      group.classList.toggle('is-collapsed',folded);
      head.setAttribute('aria-expanded',String(!folded));
      const value=store().snippetCollapsedRoles||[];
      store().snippetCollapsedRoles=folded?[...new Set([...value,role.key])]:value.filter(x=>x!==role.key);
      persist();
    },'pk-snip-role-heading');
    const currentFolded=snippetCollapsed.has(role.key);
    group.classList.toggle('is-collapsed',currentFolded);
    head.setAttribute('aria-expanded',String(!currentFolded));
    head.append(snippetAvatarElement(role),snippetMake('strong','',role.name),snippetMake('span','pk-snip-muted',items.length+' 句'),snippetMake('i','pk-snip-chevron'));
    group.appendChild(head);
    const content=snippetMake('div','pk-snip-role-content');
    const visibleCount=snippetVisibleCounts.get(role.key)||SNIPPET_PAGE_SIZE;
    for(const item of items.slice(0,visibleCount)){
      const card=snippetMake('div','pk-snip-card'+(snippetChosen.has(item.id)?' is-selected':''));
      const text=snippetButton('',()=>{snippetDetailId=item.id;snippetView='detail';renderSnippetBox();},'pk-snip-card-content');
      text.appendChild(snippetMake('span','pk-snip-card-quote',item.text));
      const meta=snippetMake('span','pk-snip-card-meta');
      meta.textContent=snippetLabelTime(item);
      text.appendChild(meta);
      const check=snippetButton(snippetChosen.has(item.id)?'✓':'',()=>{
        if(snippetChosen.has(item.id))snippetChosen.delete(item.id);else snippetChosen.add(item.id);
        card.classList.toggle('is-selected',snippetChosen.has(item.id));
        check.textContent=snippetChosen.has(item.id)?'✓':'';snippetUpdateSelectionFooter();
      },'pk-snip-check');check.setAttribute('aria-label','选择此句');
      card.append(text,check);content.appendChild(card);
    }
    if(items.length>visibleCount){
      const more=snippetButton('显示更多（剩余 '+(items.length-visibleCount)+' 句）',()=>{
        const scroll=list.scrollTop;
        snippetVisibleCounts.set(role.key,visibleCount+SNIPPET_PAGE_SIZE);
        snippetRenderList(list);list.scrollTop=scroll;
      },'pk-snip-small');
      more.style.cssText='display:block;margin:10px auto 15px;padding:10px 14px;';
      content.appendChild(more);
    }
    group.appendChild(content);list.appendChild(group);
  }
  snippetUpdateSelectionFooter();
}
function snippetUpdateSelectionFooter(){
  if(!snippetBox)return;
  const count=snippetBox.querySelector('.pk-snip-selected');
  if(count)count.textContent=snippetChosen.size?'已选 '+snippetChosen.size+' 句':'共收藏 '+snippetStore().length+' 句';
  const del=snippetBox.querySelector('.pk-snip-danger');if(del)del.hidden=!snippetChosen.size;
  const merge=snippetBox.querySelector('.pk-snip-merge');if(merge)merge.hidden=snippetChosen.size<2;
}
function snippetRenderDetail(area){
  const item=snippetStore().find(x=>x.id===snippetDetailId);
  if(!item){snippetView='library';renderSnippetBox();return;}
  const role=snippetRoleOf(item);
  area.appendChild(snippetButton('‹ 返回收藏',()=>{snippetView='library';renderSnippetBox();},'pk-snip-back'));
  const card=snippetMake('div','pk-snip-detail-card');
  const head=snippetMake('div','pk-snip-role-heading');
  head.append(snippetAvatarElement(role),snippetMake('strong','',role.name),snippetMake('span','pk-snip-muted',snippetLabelTime(item)));
  card.append(head,snippetMake('div','pk-snip-detail-text',item.text));area.appendChild(card);
  const actions=snippetMake('div','pk-snip-detail-actions');
  actions.appendChild(snippetButton('repo 美化',()=>{
    const id=snippetDraftMessageId(item);
    if(id===null){snippetToast('当前聊天找不到可用的来源消息，请切换聊天或复制文字','error');return;}
    const text=item.text;closeSnippetBox();openById(id,text);
  },'pk-snip-primary'));
  actions.appendChild(snippetButton('复制文字',async()=>{
    try{
      if(window.navigator.clipboard?.writeText)await window.navigator.clipboard.writeText(item.text);
      else{
        const box=document.createElement('textarea');box.value=item.text;
        box.style.cssText='position:fixed;left:-9999px;top:0;opacity:0';
        document.body.appendChild(box);box.focus();box.select();
        const ok=document.execCommand?.('copy');box.remove();
        if(!ok)throw Error('当前环境不支持复制');
      }
      snippetToast('已复制','success');
    }catch(error){snippetToast(error.message||'复制失败','error');}
  },'pk-snip-soft'));
  actions.appendChild(snippetButton('删除',()=>{
    if(!window.confirm('确定删除这条收藏？'))return;
    store().pickedSentences=snippetStore().filter(x=>x.id!==item.id);
    snippetChosen.delete(item.id);persist();snippetView='library';renderSnippetBox();
  },'pk-snip-danger-outline'));
  area.appendChild(actions);
}
function snippetField(title,node){
  const row=snippetMake('label','pk-snip-field');row.appendChild(snippetMake('span','',title));row.appendChild(node);return row;
}
function snippetInput(type,value,onChange){
  const el=document.createElement('input');el.type=type;el.value=value;el.oninput=()=>onChange(el.value);return el;
}
function snippetRenderSettings(area){
  const p=snippetPrefs();
  area.appendChild(snippetButton('‹ 返回收藏',()=>{snippetView='library';renderSnippetBox();},'pk-snip-back'));
  area.appendChild(snippetMake('h3','pk-snip-section-title','外观'));
  const themes=snippetMake('div','pk-snip-segments');
  for(const [value,label] of [['auto','跟随系统'],['light','日间'],['dark','夜间']]){
    themes.appendChild(snippetButton(label,()=>{p.theme=value;persist();snippetApplyAppearance();
      for(const btn of themes.children)btn.classList.toggle('is-active',btn.dataset.value===value);
    },'pk-snip-segment'+(p.theme===value?' is-active':'')));
    themes.lastChild.dataset.value=value;
  }
  area.appendChild(themes);
  area.appendChild(snippetField('日间面板底色',snippetInput('color',p.lightBg,value=>{p.lightBg=value;persist();snippetApplyAppearance();})));
  area.appendChild(snippetField('夜间面板底色',snippetInput('color',p.darkBg,value=>{p.darkBg=value;persist();snippetApplyAppearance();})));
  area.appendChild(snippetField('强调颜色',snippetInput('color',p.accent,value=>{p.accent=value;persist();snippetApplyAppearance();})));
  area.appendChild(snippetField('点句高亮颜色',snippetInput('color',p.highlight,value=>{p.highlight=value;persist();})));
  area.appendChild(snippetMake('h3','pk-snip-section-title','调整面板'));
  const slider=(label,key,min,max,unit)=>{
    const input=snippetInput('range',p[key],value=>{p[key]=Number(value);valueEl.textContent=value+unit;persist();snippetApplyAppearance();});
    input.min=min;input.max=max;input.step='1';
    const row=snippetMake('div','pk-snip-slider');
    const labelEl=snippetMake('span','',label),valueEl=snippetMake('b','',p[key]+unit);
    row.append(labelEl,input,valueEl);return row;
  };
  area.append(slider('文字大小','fontSize',12,20,'px'),slider('面板高度','panelHeight',60,94,'vh'),slider('面板宽度','panelWidth',78,99,'vw'));
  const density=snippetMake('div','pk-snip-segments');
  for(const [value,label] of [['normal','标准间距'],['compact','紧凑间距']]){
    const b=snippetButton(label,()=>{p.density=value;persist();snippetApplyAppearance();
      for(const child of density.children)child.classList.toggle('is-active',child.dataset.value===value);
    },'pk-snip-segment'+(p.density===value?' is-active':''));b.dataset.value=value;density.appendChild(b);
  }area.appendChild(density);
  area.appendChild(snippetMake('h3','pk-snip-section-title','收藏悬浮图标'));
  const shortcut=document.createElement('input');shortcut.type='checkbox';
  shortcut.checked=p.tapShortcut!==false;
  shortcut.setAttribute('aria-label','显示收藏悬浮图标');
  shortcut.onchange=()=>{p.tapShortcut=shortcut.checked;persist();syncSnippetTapHandle();};
  area.appendChild(snippetField('显示悬浮图标',shortcut));
  const preview=snippetMake('div','pk-snip-icon-preview');
  const refreshPreview=()=>{
    preview.replaceChildren();
    if(typeof p.iconImage==='string'&&p.iconImage){
      const img=document.createElement('img');img.alt='当前悬浮图标';img.src=p.iconImage;
      img.onerror=()=>{preview.textContent='图片无法加载，请更换文件或链接';};
      preview.appendChild(img);
    }else preview.appendChild(snippetMake('span','pk-snip-muted','默认书签图标（可换成任意比例图片）'));
  };
  refreshPreview();area.appendChild(preview);
  const fileInput=document.createElement('input');fileInput.type='file';
  fileInput.accept='image/png,image/jpeg,image/webp,image/gif,image/svg+xml';fileInput.hidden=true;
  fileInput.onchange=()=>{
    const file=fileInput.files?.[0];fileInput.value='';if(!file)return;
    if(!file.type.startsWith('image/')||file.size>3*1024*1024){snippetToast('请选择 3 MB 以内的图片','error');return;}
    const reader=new window.FileReader();
    reader.onload=()=>{
      if(typeof reader.result!=='string'||!reader.result.startsWith('data:image/'))return snippetToast('无法读取图片','error');
      p.iconImage=reader.result;persist();syncSnippetTapHandle();refreshPreview();urlInput.value='';snippetToast('图标已保存','success');
    };
    reader.onerror=()=>snippetToast('读取图标失败','error');reader.readAsDataURL(file);
  };
  area.appendChild(fileInput);
  const iconActions=snippetMake('div','pk-snip-icon-choices');
  iconActions.append(snippetButton('上传图片',()=>fileInput.click(),'pk-snip-soft'),
    snippetButton('恢复默认图标',()=>{p.iconImage='';persist();syncSnippetTapHandle();refreshPreview();urlInput.value='';},'pk-snip-soft'));
  area.appendChild(iconActions);
  const urlInput=snippetInput('url',typeof p.iconImage==='string'&&p.iconImage.startsWith('http')?p.iconImage:'',()=>{});
  urlInput.onchange=()=>{
    const url=urlInput.value.trim();
    if(!url){if(typeof p.iconImage==='string'&&p.iconImage.startsWith('http')){p.iconImage='';persist();syncSnippetTapHandle();refreshPreview();}return;}
    if(!/^https?:\/\//i.test(url))return;
    p.iconImage=url;persist();syncSnippetTapHandle();refreshPreview();
  };
  urlInput.placeholder='也可以粘贴图片链接（https://…）';urlInput.className='pk-snip-icon-input';
  area.appendChild(urlInput);
  const sz=snippetMake('div','pk-snip-slider');
  const sizeInput=snippetInput('range',p.iconSize,value=>{
    p.iconSize=Number(value);sizeValue.textContent=value+'px';persist();syncSnippetTapHandle();
  });
  sizeInput.min='28';sizeInput.max='120';sizeInput.step='2';
  const sizeValue=snippetMake('b','',p.iconSize+'px');
  sz.append(snippetMake('span','','图标大小'),sizeInput,sizeValue);area.appendChild(sz);
  area.appendChild(snippetButton('重置悬浮位置',()=>{
    p.floatX=null;p.floatY=null;persist();syncSnippetTapHandle();snippetToast('位置已重置','success');
  },'pk-snip-soft'));
  area.appendChild(snippetMake('p','pk-snip-help','轻点悬浮图标开启或退出点句收藏；开启后直接点正文句子。长方形、透明背景、不规则外轮廓都按原比例显示，不强制圆形裁剪。只有想换位置时才拖动图标，拖动不会收藏句子。关闭图标后仍可从魔棒 → 设置重新开启。'));
  area.appendChild(snippetMake('h3','pk-snip-section-title','划线美化'));
  const selectionToggle=document.createElement('input');selectionToggle.type='checkbox';
  selectionToggle.checked=p.selectionShortcut!==false;
  selectionToggle.setAttribute('aria-label','划线显示收藏与 repo 美化选项');
  selectionToggle.onchange=()=>{p.selectionShortcut=selectionToggle.checked;persist();if(!selectionToggle.checked)hideRepoSelection();};
  area.appendChild(snippetField('划线后显示收藏 / repo 美化',selectionToggle));
  area.appendChild(snippetMake('p','pk-snip-help','正常划线后出现「收藏｜repo 美化」小框；开启悬浮点句模式后，点击句子会直接收藏并出现「repo 美化」快捷选项。两个入口互不替代。'));
  area.appendChild(snippetMake('h3','pk-snip-section-title','数据管理'));
  const actions=snippetMake('div','pk-snip-settings-actions');
  actions.append(snippetButton('导出完整插件数据',snippetExportData,'pk-snip-soft'),snippetButton('导入完整插件数据',()=>snippetBox?.querySelector('[data-snip-file="data"]')?.click(),'pk-snip-soft'));
  area.appendChild(actions);
  const importSelect=document.createElement('select');
  for(const [id,label] of [['merge','合并（保留现有设置）'],['replace','替换（完整恢复备份）']]){const o=document.createElement('option');o.value=id;o.textContent=label;importSelect.append(o);}
  importSelect.value=snippetImportMode;importSelect.onchange=()=>{snippetImportMode=importSelect.value;};
  area.appendChild(snippetField('导入方式',importSelect));
  area.appendChild(snippetMake('p','pk-snip-help','完整备份包括 CSS 模板、打孔预设、作者等编辑设置、收藏句子及面板设置。不包含聊天全文或插件脚本本身。导入时推荐先备份当前数据。'));
  area.appendChild(snippetButton('清空全部收藏',()=>{
    if(!snippetStore().length)return snippetToast('收藏匣已为空');
    if(!window.confirm('确认清空全部 '+snippetStore().length+' 句收藏？此操作不可撤销。\n建议先导出备份。'))return;
    store().pickedSentences=[];snippetChosen.clear();persist();snippetToast('已清空收藏','success');renderSnippetBox();
  },'pk-snip-danger-outline'));
  area.appendChild(snippetButton('清空整个插件数据',()=>{
    if(!window.confirm('这会清空打孔海报的全部收藏、CSS 模板、预设、编辑信息和外观设置。请先导出完整备份。继续吗？'))return;
    if(!window.confirm('最后确认：所有打孔海报插件设置都将恢复初始状态，且无法撤销。确定清空？'))return;
    const state=store();
    for(const key of Object.keys(state))delete state[key];
    state.cur=clone(BASE);state.tpl={};state.sigTpl={};state.cssTpl={};state.cssHidden={};
    state.pickedSentences=[];state.snippetPrefs=clone(snippetDefaultPrefs);
    snippetChosen.clear();snippetCollapsed.clear();st.cssSignature='';
    persist();syncSnippetTapHandle();snippetToast('整个插件数据已清空','success');renderSnippetBox();
    if(st.ov){fillCssList();syncAll();schedule(true);}
  },'pk-snip-danger-outline pk-snip-wide'));

  area.appendChild(snippetMake('h3','pk-snip-section-title','模板'));
  const tplCount=Object.keys(cssEntries()).length;
  area.appendChild(snippetButton('管理已导入的 CSS 模板（'+tplCount+'） ›',()=>{snippetView='templates';renderSnippetBox();},'pk-snip-soft pk-snip-wide'));
}
function snippetRenderTemplates(area){
  area.appendChild(snippetButton('‹ 返回设置',()=>{snippetView='settings';renderSnippetBox();},'pk-snip-back'));
  const top=snippetMake('div','pk-snip-template-actions');
  top.appendChild(snippetButton('＋ 导入 CSS 模板',()=>snippetBox?.querySelector('[data-snip-file="css"]')?.click(),'pk-snip-soft'));
  area.appendChild(top);
  const records=Object.values(cssEntries());
  if(!records.length)area.appendChild(snippetMake('p','pk-snip-empty','暂无通过插件导入的 CSS 模板。原生打孔模板不在此列表中。'));
  for(const spec of records){
    const line=snippetMake('div','pk-snip-template-item');
    const name=snippetMake('div','pk-snip-template-name');
    name.append(snippetMake('strong','',cssTemplateName(spec.id,spec.name)),snippetMake('small','pk-snip-muted',spec.id));
    line.append(name,snippetButton('导出',()=>snippetExportCss(spec),'pk-snip-small'),
      snippetButton('删除',()=>{
        if(!window.confirm('删除 CSS 模板「'+spec.name+'」？\n建议先导出备份。'))return;
        delete cssEntries()[spec.id];
        if(cur().pageSkin==='css:'+spec.id)cur().pageSkin='punch';
        st.cssSignature='';persist();renderSnippetBox();
        if(st.ov){fillCssList();syncAll();schedule(true);}
      },'pk-snip-small pk-snip-danger-outline'));
    area.appendChild(line);
  }
  area.appendChild(snippetMake('p','pk-snip-help','这里只管理插件保存的 CSS 模板，不会影响收藏句子，也不会修改原始聊天。'));
}
function snippetRenderManual(area){
  area.appendChild(snippetButton('‹ 返回收藏',()=>{snippetView='library';renderSnippetBox();},'pk-snip-back'));
  const editor=document.createElement('textarea');editor.rows=5;editor.placeholder='粘贴或输入想收藏的一句话';editor.className='pk-snip-manual-input';area.appendChild(editor);
  const roleSelect=document.createElement('select');roleSelect.className='pk-snip-manual-role';
  const current=snippetCurrentCharacter(null);
  const roles=new Map([[current.roleKey,current]]);
  roles.set('unclassified',{roleKey:'unclassified',roleName:'未分类',avatar:''});
  for(const item of snippetStore()){
    if(!item||typeof item.text!=='string')continue;
    const role=snippetRoleOf(item);roles.set(role.key,{roleKey:role.key,roleName:role.name,avatar:role.avatar});
  }
  for(const role of roles.values()){
    const o=document.createElement('option');o.value=role.roleKey;o.textContent=role.roleName;roleSelect.append(o);
  }
  area.append(snippetField('归属角色',roleSelect),snippetButton('加入收藏',()=>{
    if(!editor.value.trim())return snippetToast('先输入一句话');
    const role=roles.get(roleSelect.value);
    if(addPickedSentence(editor.value,null,role)){snippetView='library';renderSnippetBox();}
  },'pk-snip-primary pk-snip-wide'));
}
function renderSnippetBox(){
  if(!snippetBox)return;
  snippetApplyAppearance();
  const heading=snippetBox.querySelector('[data-snip-title]');
  if(heading)heading.textContent={library:'句子拾取匣',detail:'句子详情',manual:'手动添加',settings:'设置',templates:'模板管理'}[snippetView]||'句子拾取匣';
  const settings=snippetBox.querySelector('[data-snip="settings"]');
  if(settings)settings.hidden=snippetView==='settings';
  const area=snippetBox.querySelector('.pk-snip-area');area.replaceChildren();
  area.classList.toggle('pk-snip-scrolling',snippetView!=='library');
  if(snippetView==='detail')snippetRenderDetail(area);
  else if(snippetView==='manual')snippetRenderManual(area);
  else if(snippetView==='settings')snippetRenderSettings(area);
  else if(snippetView==='templates')snippetRenderTemplates(area);
  else snippetRenderLibrary(area);
}
const snippetSystemTheme=window.matchMedia?.('(prefers-color-scheme: dark)');
const snippetSystemThemeChanged=()=>{if(snippetBox&&snippetPrefs().theme==='auto')snippetApplyAppearance();};
snippetSystemTheme?.addEventListener?.('change',snippetSystemThemeChanged);
function openSnippetBox(){
  if(snippetPicking)stopSnippetPicking(false);
  closeSnippetBox();
  snippetView='library';snippetDetailId=null;
  snippetCollapsed.clear();snippetVisibleCounts.clear();
  for(const key of store().snippetCollapsedRoles||[])snippetCollapsed.add(key);
  snippetBox=document.createElement('div');snippetBox.id='pk-snip-overlay';
  snippetBox.innerHTML=`<div class="pk-snip-modal" role="dialog" aria-modal="true" aria-label="句子拾取匣">
    <header class="pk-snip-head"><button type="button" data-snip="close" aria-label="关闭">×</button><strong data-snip-title>句子拾取匣</strong><button type="button" data-snip="settings" aria-label="设置">设置</button></header>
    <main class="pk-snip-area"></main>
    <input type="file" data-snip-file="data" accept="application/json,.json" hidden>
    <input type="file" data-snip-file="css" accept="text/css,.css" hidden>
  </div>`;
  snippetBox.querySelector('[data-snip="close"]').onclick=closeSnippetBox;
  snippetBox.querySelector('[data-snip="settings"]').onclick=()=>{snippetView='settings';renderSnippetBox();};
  const backup=snippetBox.querySelector('[data-snip-file="data"]');
  backup.onchange=()=>{const f=backup.files[0];backup.value='';snippetImportData(f);};
  const css=snippetBox.querySelector('[data-snip-file="css"]');
  css.onchange=()=>{const f=css.files[0];css.value='';snippetImportCss(f);};
  snippetBox.addEventListener('click',e=>{if(e.target===snippetBox)closeSnippetBox();});
  document.body.appendChild(snippetBox);renderSnippetBox();
}

function ensureRepoWandMenu() {
  const menu=document.querySelector('#extensionsMenu');
  if(!menu)return false;
  let row=menu.querySelector('#pk-wand');
  if(row)return true;
  row=document.createElement('div');
  row.id='pk-wand';
  row.className='extension_container interactable';
  row.setAttribute('role','button');
  row.setAttribute('tabindex','0');
    row.title='打开句子拾取匣；无需选中文字，不自动读取整楼';
  row.style.cssText='display:flex;align-items:center;gap:10px;padding:8px 12px;cursor:pointer;min-height:36px;';
  row.innerHTML='<i class="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i><span>repo美化</span>';
   const launch=()=>{
     openSnippetBox();
   };
  row.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();launch();});
  row.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();launch();}});
  menu.appendChild(row);
  return true;
}

// One tap toggles sentence picking; only moving the floating artwork uses dragging.
// No text selection listeners, no drag-to-collect gesture, and no shape mask.
let snippetTapHandle=null, snippetTapIconRendered=null, snippetTapMoved=false;
function snippetPositionHandle(){
  if(!snippetTapHandle)return;
  const p=snippetPrefs(),el=snippetTapHandle;
  if(Number.isFinite(p.floatX)&&Number.isFinite(p.floatY)){
    const rect=el.getBoundingClientRect();
    const w=rect.width||46,h=rect.height||46;
    const x=Math.max(4,Math.min(window.innerWidth-w-4,p.floatX*window.innerWidth-w/2));
    const y=Math.max(4,Math.min(window.innerHeight-h-4,p.floatY*window.innerHeight-h/2));
    el.style.left=x+'px';el.style.top=y+'px';el.style.right='auto';el.style.bottom='auto';
  }else{el.style.left='';el.style.top='';el.style.right='';el.style.bottom='';}
}
function syncSnippetTapHandle(){
  if(!snippetTapHandle)return;
  const p=snippetPrefs(),enabled=p.tapShortcut!==false;
  snippetTapHandle.hidden=!enabled;
  const active=snippetPicking&&snippetTapFromFloating;
  snippetTapHandle.classList.toggle('is-active',active);
  snippetTapHandle.setAttribute('aria-pressed',String(active));
  snippetTapHandle.setAttribute('aria-label',active?'退出点句收藏':'开启点句收藏');
  snippetTapHandle.title=active?'退出点句收藏':'点一下开启句子收藏（拖动可调整位置）';
  const image=typeof p.iconImage==='string'?p.iconImage.trim():'';
  if(snippetTapIconRendered!==image){
    snippetTapIconRendered=image;
    snippetTapHandle.replaceChildren();
    if(image&&(/^(?:https?:\/\/|data:image\/)/i).test(image)){
      const img=document.createElement('img');img.className='pk-snip-custom-icon';img.alt='';img.src=image;
      img.onerror=()=>{img.remove();const fallback=document.createElement('span');fallback.className='pk-snip-default-icon';fallback.innerHTML='<i class="fa-regular fa-bookmark" aria-hidden="true"></i>';snippetTapHandle?.appendChild(fallback);};
      snippetTapHandle.appendChild(img);
    }else{
      const fallback=document.createElement('span');fallback.className='pk-snip-default-icon';
      fallback.innerHTML='<i class="fa-regular fa-bookmark" aria-hidden="true"></i>';
      snippetTapHandle.appendChild(fallback);
    }
  }
  snippetTapHandle.style.setProperty('--pk-snip-icon-size',Math.max(28,Math.min(120,Number(p.iconSize)||54))+'px');
  // Defer positioning until a newly loaded image has its actual intrinsic size.
  snippetPositionHandle();
  const img=snippetTapHandle.querySelector('img');
  if(img&&!img.complete)img.onload=snippetPositionHandle;
  if(!enabled&&active)stopSnippetPicking(false);
}
function initSnippetTapHandle(){
  snippetTapHandle=document.createElement('button');
  snippetTapHandle.id='pk-snip-tap-handle';snippetTapHandle.type='button';
  snippetTapHandle.className='';
  let drag=null;
  snippetTapHandle.addEventListener('pointerdown',e=>{
    if(e.button!==undefined&&e.button!==0)return;
    const r=snippetTapHandle.getBoundingClientRect();
    drag={id:e.pointerId,startX:e.clientX,startY:e.clientY,left:r.left,top:r.top,moved:false};
    snippetTapMoved=false;
    try{snippetTapHandle.setPointerCapture(e.pointerId);}catch(_){ }
  });
  snippetTapHandle.addEventListener('pointermove',e=>{
    if(!drag||e.pointerId!==drag.id)return;
    if(!drag.moved&&Math.hypot(e.clientX-drag.startX,e.clientY-drag.startY)<9)return;
    drag.moved=true;snippetTapMoved=true;
    snippetTapHandle.classList.add('is-moving');
    const w=snippetTapHandle.offsetWidth,h=snippetTapHandle.offsetHeight;
    const x=Math.max(4,Math.min(window.innerWidth-w-4,drag.left+e.clientX-drag.startX));
    const y=Math.max(4,Math.min(window.innerHeight-h-4,drag.top+e.clientY-drag.startY));
    snippetTapHandle.style.left=x+'px';snippetTapHandle.style.top=y+'px';
    snippetTapHandle.style.right='auto';snippetTapHandle.style.bottom='auto';
    e.preventDefault();
  });
  const endDrag=e=>{
    if(!drag||e.pointerId!==drag.id)return;
    if(drag.moved){
      const r=snippetTapHandle.getBoundingClientRect(),p=snippetPrefs();
      p.floatX=Math.max(0,Math.min(1,(r.left+r.width/2)/window.innerWidth));
      p.floatY=Math.max(0,Math.min(1,(r.top+r.height/2)/window.innerHeight));
      persist();
    }
    snippetTapHandle.classList.remove('is-moving');drag=null;
  };
  snippetTapHandle.addEventListener('pointerup',endDrag);
  snippetTapHandle.addEventListener('pointercancel',endDrag);
  snippetTapHandle.addEventListener('click',e=>{
    e.preventDefault();e.stopPropagation();
    if(snippetTapMoved){snippetTapMoved=false;return;}
    if(snippetPicking){stopSnippetPicking(false);return;}
    if(!document.querySelector('#chat .mes[mesid]')){snippetToast('当前没有可收藏的消息');return;}
    startSnippetPicking({fromFloating:true});
  });
  document.body.appendChild(snippetTapHandle);syncSnippetTapHandle();
}

// Selection is a separate, optional shortcut to the existing editor. It does
// not change the user's native selection menu or save anything to the library.
let repoSelectionButton=null, repoSelectionTimer=0, repoSelectionRecord=null, repoSelectionPending=null;
let repoSelectionDismissed=null;
let repoSelectionTextPress=null;
function repoSelectionContextValid(saved){
  const message=saved&&ctx().chat?.[saved.id];
  return !!message && snippetChatIdentity()===saved.chatKey
    && message===saved.message && snippetMessageEligible(saved.id);
}
function repoSelectionSameRange(a,b){
  const left=a?.range,right=b?.range;
  return !!left&&!!right&&a.chatKey===b.chatKey&&a.id===b.id&&a.text===b.text
    &&left.startContainer===right.startContainer&&left.startOffset===right.startOffset
    &&left.endContainer===right.endContainer&&left.endOffset===right.endOffset;
}
function hideRepoSelection(){
  clearTimeout(repoSelectionTimer);repoSelectionTimer=0;
  repoSelectionPending=null;repoSelectionRecord=null;
  repoSelectionButton?.classList.remove('show');
}
function readRepoSelection(){
  if(isOpen()||snippetPicking||snippetBox||snippetMergeEditor||snippetPrefs().selectionShortcut===false)return null;
  const sel=window.getSelection?.();
  if(!sel||sel.isCollapsed||!sel.rangeCount)return null;
  const text=normalize(sel.toString());
  if(!text)return null;
  const range=sel.getRangeAt(0);
  const start=range.startContainer?.nodeType===1?range.startContainer:range.startContainer?.parentElement;
  const end=range.endContainer?.nodeType===1?range.endContainer:range.endContainer?.parentElement;
  const body=start?.closest?.('#chat .mes[mesid] .mes_text');
  if(!body||!body.contains(range.endContainer)||!body.contains(range.startContainer))return null;
  if(!end?.closest?.('#chat .mes[mesid] .mes_text'))return null;
  const mes=body.closest('.mes[mesid]');
  const id=Number(mes?.getAttribute('mesid'));
  if(!Number.isInteger(id)||id<0||!snippetMessageEligible(id))return null;
  return {id,text,range:range.cloneRange(),chatKey:snippetChatIdentity(),message:ctx().chat[id]};
}
function positionRepoSelection(record){
  if(!record||!repoSelectionButton)return false;
  const vv=window.visualViewport;
  const left=vv?.offsetLeft||0, top=vv?.offsetTop||0;
  const width=vv?.width||window.innerWidth, height=vv?.height||window.innerHeight;
  const rects=Array.from(record.range.getClientRects()).filter(r=>r.width>0&&r.height>0&&r.bottom>top&&r.top<top+height);
  const rect=rects[rects.length-1]||record.range.getBoundingClientRect();
  if(!rect?.width||rect.bottom<top||rect.top>top+height)return false;
  const bw=repoSelectionButton.offsetWidth||220, bh=repoSelectionButton.offsetHeight||41;
  const x=Math.max(left+8,Math.min(left+width-bw-8,rect.left+rect.width/2-bw/2));
  // Keep the native iOS selection menu and other excerpt extensions usable.
  let y=rect.bottom+10;
  if(y+bh>top+height-8)y=rect.top-bh-12;
  y=Math.max(top+8,Math.min(top+height-bh-8,y));
  repoSelectionButton.style.left=Math.round(x)+'px';
  repoSelectionButton.style.top=Math.round(y)+'px';
  return true;
}
function ensureRepoSelectionButton(){
  if(repoSelectionButton)return;
  const menu=document.createElement('div');
  menu.id='pk-repo-selection';menu.setAttribute('role','group');
  menu.setAttribute('aria-label','选中文字操作');
  menu.innerHTML='<button type="button" data-repo-action="collect"><i class="fa-regular fa-bookmark" aria-hidden="true"></i>收藏</button><span class="pk-action-divider" aria-hidden="true"></span><button type="button" data-repo-action="beautify"><i class="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i>repo 美化</button>';
  let lastPointer=0;
  const launch=(e,action)=>{
    e.preventDefault();e.stopPropagation();
    const saved=repoSelectionRecord;
    if(saved)repoSelectionDismissed=saved; // Ignore late Safari events for the consumed range.
    hideRepoSelection();
    // The chat array can be reused in-place when SillyTavern switches chats.
    if(!repoSelectionContextValid(saved)){
      snippetToast('原消息已失效或聊天已切换，请重新选择','error');return;
    }
    if(action==='collect'){
      addPickedSentence(saved.text,saved.id);
      window.getSelection?.()?.removeAllRanges?.();
    }else if(action==='beautify')openById(saved.id,saved.text);
  };
  menu.addEventListener('pointerdown',e=>{
    const target=e.target.closest?.('[data-repo-action]');
    if(!target)return;
    lastPointer=Date.now();launch(e,target.dataset.repoAction);
  });
  menu.addEventListener('click',e=>{
    const target=e.target.closest?.('[data-repo-action]');
    if(!target)return;
    if(Date.now()-lastPointer<800){e.preventDefault();e.stopPropagation();return;}
    launch(e,target.dataset.repoAction);
  });
  repoSelectionButton=menu;document.body.appendChild(menu);
}
function updateRepoSelection(){
  const record=readRepoSelection();
  if(record && repoSelectionDismissed){
    const dismissed=repoSelectionDismissed;
    // An outside tap can fire another selectionchange before Safari collapses
    // its OLD range. Do not resurrect the dismissed menu for that same range.
    if(repoSelectionSameRange(dismissed,record))return;
    repoSelectionDismissed=null;
  }
  if(!record){
    // iOS Safari often collapses the Selection while showing its native
    // toolbar, or when a finger is lifted. Preserve our last valid text.
    // Clicking elsewhere explicitly dismisses it (see init()).
    const sel=window.getSelection?.();
    // A collapsed iOS selection is transient: keep the action menu. An active
    // but invalid new selection must invalidate the saved excerpt immediately.
    if(sel && !sel.isCollapsed && sel.rangeCount){hideRepoSelection();return;}
    if(repoSelectionRecord && !repoSelectionContextValid(repoSelectionRecord))hideRepoSelection();
    return;
  }
  repoSelectionPending=record;
  clearTimeout(repoSelectionTimer);
  // Delay only until drag handles settle; do not re-require an active native
  // Selection at the end of the delay, because Safari may have cleared it.
  repoSelectionTimer=setTimeout(()=>{
    repoSelectionTimer=0;
    const live=readRepoSelection();
    const saved=live||repoSelectionPending;
    if(!repoSelectionContextValid(saved) || (repoSelectionDismissed && repoSelectionSameRange(repoSelectionDismissed,saved))){hideRepoSelection();return;}
    ensureRepoSelectionButton();repoSelectionRecord=saved;
    repoSelectionPending=null;
    repoSelectionButton.classList.add('show');
    if(!positionRepoSelection(saved))hideRepoSelection();
  },220);
}

function init() {
  store();
  document.querySelectorAll('.pk-mes-btn').forEach(b => b.remove());
  // The extension/wand menu can be mounted slightly after this script runs.
  let wandWatcher=null;
  if(!ensureRepoWandMenu()) {
    wandWatcher=new MutationObserver(()=>{
      if(ensureRepoWandMenu()){wandWatcher.disconnect();wandWatcher=null;}
    });
    wandWatcher.observe(document.body,{childList:true,subtree:true});
  }
  const wandMenuClick=e=>{
    if(e.target.closest?.('#extensionsMenuButton'))ensureRepoWandMenu();
  };
  document.addEventListener('click',wandMenuClick,true);
  initSnippetTapHandle();
  window.addEventListener('resize',snippetPositionHandle);
  // Observe selection only in chat message bodies; never intercept OS copy menu.
  const onRepoSelectionChange=()=>updateRepoSelection();
  const onRepoSelectionOutside=e=>{
    if(repoSelectionButton?.contains(e.target))return;
    const previous=repoSelectionRecord||repoSelectionPending;
    if(previous){
      repoSelectionDismissed=previous;
      hideRepoSelection();
    }
    // A regular tap on message text can dismiss the iOS selection without
    // creating a new one. Do NOT re-arm the same stale range on pointerdown.
    const body=e.target?.closest?.('#chat .mes[mesid] .mes_text');
    repoSelectionTextPress=body&&repoSelectionDismissed?{started:Date.now(),body}:null;
  };
  const onRepoSelectStart=e=>{
    if(e.target?.closest?.('#chat .mes[mesid] .mes_text'))repoSelectionDismissed=null;
  };
  const onRepoSelectionPointerUp=()=>{
    // Some iOS builds do not dispatch selectstart on a long press. Only a
    // deliberate long gesture can re-arm exactly the same selected range.
    if(repoSelectionTextPress && Date.now()-repoSelectionTextPress.started>=450){
      const selected=readRepoSelection();
      // pointercancel also fires during a scroll. Do not revive the stale
      // excerpt unless this gesture produced a genuinely different range.
      if(selected && !repoSelectionSameRange(repoSelectionDismissed,selected)){
        repoSelectionDismissed=null;
        updateRepoSelection();
      }
    }
    repoSelectionTextPress=null;
  };
  const onRepoSelectionKey=e=>{
    if(e.key==='Escape'){
      const previous=repoSelectionRecord||repoSelectionPending;
      if(previous)repoSelectionDismissed=previous;
      hideRepoSelection();
    }
  };
  const onRepoReposition=()=>{
    if(!repoSelectionRecord||!repoSelectionButton?.classList.contains('show'))return;
    if(!repoSelectionContextValid(repoSelectionRecord)||!positionRepoSelection(repoSelectionRecord))hideRepoSelection();
  };
  document.addEventListener('selectionchange',onRepoSelectionChange);
  document.addEventListener('pointerdown',onRepoSelectionOutside,true);
  document.addEventListener('pointerup',onRepoSelectionPointerUp,true);
  document.addEventListener('pointercancel',onRepoSelectionPointerUp,true);
  document.addEventListener('selectstart',onRepoSelectStart,true);
  document.addEventListener('keydown',onRepoSelectionKey,true);
  document.addEventListener('scroll',onRepoReposition,true);
  window.addEventListener('resize',onRepoReposition);
  window.visualViewport?.addEventListener('resize',onRepoReposition);
  window.visualViewport?.addEventListener('scroll',onRepoReposition);

  const onResize = () => {
    if (!isOpen()) return;
    if (keyboardIsOpen()) { queueKeyboardViewport(); return; }
    if (Date.now() < keyboardCoolingUntil) return;
    if (st.editing) syncVisualViewport();
    schedule();
  };
  window.addEventListener('resize', onResize);
  window.visualViewport?.addEventListener('resize', onResize);
  window.visualViewport?.addEventListener('scroll', onResize);
  return () => {
    clearTimeout(fieldTimer); fieldTimer = 0; pendingField = null;
    clearTimeout(keyboardRenderTimer); keyboardRenderTimer = 0; keyboardRenderPending = false;
    if (keyboardFrame) { window.cancelAnimationFrame(keyboardFrame); keyboardFrame = 0; }
    window.removeEventListener('resize', onResize);
    window.visualViewport?.removeEventListener('resize', onResize);
    window.visualViewport?.removeEventListener('scroll', onResize);
    wandWatcher?.disconnect();
    document.removeEventListener('click',wandMenuClick,true);
    window.removeEventListener('resize',snippetPositionHandle);
    snippetTapHandle?.remove();snippetTapHandle=null;snippetTapIconRendered=null;
    document.removeEventListener('selectionchange',onRepoSelectionChange);
    document.removeEventListener('pointerdown',onRepoSelectionOutside,true);
    document.removeEventListener('pointerup',onRepoSelectionPointerUp,true);
    document.removeEventListener('pointercancel',onRepoSelectionPointerUp,true);
    document.removeEventListener('selectstart',onRepoSelectStart,true);
    repoSelectionTextPress=null;
    document.removeEventListener('keydown',onRepoSelectionKey,true);
    document.removeEventListener('scroll',onRepoReposition,true);
    window.removeEventListener('resize',onRepoReposition);
    window.visualViewport?.removeEventListener('resize',onRepoReposition);
    window.visualViewport?.removeEventListener('scroll',onRepoReposition);
    hideRepoSelection();repoSelectionDismissed=null;repoSelectionButton?.remove();repoSelectionButton=null;
    hideSnippetActionMenu();
    snippetMergeEditor?.remove();snippetMergeEditor=null;

     stopSnippetPicking(false);closeSnippetBox();
     snippetSystemTheme?.removeEventListener?.('change',snippetSystemThemeChanged);
     document.getElementById('pk-wand')?.remove();
    if (st.ov) { st.ov._pkFontObserver?.disconnect(); st.ov.remove(); }
  };
}


  const dispose = init();
  const onPageHide = () => { if (typeof window.__pkDispose === 'function') window.__pkDispose(); };
  window.__pkDispose = () => {
    globalThis.removeEventListener('pagehide', onPageHide);
    if (rafId) { window.cancelAnimationFrame(rafId); rafId = 0; }
    dispose();
    style.remove();
    window.__pkDispose = null;
  };
  globalThis.addEventListener('pagehide', onPageHide);
})();
